import { ServerNode } from '../types/vpn';

export const SERVERS_LIST: ServerNode[] = [
  // --- WARP-in-WARP (وارپ در وارپ دو مرحله‌ای) ---
  {
    id: 'warp-on-warp-chain',
    name: 'WARP-in-WARP Dual Cloudflare Chain',
    nameFa: 'وارپ در وارپ کلودفلر (دو لایه ضد فیلترینگ)',
    country: 'Germany / Cloudflare Dual',
    countryCode: 'cf',
    flag: '⚡',
    protocol: 'warp_in_warp',
    subProtocol: 'warp_on_warp_dual',
    category: 'international',
    ping: 46,
    serverIp: '162.159.192.1 -> 162.159.193.10',
    port: 2408,
    cipher: 'Dual WireGuard-Noise Layer',
    recommendedIsps: ['mci', 'mtn', 'rightel', 'mokhaberat', 'zitel'],
    loadPercentage: 30,
    configUrl: 'warp://chain@162.159.192.1:2408?inner=162.159.193.10:500&mtu=1280#MatVPN-WARP-in-WARP',
    features: ['بای‌پس فیلترینگ با کپسوله‌سازی دو لایه وارپ', 'آی‌پی تمیز کلودفلر با پینگ فوق‌العاده', 'آنبلاک یوتیوب و تلگرام در دکل‌های همراه']
  },

  // --- National Internet Reverse Relays (اینترنت ملی) ---
  {
    id: 'iran-relay-tehran',
    name: 'Tehran Intranet Reverse Relay',
    nameFa: 'تونل معکوس اضطراری تهران (ملی به خارج)',
    country: 'Iran / Germany',
    countryCode: 'ir',
    flag: '🇮🇷',
    protocol: 'iran_relay',
    subProtocol: 'iran_national_relay',
    category: 'national_emergency',
    ping: 32,
    serverIp: '185.143.232.14',
    port: 443,
    isNationalRelay: true,
    recommendedIsps: ['mci', 'mtn', 'rightel', 'mokhaberat', 'zitel'],
    loadPercentage: 42,
    configUrl: 'vless://matvpn-tehran-relay@185.143.232.14:443?security=reality&sni=shaparak.ir&fp=chrome#MatVPN-Iran-Relay',
    features: ['فعال در زمان قطعی کامل اینترنت بین‌الملل', 'SNI جعلی سایت بانکی', 'ترافیک نیم‌بها']
  },
  {
    id: 'iran-relay-isfahan',
    name: 'Isfahan White-Tunnel Bridge',
    nameFa: 'پل ضد قطعی اصفهان (مخصوص همراه اول و ایرانسل)',
    country: 'Iran / Netherlands',
    countryCode: 'ir',
    flag: '🇮🇷',
    protocol: 'iran_relay',
    subProtocol: 'iran_national_relay',
    category: 'national_emergency',
    ping: 38,
    serverIp: '188.121.100.55',
    port: 8443,
    isNationalRelay: true,
    recommendedIsps: ['mci', 'mtn'],
    loadPercentage: 55,
    configUrl: 'vless://matvpn-isfahan-relay@188.121.100.55:8443?security=reality&sni=telewebion.com&fp=safari#MatVPN-Isfahan',
    features: ['بای‌پس فیلترینگ شدید', 'تکه کردن بسته‌ها (Fragment)', 'مقاوم در برابر اختلالات DNS']
  },

  // --- Amnezia VPN (AmneziaWG Anti-DPI) ---
  {
    id: 'amnezia-ams-01',
    name: 'AmneziaWG Stealth DPI-Proof',
    nameFa: 'امنزیا وایرگارد آنتی DPI (آمستردام)',
    country: 'Netherlands',
    countryCode: 'nl',
    flag: '🇳🇱',
    protocol: 'amnezia',
    subProtocol: 'amnezia_wg',
    ping: 68,
    serverIp: '45.155.172.90',
    port: 51820,
    cipher: 'ChaCha20-Poly1305 + JunkPackets',
    recommendedIsps: ['mci', 'mtn', 'rightel', 'mokhaberat'],
    loadPercentage: 38,
    configUrl: 'awg://amnezia-ams-config?jc=4&jmin=50&jmax=1000&s1=15&s2=30#MatVPN-AmneziaWG-NL',
    features: ['پکت‌های نویز رندوم Amnezia', 'غیرقابل شناسایی توسط فایروال مخابرات', 'پینگ بسیار پایدار']
  },
  {
    id: 'amnezia-zurich-02',
    name: 'AmneziaWG Junk Shield',
    nameFa: 'امنزیا زوریخ (سوئیس - ضد فیلترینگ سخت)',
    country: 'Switzerland',
    countryCode: 'ch',
    flag: '🇨🇭',
    protocol: 'amnezia',
    subProtocol: 'amnezia_wg',
    ping: 74,
    serverIp: '194.36.144.12',
    port: 52820,
    cipher: 'ChaCha20 + ObfsHeader',
    recommendedIsps: ['mci', 'mtn', 'zitel'],
    loadPercentage: 29,
    configUrl: 'awg://amnezia-ch-config?jc=6&jmin=70&jmax=1200&s1=20&s2=40#MatVPN-AmneziaWG-CH',
    features: ['رمزنگاری فوق سنگین سوئیس', 'پشتیبانی از همراه اول و رایتل', 'بدون نشت آی‌پی']
  },

  // --- Cloudflare WARP & WARP+ ---
  {
    id: 'warp-cleanip-01',
    name: 'WARP+ Clean IP Auto-Scan',
    nameFa: 'وارپ پلاس با اسکن خودکار آی‌پی تمیز',
    country: 'Germany / Cloudflare',
    countryCode: 'de',
    flag: '🚀',
    protocol: 'warp',
    subProtocol: 'warp_clean_ip',
    isCleanIp: true,
    ping: 52,
    serverIp: '162.159.192.1',
    port: 2408,
    cipher: 'WireGuard-Noise',
    recommendedIsps: ['mci', 'mtn', 'rightel', 'mokhaberat'],
    loadPercentage: 45,
    configUrl: 'warp://162.159.192.1:2408?reserved=1,2,3&mtu=1280#MatVPN-WARP-Plus',
    features: ['سرعت نامحدود کلودفلر', 'تست دائمی تمیز بودن رنج آی‌پی', 'تنظیم خودکار MTU 1280']
  },
  {
    id: 'warp-frankfurt-02',
    name: 'WARP ZeroTrust Gateway',
    nameFa: 'وارپ زیروتراست فرانکفورت (حداکثر سرعت دانلود)',
    country: 'Germany',
    countryCode: 'de',
    flag: '🇩🇪',
    protocol: 'warp',
    subProtocol: 'warp_wireguard',
    ping: 61,
    serverIp: '162.159.193.10',
    port: 500,
    cipher: 'WireGuard-Noise',
    recommendedIsps: ['mtn', 'mokhaberat', 'zitel'],
    loadPercentage: 58,
    configUrl: 'warp://162.159.193.10:500?mtu=1360#MatVPN-WARP-Fast',
    features: ['مناسب یوتیوب و اینستاگرام 4K', 'پینگ کم برای گیمینگ', 'DNS امن 1.1.1.1']
  },

  // --- Tor Onion Routing & Snowflake Bridges ---
  {
    id: 'tor-snowflake-01',
    name: 'Tor Snowflake Resilient',
    nameFa: 'تور اسنوفلیک (عبور از فیلترینگ ۱۰۰٪ ضد مسدودی)',
    country: 'Tor Network',
    countryCode: 'tor',
    flag: '🧅',
    protocol: 'tor',
    subProtocol: 'tor_snowflake',
    ping: 110,
    serverIp: 'snowflake.torproject.net',
    port: 443,
    cipher: 'WebRTC Multi-Peer P2P',
    recommendedIsps: ['mci', 'mtn', 'rightel', 'mokhaberat', 'zitel'],
    loadPercentage: 62,
    configUrl: 'tor://snowflake?broker=https://snowflake-broker.torproject.net/&amp_cache=true#MatVPN-Tor-Snowflake',
    features: ['استفاده از ترنسپورت WebRTC', 'غیرقابل مسدودسازی توسط رگولاتوری', 'حریم خصوصی مطلق']
  },
  {
    id: 'tor-obfs4-finland',
    name: 'Tor obfs4 Bridges Turbo',
    nameFa: 'پل‌های تغییرشکل یافته Tor obfs4 (فنلاند)',
    country: 'Finland',
    countryCode: 'fi',
    flag: '🇫🇮',
    protocol: 'tor',
    subProtocol: 'tor_obfs4',
    ping: 95,
    serverIp: '95.217.180.22',
    port: 443,
    cipher: 'obfs4 Obfuscation',
    recommendedIsps: ['mci', 'mtn'],
    loadPercentage: 51,
    configUrl: 'tor://obfs4@95.217.180.22:443?cert=matvpnCert&iat-mode=1#MatVPN-Tor-obfs4',
    features: ['تبدیل ظاهر ترافیک به رندوم بیتس', 'دور زدن فیلترینگ سخت همراه اول', 'مسیریابی ۳ گره‌ای']
  },

  // --- V2Ray / Xray (VLESS Reality & Vision) ---
  {
    id: 'v2ray-vless-reality-fra',
    name: 'VLESS Reality Chrome Fake',
    nameFa: 'وی‌لس ریالیتی (تکنولوژی گوگل کروم - فرانکفورت)',
    country: 'Germany',
    countryCode: 'de',
    flag: '🇩🇪',
    protocol: 'v2ray',
    subProtocol: 'vless_reality',
    ping: 58,
    serverIp: '159.69.210.88',
    port: 443,
    cipher: 'TLS 1.3 / Reality',
    recommendedIsps: ['mci', 'mtn', 'rightel', 'mokhaberat', 'zitel'],
    loadPercentage: 40,
    configUrl: 'vless://4a81e3a9-e854-4a27-a9a3-5c219f5647a1@159.69.210.88:443?security=reality&sni=www.google.com&fp=chrome&pbk=matvpnRealityKey&sid=6a2b&type=tcp&flow=xtls-rprx-vision#MatVPN-Reality-DE',
    features: ['تقلید رفتار مرورگر کروم', 'تکنولوژی Vision ضد DPI', 'پینگ فوق‌العاده سریع']
  },
  {
    id: 'v2ray-vless-helsinki',
    name: 'VLESS Reality gRPC Fast',
    nameFa: 'وی‌لس ریالیتی gRPC (هلسینکی فنلاند)',
    country: 'Finland',
    countryCode: 'fi',
    flag: '🇫🇮',
    protocol: 'v2ray',
    subProtocol: 'vless_reality',
    ping: 64,
    serverIp: '65.21.140.72',
    port: 443,
    cipher: 'gRPC Multi-Stream',
    recommendedIsps: ['mci', 'mtn', 'rightel'],
    loadPercentage: 35,
    configUrl: 'vless://9b71a2c3-d4e5-4f67-8901-23456789abcd@65.21.140.72:443?security=reality&sni=speedtest.net&fp=firefox&type=grpc&serviceName=matgrpc#MatVPN-Reality-FI',
    features: ['مخصوص تلگرام و اینستاگرام پرسرعت', 'مناسب برای دانلود حجیم', 'ضد پکت لاس']
  },
  {
    id: 'v2ray-vmess-ws-cdn',
    name: 'VMess WebSocket CDN Relay',
    nameFa: 'وی‌مس وب‌سوکت روی CDN کلودفلر',
    country: 'United Kingdom',
    countryCode: 'gb',
    flag: '🇬🇧',
    protocol: 'v2ray',
    subProtocol: 'vmess_ws',
    ping: 72,
    serverIp: '104.21.45.190',
    port: 443,
    cipher: 'Auto / AES-128-GCM',
    recommendedIsps: ['mci', 'mtn', 'mokhaberat'],
    loadPercentage: 66,
    configUrl: 'vmess://eyJhZGQiOiIxMDQuMjEuNDUuMTkwIiwiYWlkIjoiMCIsImhvc3QiOiJjZG4ubWF0dnBuLm5ldCIsImlkIjoiZjI1NGYyZTUtYTcwYi00YjVjLThhYmYtYzRiYmM2OTZkODliIiwibmV0Ijoid3MiLCJwYXRoIjoiL21hdHdzIiwicG9ydCI6IjQ0MyIsInBzIjoiTWF0VlBOLVZNZXNzLVVLIiwidGxzIjoidGxzIiwidHlwZSI6Im5vbmUiLCJ2IjoiMiJ9',
    features: ['عبور از فایروال با CDN', 'پنهان‌سازی آی‌پی اصلی پشت کلودفلر', 'آپلود پرسرعت']
  },

  // --- Psiphon ---
  {
    id: 'psiphon-stealth-austria',
    name: 'Psiphon Obfuscated SSH',
    nameFa: 'سایفون اس‌اس‌اچ مبدل (اتریش)',
    country: 'Austria',
    countryCode: 'at',
    flag: '🇦🇹',
    protocol: 'psiphon',
    subProtocol: 'psiphon_ssh',
    ping: 82,
    serverIp: '193.187.174.40',
    port: 443,
    cipher: 'SSH-RSA + Fronting',
    recommendedIsps: ['mci', 'rightel', 'mokhaberat'],
    loadPercentage: 47,
    configUrl: 'psiphon://ssh-tunnel@193.187.174.40:443?protocol=SSH-OSSH&fronting=cloudflare#MatVPN-Psiphon-AT',
    features: ['الگوریتم اختصاصی فرار از فیلترینگ سایفون', 'سوییچ هوشمند پورت', 'پایداری بالا در شبکه‌های ضعیف']
  },

  // --- WireGuard Native ---
  {
    id: 'wireguard-fast-stockholm',
    name: 'WireGuard Kernel Speed',
    nameFa: 'وایرگارد مستقیم هسته کرنل (استکهلم سوئد)',
    country: 'Sweden',
    countryCode: 'se',
    flag: '🇸🇪',
    protocol: 'wireguard',
    subProtocol: 'warp_wireguard',
    ping: 65,
    serverIp: '185.157.162.20',
    port: 51820,
    cipher: 'Curve25519 / Poly1305',
    recommendedIsps: ['mtn', 'zitel', 'mokhaberat'],
    loadPercentage: 30,
    configUrl: '[Interface]\nPrivateKey = aBcDeFgHiJkLmNoPqRsTuVwXyZ123456=\nAddress = 10.0.0.2/24\nDNS = 1.1.1.1\n\n[Peer]\nPublicKey = zYxWvUtSrQpOnMlKjIhGfEdCbA654321=\nEndpoint = 185.157.162.20:51820\nAllowedIPs = 0.0.0.0/0',
    features: ['کمترین مصرف باتری در اندروید', 'پروتکل سبک با سرعت آنی', 'بهینه‌سازی شده برای استریم']
  },

  // --- Proton VPN ---
  {
    id: 'proton-stealth-swiss',
    name: 'Proton Stealth Protocol',
    nameFa: 'پروتون پروتکل استیلث (سوئیس - امنیت حداکثری)',
    country: 'Switzerland',
    countryCode: 'ch',
    flag: '🇨🇭',
    protocol: 'proton',
    subProtocol: 'proton_stealth',
    ping: 79,
    serverIp: '185.159.157.3',
    port: 443,
    cipher: 'WireGuard-over-TLS (Stealth)',
    recommendedIsps: ['mci', 'mtn', 'rightel'],
    loadPercentage: 50,
    configUrl: 'proton://stealth@185.159.157.3:443?safeMode=on&netshield=active#MatVPN-Proton-Stealth',
    features: ['مخصوص عبور از فیلترینگ شدید', 'حفاظت در برابر نشت DNS و WebRTC', 'سرورهای اختصاصی با گواهی سوئیس']
  },

  // --- Lantern P2P Mesh ---
  {
    id: 'lantern-mesh-uk',
    name: 'Lantern P2P Mesh Bypass',
    nameFa: 'لنترن شبکه همتابه‌همتا (لندن انگلستان)',
    country: 'United Kingdom',
    countryCode: 'gb',
    flag: '🏮',
    protocol: 'lantern',
    subProtocol: 'lantern_mesh',
    ping: 88,
    serverIp: '51.15.22.8',
    port: 8080,
    cipher: 'P2P Mesh + Fronting',
    recommendedIsps: ['mci', 'mtn', 'mokhaberat'],
    loadPercentage: 39,
    configUrl: 'lantern://mesh-node@51.15.22.8:8080?peerHop=true#MatVPN-Lantern-P2P',
    features: ['استفاده از شبکه P2P توزیع‌شده', 'عدم نیاز به سرور متمرکز', 'دور زدن فیلترهای منطقه‌ای']
  },

  // --- Sing-Box (ضد فیلتر sin / sing-box) ---
  {
    id: 'singbox-tuic-frankfurt',
    name: 'Sing-Box TUIC v5 & ShadowTLS',
    nameFa: 'سینگ‌باکس TUIC v5 ضد فیلترینگ شدید',
    country: 'Germany',
    countryCode: 'de',
    flag: '📦',
    protocol: 'singbox',
    subProtocol: 'singbox_tuic',
    ping: 49,
    serverIp: '188.40.168.112',
    port: 8443,
    cipher: 'BBR + Congestion Control',
    recommendedIsps: ['mci', 'mtn', 'rightel', 'mokhaberat'],
    loadPercentage: 28,
    configUrl: 'singbox://{"outbounds":[{"type":"tuic","server":"188.40.168.112","server_port":8443,"uuid":"matvpn-singbox-uuid","password":"matvpn","congestion_control":"bbr","tls":{"enabled":true,"server_name":"www.bing.com"}}]}#MatVPN-SingBox-TUIC',
    features: ['سرعت آنی روی پروتکل UDP پروتکل TUIC', 'شبیه‌سازی ترافیک موتور جستجو بینگ', 'مقاوم در برابر اختلالات دکل‌های همراه']
  },

  // --- GitHub Tunnel Relay (گیت‌هاب تانل ضد تحریم و بدون فیلتر) ---
  {
    id: 'github-tunnel-relay',
    name: 'GitHub Cloud DevTunnel Relay',
    nameFa: 'گیت‌هاب تانل ابری (دامنه مجاز سفید دانشگاهی)',
    country: 'United States',
    countryCode: 'us',
    flag: '🐙',
    protocol: 'github_tunnel',
    subProtocol: 'github_actions_relay',
    ping: 55,
    serverIp: 'tunnel.githubusercontent.com',
    port: 443,
    cipher: 'GitHub-TLS-v1.3',
    recommendedIsps: ['mci', 'mtn', 'rightel', 'mokhaberat', 'zitel'],
    loadPercentage: 31,
    configUrl: 'vless://matvpn-github-relay@tunnel.githubusercontent.com:443?security=tls&sni=github.com&fp=chrome#MatVPN-GitHub-Tunnel',
    features: ['عبور از فیلتر به دلیل سفید بودن دامنه‌های گیت‌هاب', 'غیرقابل مسدودی برای برنامه‌نویسان و دانشگاه‌ها', 'پایداری ۱۰۰٪ بدون نوسان']
  },

  // --- Windscribe VPN (Stealth WSTunnel) ---
  {
    id: 'windscribe-stealth-canada',
    name: 'Windscribe Stealth WSTunnel',
    nameFa: 'وینداسکرایب استیلث ۴۴۳ (تورنتو کانادا)',
    country: 'Canada',
    countryCode: 'ca',
    flag: '🇨🇦',
    protocol: 'windscribe',
    subProtocol: 'windscribe_stealth',
    ping: 89,
    serverIp: '198.51.100.80',
    port: 443,
    cipher: 'WSTunnel-over-TLS',
    recommendedIsps: ['mci', 'mtn', 'mokhaberat'],
    loadPercentage: 44,
    configUrl: 'windscribe://stealth@198.51.100.80:443?protocol=wstunnel&port=443#MatVPN-Windscribe-Stealth',
    features: ['مبدل ترافیک به وب‌سوکت استاندارد HTTPS', 'تکنولوژی رابرت ضد ردیابی', 'رمزنگاری نظامی AES-256-GCM']
  },

  // --- OpenVPN (با پچ مبدل Scramble و ضد فیلترینگ XOR) ---
  {
    id: 'openvpn-xor-germany',
    name: 'OpenVPN Scramble XOR Stealth',
    nameFa: 'اوپن‌وی‌پی‌ان با پچ مبدل XOR (فرانکفورت)',
    country: 'Germany',
    countryCode: 'de',
    flag: '🇩🇪',
    protocol: 'openvpn',
    subProtocol: 'openvpn_xor',
    ping: 67,
    serverIp: '195.201.200.45',
    port: 1194,
    cipher: 'AES-256-CBC + Scramble-XOR',
    recommendedIsps: ['mci', 'rightel', 'mokhaberat'],
    loadPercentage: 36,
    configUrl: 'client\ndev tun\nproto tcp\nremote 195.201.200.45 1194\nscramble obfuscate matvpn_xor_key\ncipher AES-256-GCM\nauth SHA256\n<ca>\n-----BEGIN CERTIFICATE-----\nMIIDQjCCAiqgAwIBAgIU...\n-----END CERTIFICATE-----\n</ca>',
    features: ['مبدل XOR جهت خنثی‌سازی اثرانگشت OpenVPN', 'پورت TCP 1194 و ۴۴۳', 'تست شده روی سخت‌ترین فایروال‌های دولتی']
  },

  // --- Telegram MTProto Fake TLS Proxy (پروکسی اختصاصی تلگرام) ---
  {
    id: 'telegram-mtproto-proxy',
    name: 'Telegram MTProto Fake TLS Proxy',
    nameFa: 'پروکسی تلگرام ضد فیلتر (Fake TLS سکرت ee)',
    country: 'Netherlands',
    countryCode: 'nl',
    flag: '✈️',
    protocol: 'telegram_proxy',
    subProtocol: 'telegram_mtproto_faketls',
    ping: 44,
    serverIp: '185.220.101.5',
    port: 443,
    cipher: 'MTProto Fake TLS / ee secret',
    recommendedIsps: ['mci', 'mtn', 'rightel', 'mokhaberat', 'zitel'],
    loadPercentage: 22,
    configUrl: 'tg://proxy?server=185.220.101.5&port=443&secret=ee1603010200010001fc030386e24c3add7777772e676f6f676c652e636f6d',
    features: ['اتصال مستقیم ۱ کلیکه تلگرام بدون قطعی', 'سکرت ee تقلید سایت گوگل', 'دانلود فوق سریع فیلم و ویس در تلگرام']
  }
];

export interface VPNEngineMeta {
  id: string;
  name: string;
  nameFa: string;
  icon: string;
  color: string;
  category: 'international' | 'national_emergency';
  desc: string;
}

export const VPN_CATEGORIES = [
  { id: 'all', nameFa: 'همه پروتکل‌ها (۱۵ پروتکل)', icon: '⚡' },
  { id: 'international', nameFa: '۱. فیلترشکن‌های بین‌المللی و ضد DPI', icon: '🌐' },
  { id: 'national_emergency', nameFa: '۲. شبکه‌های ضد قطعی ملی و اضطراری', icon: '🇮🇷' },
];

export const ALL_SUPPORTED_ENGINES: VPNEngineMeta[] = [
  // --- Category 1: International & Anti-DPI ---
  { id: 'v2ray', name: 'V2Ray / Xray', nameFa: 'وی‌تو‌ری و ریالیتی', icon: '⚡', color: '#ff2d78', category: 'international', desc: 'VLESS, VMess, Reality, Trojan, Shadowsocks' },
  { id: 'warp_in_warp', name: 'WARP in WARP', nameFa: 'وارپ در وارپ (دو لایه)', icon: '🚀', color: '#ffe600', category: 'international', desc: 'کپسوله‌سازی دو لایه کلودفلر برای دور زدن فیلترینگ شدید' },
  { id: 'warp', name: 'Cloudflare WARP', nameFa: 'وارپ کلودفلر', icon: '🚀', color: '#ff7700', category: 'international', desc: 'WARP+, Clean IP Scanner, ZeroTrust, MTU 1280' },
  { id: 'singbox', name: 'Sing-Box Core', nameFa: 'سینگ‌باکس TUIC', icon: '📦', color: '#ffe600', category: 'international', desc: 'TUIC v5, ShadowTLS, Multiplexing, Zero Latency' },
  { id: 'amnezia', name: 'Amnezia VPN', nameFa: 'امنزیا وایرگارد', icon: '🔒', color: '#00ff66', category: 'international', desc: 'AmneziaWG با پکت‌های تصادفی Junk علیه فیلترینگ' },
  { id: 'windscribe', name: 'Windscribe Stealth', nameFa: 'وینداسکرایب', icon: '🛡️', color: '#ff7700', category: 'international', desc: 'Wstunnel روی پورت ۴۴۳ با تکنولوژی ضد ردیابی' },
  { id: 'openvpn', name: 'OpenVPN Scramble', nameFa: 'اوپن‌وی‌پی‌ان XOR', icon: '🔒', color: '#a855f7', category: 'international', desc: 'پچ اختصاصی XOR برای عبور از فیلترینگ لایه ۷' },
  { id: 'tor', name: 'Tor & Snowflake', nameFa: 'تور و اسنوفلیک', icon: '🧅', color: '#ffe600', category: 'international', desc: 'Snowflake WebRTC, obfs4 Bridges, Uncensorable' },
  { id: 'psiphon', name: 'Psiphon Tunnel', nameFa: 'سایفون تانل', icon: '🌐', color: '#00e5ff', category: 'international', desc: 'Obfuscated SSH, Fronted Meeks, Multi-Hop' },
  { id: 'wireguard', name: 'WireGuard', nameFa: 'وایرگارد مستقیم', icon: '🛡️', color: '#a855f7', category: 'international', desc: 'Fastest UDP kernel tunneling, ultra low battery' },
  { id: 'proton', name: 'Proton Stealth', nameFa: 'پروتون استیلث', icon: '⚔️', color: '#ff2d78', category: 'international', desc: 'Stealth WG-over-TLS, Secure Core, Swiss privacy' },
  { id: 'lantern', name: 'Lantern P2P', nameFa: 'لنترن مش', icon: '🏮', color: '#ff7700', category: 'international', desc: 'Peer-to-Peer mesh routing, geo-blocking bypass' },

  // --- Category 2: National & Emergency Bypasses ---
  { id: 'iran_relay', name: 'National Intranet Relay', nameFa: 'پل اینترنت ملی', icon: '🇮🇷', color: '#00ff66', category: 'national_emergency', desc: 'سوییچ خودکار هنگام قطعی اینترنت بین‌الملل و ملی شدن' },
  { id: 'github_tunnel', name: 'GitHub Tunnel', nameFa: 'گیت‌هاب تانل ابری', icon: '🐙', color: '#00ff66', category: 'national_emergency', desc: 'عبور از فیلتر به دلیل سفید بودن دامنه‌های گیت‌هاب' },
  { id: 'telegram_proxy', name: 'Telegram MTProto', nameFa: 'پروکسی تلگرام', icon: '✈️', color: '#00e5ff', category: 'national_emergency', desc: 'پروکسی دائمی تلگرام با سکرت Fake TLS' },
];

export const IRANIAN_APPS_PRESETS = [
  { id: 'bank_mellat', name: 'همراه بانک ملت', pkg: 'ir.bankmellat', isBypass: true, icon: '🏦' },
  { id: 'bank_melli', name: 'بام بانک ملی', pkg: 'ir.melli.baam', isBypass: true, icon: '🏛️' },
  { id: 'snapp', name: 'اسنپ رانندگان و مسافر', pkg: 'cab.snapp.passenger', isBypass: true, icon: '🚗' },
  { id: 'tapsi', name: 'تپسی Tapsi', pkg: 'taxi.tap30.passenger', isBypass: true, icon: '🚕' },
  { id: 'digikala', name: 'دیجی‌کالا', pkg: 'com.digikala', isBypass: true, icon: '🛍️' },
  { id: 'ap', name: 'آپ (آسان پرداخت)', pkg: 'com.asanpardakht.app', isBypass: true, icon: '💳' },
  { id: 'rubika', name: 'روبیکا (شبکه ملی)', pkg: 'ir.rubika.app', isBypass: true, icon: '🇮🇷' },
  { id: 'bale', name: 'بله پیام‌رسان', pkg: 'ir.bale.messenger', isBypass: true, icon: '💬' },
  { id: 'telegram', name: 'تلگرام Telegram (تونل اجباری)', pkg: 'org.telegram.messenger', isBypass: false, icon: '✈️' },
  { id: 'instagram', name: 'اینستاگرام Instagram', pkg: 'com.instagram.android', isBypass: false, icon: '📸' },
  { id: 'youtube', name: 'یوتیوب YouTube', pkg: 'com.google.android.youtube', isBypass: false, icon: '▶️' },
  { id: 'x', name: 'ایکس / توییتر Twitter', pkg: 'com.twitter.android', isBypass: false, icon: '✖️' },
  { id: 'whatsapp', name: 'واتساپ WhatsApp', pkg: 'com.whatsapp', isBypass: false, icon: '🟢' }
];
