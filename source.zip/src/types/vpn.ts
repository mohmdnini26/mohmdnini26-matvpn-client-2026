export type VPNProtocol = 
  | 'v2ray' 
  | 'warp' 
  | 'warp_in_warp'
  | 'wireguard' 
  | 'amnezia' 
  | 'tor' 
  | 'psiphon' 
  | 'proton' 
  | 'lantern'
  | 'singbox'
  | 'openvpn'
  | 'windscribe'
  | 'github_tunnel'
  | 'telegram_proxy'
  | 'iran_relay';

export type SubProtocol = 
  | 'vless_reality'
  | 'vmess_ws'
  | 'trojan_grpc'
  | 'shadowsocks_2022'
  | 'warp_wireguard'
  | 'warp_clean_ip'
  | 'warp_on_warp_dual'
  | 'amnezia_wg'
  | 'tor_snowflake'
  | 'tor_obfs4'
  | 'psiphon_ssh'
  | 'proton_stealth'
  | 'lantern_mesh'
  | 'singbox_tuic'
  | 'openvpn_xor'
  | 'windscribe_stealth'
  | 'github_actions_relay'
  | 'telegram_mtproto_faketls'
  | 'iran_national_relay';

export type VPNCategory = 'international' | 'national_emergency';

export type ISPType = 'all' | 'mci' | 'mtn' | 'rightel' | 'mokhaberat' | 'zitel';

export interface ServerNode {
  id: string;
  name: string;
  nameFa: string;
  country: string;
  countryCode: string;
  flag: string;
  category?: VPNCategory;
  protocol: VPNProtocol;
  subProtocol: SubProtocol;
  ping: number; // in ms
  serverIp: string;
  port: number;
  cipher?: string;
  isNationalRelay?: boolean; // تونل رله اینترنت ملی
  isCleanIp?: boolean;
  recommendedIsps: ISPType[];
  loadPercentage: number;
  configUrl: string;
  features: string[];
}

export interface VPNSettings {
  // Iran National Internet auto-fallback
  nationalAutoFallback: boolean; // سوئیچ خودکار به رله داخلی هنگام قطعی یا افت سرعت
  autoFailoverProtocols: boolean; // سوییچ خودکار در صورت فیلتر شدن یک پروتکل
  failoverLatencyThreshold: number; // ms e.g. 500ms

  // Anti-Censorship & DPI bypass
  fragmentEnabled: boolean; // پکت فرگمنت
  fragmentLength: string; // e.g. "1-3"
  fragmentInterval: string; // e.g. "10-25"
  
  fakeSniEnabled: boolean; // دور زدن با SNI مجاز داخلی
  selectedFakeSni: string; // e.g. "shaparak.ir", "telewebion.com", "shad.ir"
  customFakeSni: string;

  amneziaJunkPackets: boolean; // هدرهای رندوم و پکت‌های آشغال Amnezia
  amneziaJunkMin: number;
  amneziaJunkMax: number;

  mtu: number; // 1280 (WARP/Mobile) or 1420
  killSwitch: boolean; // قطع کامل اینترنت در صورت قطعی وی‌پی‌ان
  splitTunnelingMode: 'all' | 'bypass_iran' | 'only_selected';
  whitelistedIranianApps: string[]; // برنامه‌های بانکی و ایرانی

  dnsType: 'cloudflare_doh' | 'google_doh' | 'adguard_doh' | 'shecan_bypass' | 'custom';
  customDns: string;

  soundEffects: boolean;
  hapticFeedback: boolean;
  rainParticlesEnabled: boolean; // ذرات نم‌نم باران با تغییر رنگ هر ثانیه
  currentISP: ISPType;
}

export type ConnectionStatus = 
  | 'disconnected' 
  | 'connecting' 
  | 'connected' 
  | 'switching_to_national'
  | 'disconnecting';

export interface TrafficStats {
  downloadSpeed: number; // in KB/s or MB/s
  uploadSpeed: number;
  totalDownloadedBytes: number;
  totalUploadedBytes: number;
  currentPing: number;
  packetLoss: number;
  durationSeconds: number;
}
