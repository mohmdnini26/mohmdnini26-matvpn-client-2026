export interface CleanIpResult {
  ip: string;
  ping: number;
  packetLoss: number;
  downloadSpeedMbps: number;
  status: 'excellent' | 'good' | 'fair' | 'blocked';
  datacenter: string;
}

export const CLOUDFLARE_CLEAN_IPS: { ip: string; datacenter: string }[] = [
  { ip: '162.159.192.1', datacenter: 'Frankfurt (FRA)' },
  { ip: '162.159.193.10', datacenter: 'Istanbul (IST)' },
  { ip: '162.159.195.2', datacenter: 'Helsinki (HEL)' },
  { ip: '188.114.96.1', datacenter: 'Vienna (VIE)' },
  { ip: '188.114.97.2', datacenter: 'Amsterdam (AMS)' },
  { ip: '104.16.132.229', datacenter: 'London (LHR)' },
  { ip: '172.64.32.1', datacenter: 'Dubai (DXB)' },
  { ip: '108.162.193.1', datacenter: 'Frankfurt-2 (FRA)' },
  { ip: '141.101.90.1', datacenter: 'Madrid (MAD)' },
  { ip: '162.159.138.8', datacenter: 'Stockholm (ARN)' },
];

export async function scanCleanIps(
  onProgress: (scanned: number, total: number, latest: CleanIpResult) => void
): Promise<CleanIpResult[]> {
  const results: CleanIpResult[] = [];
  const total = CLOUDFLARE_CLEAN_IPS.length;

  for (let i = 0; i < total; i++) {
    const item = CLOUDFLARE_CLEAN_IPS[i];
    // Realistic simulation of ping and packet loss based on typical Iranian network conditions
    await new Promise((res) => setTimeout(res, 220 + Math.random() * 200));

    // Calculate simulated ping (50ms - 190ms)
    const basePing = 45 + Math.floor(Math.random() * 70);
    const packetLoss = Math.random() < 0.2 ? Math.floor(Math.random() * 8) : 0;
    const speed = parseFloat((12 + Math.random() * 38).toFixed(1));

    let status: CleanIpResult['status'] = 'good';
    if (basePing < 65 && packetLoss === 0) status = 'excellent';
    else if (packetLoss > 5 || basePing > 130) status = 'fair';

    const result: CleanIpResult = {
      ip: item.ip,
      ping: basePing,
      packetLoss,
      downloadSpeedMbps: speed,
      status,
      datacenter: item.datacenter,
    };

    results.push(result);
    onProgress(i + 1, total, result);
  }

  return results.sort((a, b) => a.ping - b.ping);
}

export interface IspDiagnosticResult {
  ispName: string;
  censorLevel: 'شدید (فیلترینگ سراسری)' | 'متوسط (مسدودی UDP و TLS)' | 'عادی (پروتکل‌های متداول باز)';
  nationalNetActive: boolean; // آیا اینترنت به حالت ملی درآمده؟
  recommendedProtocol: string;
  recommendedEngine: string;
  dpiBypassMethod: string;
  pingToNationalRelay: number;
  pingToInternational: number | null; // null if blocked
}

export function diagnoseIranNetwork(isp: string): IspDiagnosticResult {
  switch (isp) {
    case 'mci': // همراه اول
      return {
        ispName: 'همراه اول (MCI)',
        censorLevel: 'شدید (فیلترینگ سراسری)',
        nationalNetActive: false,
        recommendedProtocol: 'AmneziaWG / VLESS Reality + Fragment',
        recommendedEngine: 'امنزیا یا ریالیتی با تکه‌تکه‌سازی پکت (Fragment 1-3)',
        dpiBypassMethod: 'TLS Fragment + Fake SNI shaparak.ir',
        pingToNationalRelay: 34,
        pingToInternational: 68,
      };
    case 'mtn': // ایرانسل
      return {
        ispName: 'ایرانسل (MTN Irancell)',
        censorLevel: 'شدید (فیلترینگ سراسری)',
        nationalNetActive: false,
        recommendedProtocol: 'WARP+ Clean IP / Tor Snowflake',
        recommendedEngine: 'وارپ کلودفلر با پورت ۲۴۰۸ یا اسنوفلیک',
        dpiBypassMethod: 'Junk Packets + WireGuard Noise',
        pingToNationalRelay: 29,
        pingToInternational: 59,
      };
    case 'rightel': // رایتل
      return {
        ispName: 'رایتل (Rightel)',
        censorLevel: 'متوسط (مسدودی UDP و TLS)',
        recommendedProtocol: 'VLESS Reality gRPC / Psiphon SSH',
        recommendedEngine: 'وی‌لس ریالیتی با پکت‌های gRPC',
        nationalNetActive: false,
        dpiBypassMethod: 'gRPC Multiplexing + Chrome Fingerprint',
        pingToNationalRelay: 41,
        pingToInternational: 75,
      };
    default:
      return {
        ispName: 'کلیه اپراتورها (مخابرات / شاتل / زیتل)',
        censorLevel: 'متوسط (مسدودی UDP و TLS)',
        nationalNetActive: false,
        recommendedProtocol: 'AmneziaWG / WARP+ / National Relay',
        recommendedEngine: 'تونل امنزیا یا رله معکوس اینترنت ملی',
        dpiBypassMethod: 'Fragment 1-3, Delay 15ms + DoH Cloudflare',
        pingToNationalRelay: 25,
        pingToInternational: 62,
      };
  }
}
