import React from 'react';
import { VPNProtocol } from '../types/vpn';

interface VpnBrandLogoProps {
  protocol: VPNProtocol | string;
  size?: number;
  className?: string;
}

export const VpnBrandLogo: React.FC<VpnBrandLogoProps> = ({
  protocol,
  size = 20,
  className = ''
}) => {
  switch (protocol) {
    // 1. Cloudflare WARP
    case 'warp':
      return (
        <svg width={size} height={size} viewBox="0 0 32 32" fill="none" className={className}>
          <path
            d="M23.5 15.2C22.9 11.8 19.9 9.2 16.3 9.2c-3.1 0-5.7 1.9-6.7 4.7C8.1 14.2 7 15.6 7 17.3c0 2.2 1.8 4 4 4h12.5c2.5 0 4.5-2 4.5-4.5 0-2.3-1.7-4.2-4-4.5l-.5-.1z"
            fill="#F38020"
          />
          <path
            d="M16 11.5L12 17.5h3.5v5l4-6H16v-5z"
            fill="#FAAE40"
          />
        </svg>
      );

    // 2. WARP-in-WARP (وارپ در وارپ دو لایه)
    case 'warp_in_warp':
      return (
        <svg width={size} height={size} viewBox="0 0 32 32" fill="none" className={className}>
          {/* Back Cloud */}
          <path
            d="M21 12c-.4-2.5-2.6-4.4-5.3-4.4-2.3 0-4.3 1.4-5 3.5C9.6 11.3 8.7 12.3 8.7 13.6c0 1.6 1.3 3 3 3H21c1.9 0 3.4-1.5 3.4-3.4 0-1.7-1.3-3.1-3-3.4l-.4.2z"
            fill="#ff7700"
            opacity="0.7"
          />
          {/* Front Cloud */}
          <path
            d="M25 18c-.4-2.5-2.6-4.4-5.3-4.4-2.3 0-4.3 1.4-5 3.5C13.6 17.3 12.7 18.3 12.7 19.6c0 1.6 1.3 3 3 3H25c1.9 0 3.4-1.5 3.4-3.4 0-1.7-1.3-3.1-3-3.4l-.4.2z"
            fill="#ffe600"
          />
          {/* Lightning Bolt Connector */}
          <path d="M17 14l-3 5h3v4l4-5h-3v-4z" fill="#ff2d78" />
        </svg>
      );

    // 3. V2Ray / Xray
    case 'v2ray':
      return (
        <svg width={size} height={size} viewBox="0 0 32 32" fill="none" className={className}>
          <rect width="32" height="32" rx="7" fill="#1b1c2b" />
          <path
            d="M8 8l8 16 8-16h-4l-4 9-4-9H8z"
            fill="url(#v2rayGrad)"
          />
          <path d="M16 19l4-11h-2l-2 6-2-6h-2l4 11z" fill="#ff2d78" />
          <defs>
            <linearGradient id="v2rayGrad" x1="8" y1="8" x2="24" y2="24">
              <stop stopColor="#ff2d78" />
              <stop offset="1" stopColor="#00e5ff" />
            </linearGradient>
          </defs>
        </svg>
      );

    // 4. Sing-Box (ضد فیلتر سینگ‌باکس)
    case 'singbox':
      return (
        <svg width={size} height={size} viewBox="0 0 32 32" fill="none" className={className}>
          <rect width="32" height="32" rx="7" fill="#1a1c22" />
          <path d="M16 6L7 11v10l9 5 9-5V11L16 6z" fill="#ffe600" fillOpacity="0.25" stroke="#ffe600" strokeWidth="1.8" />
          <path d="M16 6v10M7 11l9 5 9-5" stroke="#ffe600" strokeWidth="1.8" />
          <circle cx="16" cy="16" r="3" fill="#ff2d78" />
        </svg>
      );

    // 5. Amnezia VPN (امنزیا)
    case 'amnezia':
      return (
        <svg width={size} height={size} viewBox="0 0 32 32" fill="none" className={className}>
          <rect width="32" height="32" rx="7" fill="#0e2316" />
          <path
            d="M16 6l9 4v7c0 5.5-3.8 10.7-9 12-5.2-1.3-9-6.5-9-12v-7l9-4z"
            fill="#00ff66"
            fillOpacity="0.25"
            stroke="#00ff66"
            strokeWidth="1.8"
          />
          <circle cx="16" cy="15" r="3" fill="#00ff66" />
          <path d="M14.5 17h3l-.5 4h-2l-.5-4z" fill="#00ff66" />
        </svg>
      );

    // 6. Tor Network
    case 'tor':
      return (
        <svg width={size} height={size} viewBox="0 0 32 32" fill="none" className={className}>
          <rect width="32" height="32" rx="7" fill="#25122b" />
          <path
            d="M16 7C11 7 7 11 7 16s4 9 9 9 9-4 9-9-4-9-9-9z"
            stroke="#a855f7"
            strokeWidth="2"
          />
          <path
            d="M16 11c-2.8 0-5 2.2-5 5s2.2 5 5 5 5-2.2 5-5-2.2-5-5-5z"
            stroke="#c084fc"
            strokeWidth="1.8"
          />
          <circle cx="16" cy="16" r="2" fill="#ffe600" />
        </svg>
      );

    // 7. Psiphon (سایفون)
    case 'psiphon':
      return (
        <svg width={size} height={size} viewBox="0 0 32 32" fill="none" className={className}>
          <rect width="32" height="32" rx="7" fill="#0d1b2a" />
          <circle cx="16" cy="16" r="10" stroke="#00e5ff" strokeWidth="2" />
          <path d="M12 21V11h5c2.8 0 4 1.5 4 3.5s-1.2 3.5-4 3.5h-3v3h-2z" fill="#ffffff" />
          <circle cx="15.5" cy="14.5" r="1.5" fill="#00e5ff" />
        </svg>
      );

    // 8. WireGuard (وایرگارد)
    case 'wireguard':
      return (
        <svg width={size} height={size} viewBox="0 0 32 32" fill="none" className={className}>
          <rect width="32" height="32" rx="7" fill="#2a0f12" />
          <path
            d="M16 6C10.5 6 6 10.5 6 16c0 4.2 2.6 7.8 6.3 9.3.4.1.6-.2.6-.4v-1.6c-2.5.5-3-1.1-3-1.1-.4-1.1-1-1.4-1-1.4-.8-.6.1-.6.1-.6.9.1 1.4.9 1.4.9.8 1.4 2.1 1 2.6.8.1-.6.3-1 .6-1.3-2-.2-4.1-1-4.1-4.5 0-1 .4-1.8 1-2.5-.1-.2-.4-1.2.1-2.4 0 0 .8-.3 2.5.9.8-.2 1.6-.3 2.4-.3.8 0 1.6.1 2.4.3 1.8-1.2 2.5-.9 2.5-.9.5 1.2.2 2.2.1 2.4.6.7 1 1.5 1 2.5 0 3.5-2.1 4.3-4.1 4.5.3.3.6.9.6 1.7v2.6c0 .2.2.5.6.4 3.7-1.5 6.3-5.1 6.3-9.3 0-5.5-4.5-10-10-10z"
            fill="#e11d48"
          />
        </svg>
      );

    // 9. Windscribe (وینداسکرایب)
    case 'windscribe':
      return (
        <svg width={size} height={size} viewBox="0 0 32 32" fill="none" className={className}>
          <rect width="32" height="32" rx="7" fill="#121829" />
          <path
            d="M9 10l3.5 12h2L16 15l1.5 7h2L23 10h-2.5l-1.5 8-1.5-8h-3l-1.5 8-1.5-8H9z"
            fill="#ff7700"
          />
          <circle cx="16" cy="10" r="1.5" fill="#00e5ff" />
        </svg>
      );

    // 10. OpenVPN (اوپن‌وی‌پی‌ان)
    case 'openvpn':
      return (
        <svg width={size} height={size} viewBox="0 0 32 32" fill="none" className={className}>
          <rect width="32" height="32" rx="7" fill="#201712" />
          <circle cx="16" cy="16" r="9" stroke="#ea580c" strokeWidth="2.2" />
          <path d="M16 11a3 3 0 00-2 5.2V19h4v-2.8A3 3 0 0016 11z" fill="#ea580c" />
          <path d="M11 16h2M19 16h2" stroke="#ea580c" strokeWidth="2" strokeLinecap="round" />
        </svg>
      );

    // 11. Proton VPN (پروتون)
    case 'proton':
      return (
        <svg width={size} height={size} viewBox="0 0 32 32" fill="none" className={className}>
          <rect width="32" height="32" rx="7" fill="#1e152d" />
          <path
            d="M16 7L8 12v7c0 5 3.5 9.5 8 11 4.5-1.5 8-6 8-11v-7l-8-5z"
            stroke="#a855f7"
            strokeWidth="2"
            fill="#a855f7"
            fillOpacity="0.2"
          />
          <path d="M16 11v11M12 16h8" stroke="#00ff66" strokeWidth="2" strokeLinecap="round" />
        </svg>
      );

    // 12. GitHub Tunnel (گیت‌هاب تانل)
    case 'github_tunnel':
      return (
        <svg width={size} height={size} viewBox="0 0 32 32" fill="none" className={className}>
          <rect width="32" height="32" rx="7" fill="#181c24" />
          <path
            d="M16 6C10.5 6 6 10.5 6 16c0 4.4 2.9 8.2 6.8 9.5.5.1.7-.2.7-.5v-1.7c-2.8.6-3.4-1.4-3.4-1.4-.5-1.2-1.1-1.5-1.1-1.5-.9-.6.1-.6.1-.6 1 .1 1.5 1 1.5 1 .9 1.5 2.3 1.1 2.9.8.1-.7.4-1.1.7-1.4-2.2-.2-4.6-1.1-4.6-5 0-1.1.4-2 1-2.7-.1-.3-.4-1.3.1-2.7 0 0 .8-.3 2.8 1 .8-.2 1.7-.3 2.5-.3.8 0 1.7.1 2.5.3 2-1.3 2.8-1 2.8-1 .5 1.4.2 2.4.1 2.7.6.7 1 1.6 1 2.7 0 3.9-2.3 4.7-4.6 5 .4.3.7.9.7 1.9v2.8c0 .3.2.6.7.5 4-1.3 6.8-5.1 6.8-9.5 0-5.5-4.5-10-10-10z"
            fill="#ffffff"
          />
        </svg>
      );

    // 13. Telegram MTProto (تلگرام)
    case 'telegram_proxy':
      return (
        <svg width={size} height={size} viewBox="0 0 32 32" fill="none" className={className}>
          <rect width="32" height="32" rx="7" fill="#0088cc" />
          <path
            d="M7.5 15.5l14-6-4.5 15-3.5-4.5-2.5 2.5-.5-4.5 9-8.5-11 5.5-1-4z"
            fill="#ffffff"
          />
        </svg>
      );

    // 14. Lantern (لنترن)
    case 'lantern':
      return (
        <svg width={size} height={size} viewBox="0 0 32 32" fill="none" className={className}>
          <rect width="32" height="32" rx="7" fill="#261b10" />
          <path d="M16 6v3M12 9h8l2 6-2 9h-8l-2-9 2-6z" stroke="#ff7700" strokeWidth="1.8" />
          <line x1="16" y1="12" x2="16" y2="20" stroke="#ffe600" strokeWidth="2" />
        </svg>
      );

    // 15. National Intranet Relay (پل اینترنت ملی)
    case 'iran_relay':
    default:
      return (
        <svg width={size} height={size} viewBox="0 0 32 32" fill="none" className={className}>
          <rect width="32" height="32" rx="7" fill="#0a1a12" stroke="#00ff66" strokeWidth="1.2" />
          <rect x="7" y="9" width="18" height="4" fill="#22c55e" rx="1" />
          <rect x="7" y="13" width="18" height="6" fill="#ffffff" />
          <rect x="7" y="19" width="18" height="4" fill="#ef4444" rx="1" />
          <circle cx="16" cy="16" r="2.2" fill="#ef4444" />
        </svg>
      );
  }
};
