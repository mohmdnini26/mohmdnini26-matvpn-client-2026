import React from 'react';

interface RainbowIconProps {
  size?: number;
  className?: string;
  animate?: boolean;
  withGlow?: boolean;
}

export const RainbowIcon: React.FC<RainbowIconProps> = ({
  size = 64,
  className = '',
  animate = true,
  withGlow = true
}) => {
  return (
    <div 
      className={`relative inline-flex items-center justify-center select-none ${className}`}
      style={{ width: size, height: size }}
    >
      {/* Outer Rainbow Glow Aura */}
      {withGlow && (
        <div 
          className={`absolute inset-0 rounded-3xl opacity-75 blur-xl -z-10 ${animate ? 'animate-pulse' : ''}`}
          style={{
            background: 'radial-gradient(circle, rgba(255,45,120,0.5) 0%, rgba(255,119,0,0.4) 25%, rgba(255,230,0,0.3) 50%, rgba(0,255,102,0.4) 75%, rgba(0,229,255,0.4) 100%)'
          }}
        />
      )}

      {/* SVG 7-Color Rainbow Shield Emblem */}
      <svg
        width={size}
        height={size}
        viewBox="0 0 100 100"
        fill="none"
        xmlns="http://www.w3.org/2000/svg"
        className={`relative ${animate ? 'filter drop-shadow-[0_0_12px_rgba(255,45,120,0.6)]' : ''}`}
      >
        <defs>
          {/* 7-Color Rainbow Linear Gradient */}
          <linearGradient id="rainbow7" x1="0%" y1="0%" x2="100%" y2="100%">
            <stop offset="0%" stopColor="#ff2d78" />   {/* Neon Pink */}
            <stop offset="18%" stopColor="#ff7700" />  {/* Blazing Orange */}
            <stop offset="36%" stopColor="#ffe600" />  {/* Electric Yellow */}
            <stop offset="54%" stopColor="#00ff66" />  {/* Phosphor Green */}
            <stop offset="72%" stopColor="#00e5ff" />  {/* Cyan Aqua */}
            <stop offset="88%" stopColor="#3b82f6" />  {/* Electric Blue */}
            <stop offset="100%" stopColor="#a855f7" /> {/* Violet */}
          </linearGradient>

          {/* Reverse Rainbow for Depth */}
          <linearGradient id="rainbowReverse" x1="100%" y1="0%" x2="0%" y2="100%">
            <stop offset="0%" stopColor="#00e5ff" />
            <stop offset="30%" stopColor="#00ff66" />
            <stop offset="60%" stopColor="#ffe600" />
            <stop offset="80%" stopColor="#ff7700" />
            <stop offset="100%" stopColor="#ff2d78" />
          </linearGradient>

          {/* Core Obsidian Radial Shade */}
          <radialGradient id="darkCore" cx="50%" cy="50%" r="50%">
            <stop offset="0%" stopColor="#1a1c29" />
            <stop offset="70%" stopColor="#0b0c14" />
            <stop offset="100%" stopColor="#050608" />
          </radialGradient>
        </defs>

        {/* Outer Rounded Squircle Base (Obsidian with Rainbow Stroke) */}
        <rect
          x="6"
          y="6"
          width="88"
          height="88"
          rx="26"
          fill="url(#darkCore)"
          stroke="url(#rainbow7)"
          strokeWidth="3.5"
        />

        {/* Inner 7-Color Rainbow Ring */}
        <circle
          cx="50"
          cy="50"
          r="34"
          stroke="url(#rainbowReverse)"
          strokeWidth="3"
          strokeDasharray="6 4"
          className={animate ? 'animate-spin-slow origin-center' : ''}
        />

        {/* Security Shield Silhouette */}
        <path
          d="M50 20L68 28V46C68 59 59.5 70 50 75C40.5 70 32 59 32 46V28L50 20Z"
          fill="url(#rainbow7)"
          fillOpacity="0.22"
          stroke="url(#rainbow7)"
          strokeWidth="2.5"
          strokeLinejoin="round"
        />

        {/* Fast Lightning / Key Bolt in Center */}
        <path
          d="M53 28L40 48H49L46 68L60 46H50L53 28Z"
          fill="url(#rainbow7)"
          stroke="#ffffff"
          strokeWidth="1.2"
          strokeLinejoin="round"
        />

        {/* Tiny Accent Sparkles */}
        <circle cx="28" cy="28" r="2" fill="#ffe600" />
        <circle cx="72" cy="72" r="2.5" fill="#00ff66" />
        <circle cx="73" cy="27" r="2" fill="#ff2d78" />
        <circle cx="27" cy="73" r="2" fill="#00e5ff" />
      </svg>
    </div>
  );
};
