import React from 'react';
import { 
  X, Sliders, Shield, Zap, Split, Lock, Radio, Cpu, Volume2, Globe2, 
  Shuffle, CloudRain, Send, GitBranch, Search, Globe, ChevronLeft, Check, Sparkles,
  QrCode, Activity
} from 'lucide-react';
import { VPNSettings } from '../types/vpn';
import { VpnBrandLogo } from './VpnBrandLogos';

interface AdvancedSettingsModalProps {
  isOpen: boolean;
  onClose: () => void;
  settings: VPNSettings;
  onUpdateSettings: (newSettings: Partial<VPNSettings>) => void;
  onOpenTelegramModal?: () => void;
  onOpenCleanIpModal?: () => void;
  onOpenNationalModal?: () => void;
  onOpenSplitTunnelModal?: () => void;
  onOpenConfigManager?: () => void;
  onOpenDiagnostics?: () => void;
  onSelectGitHubTunnel?: () => void;
  onSelectWarpInWarp?: () => void;
}

export const AdvancedSettingsModal: React.FC<AdvancedSettingsModalProps> = ({
  isOpen,
  onClose,
  settings,
  onUpdateSettings,
  onOpenTelegramModal,
  onOpenCleanIpModal,
  onOpenNationalModal,
  onOpenSplitTunnelModal,
  onOpenConfigManager,
  onOpenDiagnostics,
  onSelectGitHubTunnel,
  onSelectWarpInWarp,
}) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center bg-black/85 backdrop-blur-sm p-0 sm:p-4 animate-in fade-in duration-200">
      <div className="w-full sm:max-w-md bg-[#0e101a] border border-[#ff2d78]/30 rounded-t-3xl sm:rounded-3xl max-h-[92vh] flex flex-col overflow-hidden shadow-[0_0_40px_rgba(255,45,120,0.15)]">
        {/* Header */}
        <div className="p-4 border-b border-slate-800 flex items-center justify-between bg-gradient-to-r from-[#ff2d78]/10 via-[#0e101a] to-transparent">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-xl bg-[#ff2d78]/20 border border-[#ff2d78]/40 flex items-center justify-center text-[#ff2d78]">
              <Sliders size={20} />
            </div>
            <div>
              <h3 className="font-bold text-slate-100 text-sm">تنظیمات و ابزارهای پیشرفته</h3>
              <p className="text-[11px] text-slate-400">پروکسی تلگرام، تانل‌ها، اسکنر IP و موتور ضد DPI</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="w-8 h-8 rounded-full bg-slate-800/80 text-slate-400 hover:text-white flex items-center justify-center cursor-pointer"
          >
            <X size={18} />
          </button>
        </div>

        {/* Scrollable Settings & Tools List */}
        <div className="flex-1 overflow-y-auto p-4 space-y-4">
          
          {/* ========================================================
              CATEGORY 1: پروکسی‌ها و تانل‌های ویژه (منتقل‌شده از صفحه اول)
              ======================================================== */}
          <div className="space-y-2">
            <span className="text-xs font-bold text-slate-200 flex items-center gap-1.5">
              <span className="w-2 h-2 rounded-full bg-[#00e5ff]" />
              <span>پروکسی‌ها و ابزارهای ضد فیلتر ویژه:</span>
            </span>

            {/* 1.1: Telegram MTProto Proxy Fake TLS */}
            <div 
              onClick={() => {
                onClose();
                onOpenTelegramModal?.();
              }}
              className="p-3 rounded-2xl bg-[#121422] border border-slate-800 hover:border-[#00e5ff] hover:bg-[#00e5ff]/5 transition-all cursor-pointer flex items-center justify-between group"
            >
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-xl bg-[#0088cc]/20 border border-[#0088cc]/40 flex items-center justify-center text-[#0088cc] shrink-0">
                  <Send size={18} />
                </div>
                <div>
                  <div className="flex items-center gap-2">
                    <span className="text-xs font-bold text-slate-100">پروکسی ضد فیلتر تلگرام</span>
                    <span className="text-[9px] bg-[#00e5ff]/20 text-[#00e5ff] font-bold px-1.5 py-0.2 rounded border border-[#00e5ff]/30">
                      Fake TLS
                    </span>
                  </div>
                  <span className="text-[10px] text-slate-400 block mt-0.5">
                    اتصال مستقیم ۱ کلیکه تلگرام بدون قطعی و با سکرت ee گوگل
                  </span>
                </div>
              </div>
              <ChevronLeft size={16} className="text-slate-500 group-hover:text-white transition-colors" />
            </div>

            {/* 1.2: WARP-in-WARP (وارپ در وارپ) */}
            <div 
              onClick={() => {
                onSelectWarpInWarp?.();
                onClose();
              }}
              className="p-3 rounded-2xl bg-[#121422] border border-slate-800 hover:border-[#ffe600] hover:bg-[#ffe600]/5 transition-all cursor-pointer flex items-center justify-between group"
            >
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-xl bg-[#090a14] border border-slate-700/80 flex items-center justify-center p-1 shrink-0">
                  <VpnBrandLogo protocol="warp_in_warp" size={24} />
                </div>
                <div>
                  <div className="flex items-center gap-2">
                    <span className="text-xs font-bold text-slate-100">وارپ در وارپ (WARP on WARP دو مرحله‌ای)</span>
                    <span className="text-[9px] bg-[#ffe600] text-slate-950 font-black px-1.5 py-0.2 rounded">
                      ضد فیلتر
                    </span>
                  </div>
                  <span className="text-[10px] text-slate-400 block mt-0.5">
                    کپسوله‌سازی دو لایه کلودفلر برای عبور از فیلترینگ دکل‌های همراه
                  </span>
                </div>
              </div>
              <ChevronLeft size={16} className="text-slate-500 group-hover:text-white transition-colors" />
            </div>

            {/* 1.3: GitHub Cloud Tunnel Relay */}
            <div 
              onClick={() => {
                onSelectGitHubTunnel?.();
                onClose();
              }}
              className="p-3 rounded-2xl bg-[#121422] border border-slate-800 hover:border-[#00ff66] hover:bg-[#00ff66]/5 transition-all cursor-pointer flex items-center justify-between group"
            >
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-xl bg-[#090a14] border border-slate-700/80 flex items-center justify-center p-1 shrink-0">
                  <VpnBrandLogo protocol="github_tunnel" size={24} />
                </div>
                <div>
                  <div className="flex items-center gap-2">
                    <span className="text-xs font-bold text-slate-100">گیت‌هاب تانل ابری (دامنه سفید)</span>
                    <span className="text-[9px] bg-[#00ff66]/20 text-[#00ff66] font-bold px-1.5 py-0.2 rounded border border-[#00ff66]/30">
                      دانشگاهی
                    </span>
                  </div>
                  <span className="text-[10px] text-slate-400 block mt-0.5">
                    اتصال از طریق دامنه‌های مجاز گیت‌هاب که هیچ‌گاه مسدود نمی‌شوند
                  </span>
                </div>
              </div>
              <ChevronLeft size={16} className="text-slate-500 group-hover:text-white transition-colors" />
            </div>

            {/* 1.4: Clean IP Scanner */}
            <div 
              onClick={() => {
                onClose();
                onOpenCleanIpModal?.();
              }}
              className="p-3 rounded-2xl bg-[#121422] border border-slate-800 hover:border-[#ff7700] hover:bg-[#ff7700]/5 transition-all cursor-pointer flex items-center justify-between group"
            >
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-xl bg-[#ff7700]/15 border border-[#ff7700]/30 flex items-center justify-center text-[#ff7700] shrink-0">
                  <Search size={18} />
                </div>
                <div>
                  <div className="flex items-center gap-2">
                    <span className="text-xs font-bold text-slate-100">اسکنر آی‌پی تمیز کلودفلر و وارپ</span>
                    <span className="text-[9px] bg-[#ff7700]/20 text-[#ff7700] font-bold px-1.5 py-0.2 rounded border border-[#ff7700]/30">
                      پینگ کم
                    </span>
                  </div>
                  <span className="text-[10px] text-slate-400 block mt-0.5">
                    پیدا کردن آی‌پی‌های بدون فیلتر و با پینگ زیر ۶۰ms در اپراتور شما
                  </span>
                </div>
              </div>
              <ChevronLeft size={16} className="text-slate-500 group-hover:text-white transition-colors" />
            </div>

            {/* 1.5: National Intranet Bridge */}
            <div 
              onClick={() => {
                onClose();
                onOpenNationalModal?.();
              }}
              className="p-3 rounded-2xl bg-[#121422] border border-slate-800 hover:border-[#00ff66] hover:bg-[#00ff66]/5 transition-all cursor-pointer flex items-center justify-between group"
            >
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-xl bg-[#00ff66]/15 border border-[#00ff66]/30 flex items-center justify-center text-[#00ff66] shrink-0">
                  <Zap size={18} />
                </div>
                <div>
                  <div className="flex items-center gap-2">
                    <span className="text-xs font-bold text-slate-100">سوییچ اضطراری اینترنت ملی</span>
                    <span className="text-[9px] bg-[#00ff66] text-slate-950 font-black px-1.5 py-0.2 rounded">
                      ضد قطعی
                    </span>
                  </div>
                  <span className="text-[10px] text-slate-400 block mt-0.5">
                    اتصال خودکار به تونل معکوس داخلی هنگام ضعیف شدن یا قطعی اینترنت خارجی
                  </span>
                </div>
              </div>
              <ChevronLeft size={16} className="text-slate-500 group-hover:text-white transition-colors" />
            </div>

            {/* 1.6: Split Tunneling */}
            <div 
              onClick={() => {
                onClose();
                onOpenSplitTunnelModal?.();
              }}
              className="p-3 rounded-2xl bg-[#121422] border border-slate-800 hover:border-[#ff2d78] hover:bg-[#ff2d78]/5 transition-all cursor-pointer flex items-center justify-between group"
            >
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-xl bg-[#ff2d78]/15 border border-[#ff2d78]/30 flex items-center justify-center text-[#ff2d78] shrink-0">
                  <Split size={18} />
                </div>
                <div>
                  <div className="flex items-center gap-2">
                    <span className="text-xs font-bold text-slate-100">تفکیک برنامه‌ها (Split Tunneling)</span>
                    <span className="text-[9px] bg-[#ff2d78]/20 text-[#ff2d78] font-bold px-1.5 py-0.2 rounded border border-[#ff2d78]/30">
                      بانک و اسنپ
                    </span>
                  </div>
                  <span className="text-[10px] text-slate-400 block mt-0.5">
                    خروج همراه‌بانک‌ها، اسنپ و سامانه‌های داخلی از فیلترشکن با تعرفه نیم‌بها
                  </span>
                </div>
              </div>
              <ChevronLeft size={16} className="text-slate-500 group-hover:text-white transition-colors" />
            </div>

            {/* 1.7: Config & QR Manager */}
            <div 
              onClick={() => {
                onClose();
                onOpenConfigManager?.();
              }}
              className="p-3 rounded-2xl bg-[#121422] border border-slate-800 hover:border-[#ff2d78] hover:bg-[#ff2d78]/5 transition-all cursor-pointer flex items-center justify-between group"
            >
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-xl bg-[#ff2d78]/15 border border-[#ff2d78]/30 flex items-center justify-center text-[#ff2d78] shrink-0">
                  <QrCode size={18} />
                </div>
                <div>
                  <div className="flex items-center gap-2">
                    <span className="text-xs font-bold text-slate-100">مدیریت کانفیگ و QR کد</span>
                    <span className="text-[9px] bg-[#ff2d78]/20 text-[#ff2d78] font-bold px-1.5 py-0.2 rounded border border-[#ff2d78]/30">
                      ورودی و خروجی
                    </span>
                  </div>
                  <span className="text-[10px] text-slate-400 block mt-0.5">
                    اسکن کدهای QR، وارد کردن لینک سابسکریپشن و به اشتراک‌گذاری کانفیگ‌ها
                  </span>
                </div>
              </div>
              <ChevronLeft size={16} className="text-slate-500 group-hover:text-white transition-colors" />
            </div>

            {/* 1.8: ISP Diagnostics Tool */}
            <div 
              onClick={() => {
                onClose();
                onOpenDiagnostics?.();
              }}
              className="p-3 rounded-2xl bg-[#121422] border border-slate-800 hover:border-[#00e5ff] hover:bg-[#00e5ff]/5 transition-all cursor-pointer flex items-center justify-between group"
            >
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-xl bg-[#00e5ff]/15 border border-[#00e5ff]/30 flex items-center justify-center text-[#00e5ff] shrink-0">
                  <Activity size={18} />
                </div>
                <div>
                  <div className="flex items-center gap-2">
                    <span className="text-xs font-bold text-slate-100">آنالیز و عیب‌یابی اپراتور (همراه، ایرانسل، مخابرات)</span>
                    <span className="text-[9px] bg-[#00e5ff]/20 text-[#00e5ff] font-bold px-1.5 py-0.2 rounded border border-[#00e5ff]/30">
                      تشخیص فیلترینگ
                    </span>
                  </div>
                  <span className="text-[10px] text-slate-400 block mt-0.5">
                    بررسی لایه‌های اختلال ISP و پیشنهاد بهترین سرور و پروتکل بدون قطعی
                  </span>
                </div>
              </div>
              <ChevronLeft size={16} className="text-slate-500 group-hover:text-white transition-colors" />
            </div>
          </div>

          {/* ========================================================
              CATEGORY 2: تنظیمات فنی و پروتکل‌ها
              ======================================================== */}
          <div className="pt-2 border-t border-slate-800/80 space-y-3">
            <span className="text-xs font-bold text-slate-200 flex items-center gap-1.5">
              <span className="w-2 h-2 rounded-full bg-[#ff2d78]" />
              <span>تنظیمات هسته ضد فیلترینگ و DPI:</span>
            </span>

            {/* Section 1: TLS Fragment (تکه‌تکه سازی پکت‌ها) */}
            <div className="p-3.5 rounded-2xl bg-[#121422] border border-slate-800 space-y-3">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <Split size={17} className="text-[#ffe600]" />
                  <div>
                    <span className="text-xs font-bold text-slate-100 block">پکت فرگمنت (TLS Fragment ضد DPI)</span>
                    <span className="text-[10px] text-slate-400">شکستن بسته هندشیک TLS برای کور کردن فیلتر شکن‌های مخابرات و همراه اول</span>
                  </div>
                </div>
                <label className="relative inline-flex items-center cursor-pointer">
                  <input
                    type="checkbox"
                    checked={settings.fragmentEnabled}
                    onChange={(e) => onUpdateSettings({ fragmentEnabled: e.target.checked })}
                    className="sr-only peer"
                  />
                  <div className="w-11 h-6 bg-slate-700 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-[#ffe600]"></div>
                </label>
              </div>

              {settings.fragmentEnabled && (
                <div className="grid grid-cols-2 gap-2 pt-2 border-t border-slate-800/70">
                  <div>
                    <label className="text-[10px] text-slate-400 block mb-1">طول قطعه فرگمنت (بایت):</label>
                    <select
                      value={settings.fragmentLength}
                      onChange={(e) => onUpdateSettings({ fragmentLength: e.target.value })}
                      className="w-full bg-[#181a2b] border border-slate-700 rounded-lg px-2 py-1.5 text-xs text-slate-200 focus:outline-none"
                    >
                      <option value="1-3">۱ الی ۳ بایت (توصیه شده)</option>
                      <option value="1-5">۱ الی ۵ بایت (سریع)</option>
                      <option value="2-4">۲ الی ۴ بایت (ضد فایروال سنگین)</option>
                    </select>
                  </div>
                  <div>
                    <label className="text-[10px] text-slate-400 block mb-1">تاخیر ارسال پکت (میلی‌ثانیه):</label>
                    <select
                      value={settings.fragmentInterval}
                      onChange={(e) => onUpdateSettings({ fragmentInterval: e.target.value })}
                      className="w-full bg-[#181a2b] border border-slate-700 rounded-lg px-2 py-1.5 text-xs text-slate-200 focus:outline-none"
                    >
                      <option value="10-20">۱۰ تا ۲۰ میلی‌ثانیه</option>
                      <option value="15-25">۱۵ تا ۲۵ میلی‌ثانیه (بهترین پایداری)</option>
                      <option value="30-50">۳۰ تا ۵۰ میلی‌ثانیه (حالت اختلال شدید)</option>
                    </select>
                  </div>
                </div>
              )}
            </div>

            {/* Section 2: AmneziaWG Junk Packets */}
            <div className="p-3.5 rounded-2xl bg-[#121422] border border-slate-800 space-y-3">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <Shuffle size={17} className="text-[#00ff66]" />
                  <div>
                    <span className="text-xs font-bold text-slate-100 block">پکت‌های تصادفی امنزیا (AmneziaWG Junk)</span>
                    <span className="text-[10px] text-slate-400">تزریق نویز بایت تصادفی قبل از هندشیک وایرگارد</span>
                  </div>
                </div>
                <label className="relative inline-flex items-center cursor-pointer">
                  <input
                    type="checkbox"
                    checked={settings.amneziaJunkPackets}
                    onChange={(e) => onUpdateSettings({ amneziaJunkPackets: e.target.checked })}
                    className="sr-only peer"
                  />
                  <div className="w-11 h-6 bg-slate-700 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-[#00ff66]"></div>
                </label>
              </div>
              {settings.amneziaJunkPackets && (
                <div className="text-[10px] text-slate-400 bg-[#090a12] p-2 rounded-lg border border-slate-800">
                  پیکربندی فعال: <span className="font-mono text-[#00ff66]">Jc=4, Jmin=50, Jmax=1000, S1=15, S2=30</span> (تست‌شده روی دکل‌های همراه اول و ایرانسل).
                </div>
              )}
            </div>

            {/* Section 3: MTU Optimizer */}
            <div className="p-3.5 rounded-2xl bg-[#121422] border border-slate-800 space-y-2">
              <div className="flex items-center justify-between">
                <span className="text-xs font-bold text-slate-100 flex items-center gap-2">
                  <Cpu size={16} className="text-[#ff7700]" />
                  <span>بهینه‌ساز اندازه بسته (MTU):</span>
                </span>
                <span className="text-xs font-mono font-bold text-[#ff7700]">{settings.mtu} Bytes</span>
              </div>
              <div className="grid grid-cols-4 gap-1.5 pt-1">
                {[1280, 1360, 1420, 1500].map((val) => (
                  <button
                    key={val}
                    onClick={() => onUpdateSettings({ mtu: val })}
                    className={`py-1.5 rounded-lg text-xs font-mono transition-colors cursor-pointer ${
                      settings.mtu === val
                        ? 'bg-[#ff7700] text-slate-950 font-bold'
                        : 'bg-[#181a2b] text-slate-400 hover:text-white'
                    }`}
                  >
                    {val}
                    {val === 1280 && <span className="block text-[8px] font-sans">همراه اول</span>}
                    {val === 1420 && <span className="block text-[8px] font-sans">استاندارد</span>}
                  </button>
                ))}
              </div>
            </div>

            {/* Section 4: DNS-over-HTTPS (DoH) */}
            <div className="p-3.5 rounded-2xl bg-[#121422] border border-slate-800 space-y-2.5">
              <span className="text-xs font-bold text-slate-100 flex items-center gap-2">
                <Globe2 size={16} className="text-[#00e5ff]" />
                <span>پروتکل امن DNS (رمزنگاری DoH):</span>
              </span>
              <div className="grid grid-cols-2 gap-2">
                {[
                  { id: 'cloudflare_doh', label: 'Cloudflare (1.1.1.1)' },
                  { id: 'google_doh', label: 'Google DoH (8.8.8.8)' },
                  { id: 'adguard_doh', label: 'AdGuard (ضد تبلیغات)' },
                  { id: 'shecan_bypass', label: 'شکن (ضد تحریم داخلی)' },
                ].map((dns) => (
                  <button
                    key={dns.id}
                    onClick={() => onUpdateSettings({ dnsType: dns.id as VPNSettings['dnsType'] })}
                    className={`p-2 rounded-xl border text-xs text-right transition-colors cursor-pointer ${
                      settings.dnsType === dns.id
                        ? 'bg-[#00e5ff]/15 border-[#00e5ff]/50 text-white font-bold'
                        : 'bg-[#181a2b] border-slate-800 text-slate-400 hover:text-slate-200'
                    }`}
                  >
                    {dns.label}
                  </button>
                ))}
              </div>
            </div>

            {/* Section 5: Kill Switch & Auto Failover */}
            <div className="p-3.5 rounded-2xl bg-[#121422] border border-slate-800 space-y-3">
              <div className="flex items-center justify-between">
                <div>
                  <span className="text-xs font-bold text-slate-100 block">کیل سوییچ (Kill Switch)</span>
                  <span className="text-[10px] text-slate-400">قطع فوری کل اینترنت در صورت قطع اتصال وی‌پی‌ان</span>
                </div>
                <label className="relative inline-flex items-center cursor-pointer">
                  <input
                    type="checkbox"
                    checked={settings.killSwitch}
                    onChange={(e) => onUpdateSettings({ killSwitch: e.target.checked })}
                    className="sr-only peer"
                  />
                  <div className="w-11 h-6 bg-slate-700 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-[#ff2d78]"></div>
                </label>
              </div>

              <div className="pt-2 border-t border-slate-800 flex items-center justify-between">
                <div>
                  <span className="text-xs font-bold text-slate-100 block">سوئیچ خودکار بین پروتکل‌ها (Auto-Failover)</span>
                  <span className="text-[10px] text-slate-400">در صورت اختلال یا فیلتر شدن یک پروتکل خودکار جابجا شود</span>
                </div>
                <label className="relative inline-flex items-center cursor-pointer">
                  <input
                    type="checkbox"
                    checked={settings.autoFailoverProtocols}
                    onChange={(e) => onUpdateSettings({ autoFailoverProtocols: e.target.checked })}
                    className="sr-only peer"
                  />
                  <div className="w-11 h-6 bg-slate-700 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-[#00ff66]"></div>
                </label>
              </div>
            </div>

            {/* Section 6: Sound & Haptics */}
            <div className="p-3 rounded-2xl bg-[#121422] border border-slate-800 flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Volume2 size={16} className="text-[#a855f7]" />
                <span className="text-xs font-medium text-slate-200">افکت‌های صوتی فضایی سایبرپانک</span>
              </div>
              <label className="relative inline-flex items-center cursor-pointer">
                <input
                  type="checkbox"
                  checked={settings.soundEffects}
                  onChange={(e) => onUpdateSettings({ soundEffects: e.target.checked })}
                  className="sr-only peer"
                />
                <div className="w-11 h-6 bg-slate-700 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-[#a855f7]"></div>
              </label>
            </div>

            {/* Section 7: Cyber Rain Particles */}
            <div className="p-3 rounded-2xl bg-[#121422] border border-slate-800 flex items-center justify-between">
              <div className="flex items-center gap-2">
                <CloudRain size={16} className="text-[#ff2d78]" />
                <div>
                  <span className="text-xs font-medium text-slate-200 block">ذرات نم‌نم باران نئونی</span>
                  <span className="text-[10px] text-slate-400">رنگ صورتی قبل اتصال • تغییر رنگ هر ۱ ثانیه پس از اتصال</span>
                </div>
              </div>
              <label className="relative inline-flex items-center cursor-pointer">
                <input
                  type="checkbox"
                  checked={settings.rainParticlesEnabled}
                  onChange={(e) => onUpdateSettings({ rainParticlesEnabled: e.target.checked })}
                  className="sr-only peer"
                />
                <div className="w-11 h-6 bg-slate-700 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-[#ff2d78]"></div>
              </label>
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="p-3.5 bg-[#0a0b12] border-t border-slate-800/80 flex items-center justify-end">
          <button
            onClick={onClose}
            className="px-5 py-2 rounded-xl bg-gradient-to-r from-[#ff2d78] to-[#ff7700] text-white font-bold text-xs hover:opacity-90 transition-opacity cursor-pointer"
          >
            تایید و ذخیره تنظیمات
          </button>
        </div>
      </div>
    </div>
  );
};
