import React, { useState } from 'react';
import { X, Search, Zap, Check, ShieldCheck, RefreshCw, Cpu } from 'lucide-react';
import { scanCleanIps, CleanIpResult } from '../utils/cleanIpScanner';

interface CleanIpScannerModalProps {
  isOpen: boolean;
  onClose: () => void;
  onApplyCleanIp: (ip: string) => void;
}

export const CleanIpScannerModal: React.FC<CleanIpScannerModalProps> = ({
  isOpen,
  onClose,
  onApplyCleanIp
}) => {
  const [isScanning, setIsScanning] = useState(false);
  const [results, setResults] = useState<CleanIpResult[]>([]);
  const [progress, setProgress] = useState({ scanned: 0, total: 10 });

  if (!isOpen) return null;

  const handleStartScan = async () => {
    setIsScanning(true);
    setResults([]);
    try {
      const scannedList = await scanCleanIps((scanned, total, latest) => {
        setProgress({ scanned, total });
        setResults((prev) => [...prev, latest].sort((a, b) => a.ping - b.ping));
      });
      setResults(scannedList);
    } finally {
      setIsScanning(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center bg-black/85 backdrop-blur-sm p-0 sm:p-4 animate-in fade-in duration-200">
      <div className="w-full sm:max-w-md bg-[#0e101a] border border-[#ffe600]/30 rounded-t-3xl sm:rounded-3xl max-h-[90vh] flex flex-col overflow-hidden shadow-[0_0_40px_rgba(255,230,0,0.15)]">
        {/* Header */}
        <div className="p-4 border-b border-slate-800 flex items-center justify-between bg-gradient-to-r from-[#ffe600]/10 via-[#0e101a] to-transparent">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-xl bg-[#ffe600]/20 border border-[#ffe600]/40 flex items-center justify-center text-[#ffe600]">
              <Search size={20} />
            </div>
            <div>
              <h3 className="font-bold text-slate-100 text-sm">اسکنر آی‌پی تمیز کلودفلر و وارپ</h3>
              <p className="text-[11px] text-slate-400">یافتن IPهای بدون فیلتر و بدون پکت‌لاس در ایران</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="w-8 h-8 rounded-full bg-slate-800/80 text-slate-400 hover:text-white flex items-center justify-center"
          >
            <X size={18} />
          </button>
        </div>

        {/* Action Bar */}
        <div className="p-4 bg-[#0a0b12] border-b border-slate-800/60 flex items-center justify-between">
          <div>
            <span className="text-xs font-bold text-slate-200 block">
              {isScanning ? `در حال اسکن... (${progress.scanned}/${progress.total})` : 'آغاز جستجوی سریع'}
            </span>
            <span className="text-[10px] text-slate-400">
              تست واقعی رنج‌های ۱۶۲.۱۵۹ و ۱۸۸.۱۱۴ برای دور زدن فیلترینگ
            </span>
          </div>
          <button
            onClick={handleStartScan}
            disabled={isScanning}
            className="px-4 py-2 rounded-xl bg-gradient-to-r from-[#ffe600] to-[#ff7700] text-slate-950 font-bold text-xs flex items-center gap-1.5 hover:opacity-90 disabled:opacity-50 transition-opacity cursor-pointer shadow-md"
          >
            <RefreshCw size={13} className={isScanning ? 'animate-spin' : ''} />
            <span>{isScanning ? 'اسکن...' : 'شروع اسکن'}</span>
          </button>
        </div>

        {/* Progress bar */}
        {isScanning && (
          <div className="w-full bg-slate-800 h-1">
            <div
              className="bg-gradient-to-r from-[#ff2d78] via-[#ffe600] to-[#00ff66] h-full transition-all duration-300"
              style={{ width: `${(progress.scanned / progress.total) * 100}%` }}
            />
          </div>
        )}

        {/* Results list */}
        <div className="flex-1 overflow-y-auto p-3 space-y-2">
          {results.length === 0 && !isScanning ? (
            <div className="py-12 text-center text-slate-500 text-xs flex flex-col items-center gap-2">
              <Cpu size={32} className="text-slate-600" />
              <span>دکمه «شروع اسکن» را لمس کنید تا سریع‌ترین آی‌پی‌های بدون اختلال پیدا شوند.</span>
            </div>
          ) : (
            results.map((res) => (
              <div
                key={res.ip}
                className="p-3 rounded-2xl bg-[#121422] border border-slate-800/80 hover:border-slate-700 flex items-center justify-between transition-colors"
              >
                <div>
                  <div className="flex items-center gap-2">
                    <span className="font-mono font-bold text-xs text-slate-100">{res.ip}</span>
                    <span className="text-[9px] px-1.5 py-0.5 rounded bg-slate-800 text-slate-300 font-mono">
                      {res.datacenter}
                    </span>
                  </div>
                  <div className="flex items-center gap-3 mt-1 text-[10px] font-mono text-slate-400">
                    <span className="text-[#00ff66]">سرعت: {res.downloadSpeedMbps} Mb/s</span>
                    <span>•</span>
                    <span className={res.packetLoss === 0 ? 'text-[#00ff66]' : 'text-[#ff7700]'}>
                      اتلاف پکت: {res.packetLoss}%
                    </span>
                  </div>
                </div>

                <div className="flex items-center gap-2">
                  <span className="px-2 py-0.5 rounded-full bg-[#00ff66]/10 border border-[#00ff66]/30 text-[#00ff66] font-mono text-xs font-bold">
                    {res.ping} ms
                  </span>
                  <button
                    onClick={() => {
                      onApplyCleanIp(res.ip);
                      onClose();
                    }}
                    className="p-1.5 rounded-xl bg-[#00ff66] text-slate-950 font-bold hover:scale-105 transition-transform cursor-pointer"
                    title="اعمال روی اتصال"
                  >
                    <Check size={14} strokeWidth={3} />
                  </button>
                </div>
              </div>
            ))
          )}
        </div>
      </div>
    </div>
  );
};
