import React, { useState, useEffect } from 'react';
import { X, Copy, QrCode, Download, Plus, Check, FileText } from 'lucide-react';
import QRCode from 'qrcode';
import { ServerNode } from '../types/vpn';

interface ConfigManagerModalProps {
  isOpen: boolean;
  onClose: () => void;
  activeServer: ServerNode;
  onImportCustomConfig: (configStr: string) => void;
}

export const ConfigManagerModal: React.FC<ConfigManagerModalProps> = ({
  isOpen,
  onClose,
  activeServer,
  onImportCustomConfig
}) => {
  const [tab, setTab] = useState<'export' | 'import'>('export');
  const [qrDataUrl, setQrDataUrl] = useState<string>('');
  const [copied, setCopied] = useState(false);
  const [importText, setImportText] = useState('');
  const [importSuccess, setImportSuccess] = useState(false);

  useEffect(() => {
    if (activeServer?.configUrl && isOpen) {
      QRCode.toDataURL(activeServer.configUrl, {
        width: 240,
        margin: 2,
        color: {
          dark: '#07080c',
          light: '#ffffff'
        }
      })
        .then((url) => setQrDataUrl(url))
        .catch(() => {});
    }
  }, [activeServer, isOpen]);

  if (!isOpen) return null;

  const handleCopy = () => {
    navigator.clipboard.writeText(activeServer.configUrl);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleDownload = () => {
    const blob = new Blob([activeServer.configUrl], { type: 'text/plain;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `matvpn-${activeServer.id}.conf`;
    a.click();
    URL.revokeObjectURL(url);
  };

  const handleImportSubmit = () => {
    if (!importText.trim()) return;
    onImportCustomConfig(importText.trim());
    setImportSuccess(true);
    setTimeout(() => {
      setImportSuccess(false);
      onClose();
    }, 1200);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center bg-black/85 backdrop-blur-sm p-0 sm:p-4 animate-in fade-in duration-200">
      <div className="w-full sm:max-w-md bg-[#0e101a] border border-[#ff2d78]/30 rounded-t-3xl sm:rounded-3xl max-h-[90vh] flex flex-col overflow-hidden shadow-[0_0_40px_rgba(255,45,120,0.15)]">
        {/* Header */}
        <div className="p-4 border-b border-slate-800 flex items-center justify-between bg-gradient-to-r from-[#ff2d78]/10 via-[#0e101a] to-transparent">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-xl bg-[#ff2d78]/20 border border-[#ff2d78]/40 flex items-center justify-center text-[#ff2d78]">
              <QrCode size={20} />
            </div>
            <div>
              <h3 className="font-bold text-slate-100 text-sm">مدیریت کانفیگ و اشتراک‌گذاری QR</h3>
              <p className="text-[11px] text-slate-400">خروجی QR کد، لینک مستقیم، و افزودن کانفیگ شخصی</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="w-8 h-8 rounded-full bg-slate-800/80 text-slate-400 hover:text-white flex items-center justify-center"
          >
            <X size={18} />
          </button>
        </div>

        {/* Tab switch */}
        <div className="grid grid-cols-2 p-2 bg-[#0a0b12] border-b border-slate-800/60 gap-2">
          <button
            onClick={() => setTab('export')}
            className={`py-2 rounded-xl text-xs font-bold transition-all cursor-pointer ${
              tab === 'export'
                ? 'bg-gradient-to-r from-[#ff2d78] to-[#ff7700] text-white shadow-md'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            خروجی سرور فعلی (QR و کپی)
          </button>
          <button
            onClick={() => setTab('import')}
            className={`py-2 rounded-xl text-xs font-bold transition-all cursor-pointer ${
              tab === 'import'
                ? 'bg-gradient-to-r from-[#00ff66] to-[#00e5ff] text-slate-950 shadow-md'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            ورود کانفیگ جدید (+)
          </button>
        </div>

        {/* Tab 1: Export & QR */}
        {tab === 'export' && (
          <div className="flex-1 overflow-y-auto p-4 space-y-4 flex flex-col items-center">
            {/* QR Display with Rainbow Border */}
            <div className="p-2.5 rounded-3xl bg-gradient-to-tr from-[#ff2d78] via-[#ffe600] to-[#00ff66] shadow-[0_0_25px_rgba(255,45,120,0.3)]">
              <div className="bg-white p-3 rounded-2xl flex items-center justify-center">
                {qrDataUrl ? (
                  <img src={qrDataUrl} alt="MatVPN Server QR Code" className="w-48 h-48 rounded-lg" />
                ) : (
                  <div className="w-48 h-48 flex items-center justify-center text-slate-600 font-mono text-xs">
                    تولید بارکد...
                  </div>
                )}
              </div>
            </div>

            <span className="text-xs text-slate-400 text-center">
              برای اشتراک‌گذاری با گوشی یا دوستان، بارکد بالا را با دوربین یا برنامه V2Ray/Hiddify اسکن کنید.
            </span>

            {/* Config String preview */}
            <div className="w-full bg-[#121422] border border-slate-800 rounded-2xl p-3">
              <div className="flex items-center justify-between mb-2">
                <span className="text-xs font-bold text-slate-300">لینک خام پروتکل:</span>
                <span className="text-[10px] font-mono text-[#ff2d78] font-bold uppercase">{activeServer.protocol}</span>
              </div>
              <textarea
                readOnly
                value={activeServer.configUrl}
                rows={3}
                className="w-full bg-[#090a12] border border-slate-800 rounded-xl p-2 text-[10px] font-mono text-slate-300 select-all focus:outline-none resize-none"
              />
              <div className="flex items-center gap-2 mt-2">
                <button
                  onClick={handleCopy}
                  className="flex-1 py-2 rounded-xl bg-[#1a1d2e] border border-slate-700 hover:border-[#ff2d78] text-xs font-bold text-slate-200 hover:text-white flex items-center justify-center gap-1.5 transition-colors cursor-pointer"
                >
                  {copied ? <Check size={14} className="text-[#00ff66]" /> : <Copy size={14} />}
                  <span>{copied ? 'کپی شد!' : 'کپی لینک'}</span>
                </button>
                <button
                  onClick={handleDownload}
                  className="px-4 py-2 rounded-xl bg-[#1a1d2e] border border-slate-700 hover:border-[#00ff66] text-xs font-bold text-slate-200 hover:text-white flex items-center justify-center gap-1.5 transition-colors cursor-pointer"
                >
                  <Download size={14} />
                  <span>دانلود فایل</span>
                </button>
              </div>
            </div>
          </div>
        )}

        {/* Tab 2: Import Custom Config */}
        {tab === 'import' && (
          <div className="flex-1 overflow-y-auto p-4 space-y-4">
            <div>
              <span className="text-xs font-bold text-slate-200 block mb-1">
                کانفیگ، لینک سابسکریپشن، یا محتوای WireGuard را الصاق کنید:
              </span>
              <span className="text-[11px] text-slate-400 block mb-2 leading-relaxed">
                پشتیبانی از تمامی لینک‌های: <code className="text-[#00ff66]">vless://</code>, <code className="text-[#ffe600]">vmess://</code>, <code className="text-[#ff2d78]">ss://</code>, <code className="text-[#00e5ff]">warp://</code>, <code className="text-[#a855f7]">awg://</code>
              </span>
              <textarea
                value={importText}
                onChange={(e) => setImportText(e.target.value)}
                placeholder="vless://... یا متن کانفیگ را اینجا Paste کنید..."
                rows={6}
                className="w-full bg-[#121422] border border-slate-800 focus:border-[#00ff66] rounded-2xl p-3 text-xs font-mono text-slate-200 focus:outline-none resize-none"
              />
            </div>

            <button
              onClick={handleImportSubmit}
              disabled={!importText.trim()}
              className="w-full py-3 rounded-2xl bg-gradient-to-r from-[#00ff66] to-[#00e5ff] text-slate-950 font-bold text-xs flex items-center justify-center gap-2 hover:opacity-95 disabled:opacity-50 transition-opacity cursor-pointer shadow-lg"
            >
              {importSuccess ? <Check size={16} strokeWidth={3} /> : <Plus size={16} strokeWidth={3} />}
              <span>{importSuccess ? 'با موفقیت افزوده شد!' : 'افزودن و اتصال به کانفیگ شخصی'}</span>
            </button>
          </div>
        )}
      </div>
    </div>
  );
};
