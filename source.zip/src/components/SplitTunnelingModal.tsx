import React from 'react';
import { X, Split, ShieldCheck, Check, Sparkles } from 'lucide-react';
import { VPNSettings } from '../types/vpn';
import { IRANIAN_APPS_PRESETS } from '../data/mockServers';

interface SplitTunnelingModalProps {
  isOpen: boolean;
  onClose: () => void;
  settings: VPNSettings;
  onUpdateSettings: (newSettings: Partial<VPNSettings>) => void;
}

export const SplitTunnelingModal: React.FC<SplitTunnelingModalProps> = ({
  isOpen,
  onClose,
  settings,
  onUpdateSettings
}) => {
  if (!isOpen) return null;

  const toggleAppWhitelist = (pkg: string) => {
    const list = settings.whitelistedIranianApps;
    const nextList = list.includes(pkg)
      ? list.filter((p) => p !== pkg)
      : [...list, pkg];
    onUpdateSettings({ whitelistedIranianApps: nextList });
  };

  return (
    <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center bg-black/85 backdrop-blur-sm p-0 sm:p-4 animate-in fade-in duration-200">
      <div className="w-full sm:max-w-md bg-[#0e101a] border border-[#ff7700]/30 rounded-t-3xl sm:rounded-3xl max-h-[90vh] flex flex-col overflow-hidden shadow-[0_0_40px_rgba(255,119,0,0.15)]">
        {/* Header */}
        <div className="p-4 border-b border-slate-800 flex items-center justify-between bg-gradient-to-r from-[#ff7700]/10 via-[#0e101a] to-transparent">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-xl bg-[#ff7700]/20 border border-[#ff7700]/40 flex items-center justify-center text-[#ff7700]">
              <Split size={20} />
            </div>
            <div>
              <h3 className="font-bold text-slate-100 text-sm">تونل تفکیکی برنامه‌ها (Split Tunneling)</h3>
              <p className="text-[11px] text-slate-400">جداسازی بانک‌ها، اسنپ و برنامه‌های داخلی از فیلترشکن</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="w-8 h-8 rounded-full bg-slate-800/80 text-slate-400 hover:text-white flex items-center justify-center"
          >
            <X size={18} />
          </button>
        </div>

        {/* Content */}
        <div className="flex-1 overflow-y-auto p-4 space-y-4">
          {/* Mode Selector */}
          <div className="space-y-2">
            <span className="text-xs font-bold text-slate-300 block">نحوه هدایت ترافیک:</span>
            {[
              {
                id: 'bypass_iran',
                title: 'بای‌پس خودکار برنامه‌های ایرانی (توصیه شده)',
                desc: 'همراه‌بانک‌ها، اسنپ و سامانه‌های داخلی بدون فیلترشکن و با اینترنت نیم‌بها باز می‌شوند.'
              },
              {
                id: 'all',
                title: 'تونل سراسری (تمام ترافیک گوشی)',
                desc: 'تمام داده‌های ارسالی و دریافتی از تونل کدگذاری شده MatVPN عبور می‌کنند.'
              },
              {
                id: 'only_selected',
                title: 'فقط برنامه‌های فیلتر شده انتخابی',
                desc: 'تنها تلگرام، اینستاگرام و یوتیوب تحت پوشش VPN قرار می‌گیرند.'
              }
            ].map((mode) => (
              <div
                key={mode.id}
                onClick={() => onUpdateSettings({ splitTunnelingMode: mode.id as VPNSettings['splitTunnelingMode'] })}
                className={`p-3 rounded-2xl border text-xs cursor-pointer flex items-center justify-between transition-colors ${
                  settings.splitTunnelingMode === mode.id
                    ? 'bg-[#ff7700]/15 border-[#ff7700]/60 text-white font-medium'
                    : 'bg-[#121422] border-slate-800 text-slate-400 hover:text-slate-200'
                }`}
              >
                <div>
                  <span className="font-bold text-slate-100 block">{mode.title}</span>
                  <span className="text-[10px] text-slate-400 mt-0.5 block">{mode.desc}</span>
                </div>
                {settings.splitTunnelingMode === mode.id && (
                  <div className="w-5 h-5 rounded-full bg-[#ff7700] text-slate-950 flex items-center justify-center">
                    <Check size={12} strokeWidth={3} />
                  </div>
                )}
              </div>
            ))}
          </div>

          {/* Installed Apps Checklist */}
          <div className="space-y-2 pt-2 border-t border-slate-800">
            <span className="text-xs font-bold text-slate-300 block">لیست برنامه‌های شناسایی‌شده روی گوشی:</span>
            <div className="space-y-1.5">
              {IRANIAN_APPS_PRESETS.map((app) => {
                const isSelected = settings.whitelistedIranianApps.includes(app.pkg);
                return (
                  <div
                    key={app.pkg}
                    onClick={() => toggleAppWhitelist(app.pkg)}
                    className="p-2.5 rounded-xl bg-[#121422] border border-slate-800/80 hover:border-slate-700 flex items-center justify-between text-xs cursor-pointer transition-colors"
                  >
                    <div className="flex items-center gap-2.5">
                      <span className="text-lg">{app.icon}</span>
                      <div>
                        <span className="font-bold text-slate-200">{app.name}</span>
                        <span className="text-[10px] text-slate-500 font-mono block">{app.pkg}</span>
                      </div>
                    </div>
                    <div
                      className={`w-5 h-5 rounded-md flex items-center justify-center border transition-colors ${
                        isSelected
                          ? 'bg-[#00ff66] border-[#00ff66] text-slate-950'
                          : 'border-slate-700 bg-slate-900'
                      }`}
                    >
                      {isSelected && <Check size={13} strokeWidth={3} />}
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="p-3.5 bg-[#0a0b12] border-t border-slate-800/80 flex items-center justify-end">
          <button
            onClick={onClose}
            className="px-5 py-2 rounded-xl bg-gradient-to-r from-[#ff7700] to-[#ffe600] text-slate-950 font-bold text-xs hover:opacity-90 transition-opacity cursor-pointer"
          >
            ذخیره قوانین تفکیک
          </button>
        </div>
      </div>
    </div>
  );
};
