import React from 'react';
import { Wifi, BatteryMedium, Key, Sparkles, Smartphone, Monitor } from 'lucide-react';
import { ConnectionStatus } from '../types/vpn';

interface AndroidFrameProps {
  children: React.ReactNode;
  connectionStatus: ConnectionStatus;
  isNationalActive: boolean;
  isAndroidFrameMode: boolean;
  setIsAndroidFrameMode: (val: boolean) => void;
}

export const AndroidFrame: React.FC<AndroidFrameProps> = ({
  children,
  connectionStatus,
  isNationalActive,
  isAndroidFrameMode,
  setIsAndroidFrameMode
}) => {
  const isConnected = connectionStatus === 'connected';

  return (
    <div className="min-h-screen bg-[#06070a] text-slate-100 flex flex-col items-center justify-start p-0 md:py-6 selection:bg-[#ff2d78] selection:text-white relative">
      {/* Viewport switch toolbar for convenience on desktop */}
      <div className="hidden md:flex items-center gap-3 mb-4 bg-[#12141c]/80 backdrop-blur-md px-4 py-2 rounded-full border border-slate-800 text-xs text-slate-400 z-50">
        <span className="text-slate-300 font-medium">حالت نمایش:</span>
        <button
          onClick={() => setIsAndroidFrameMode(true)}
          className={`flex items-center gap-1.5 px-3 py-1 rounded-full transition-all cursor-pointer ${
            isAndroidFrameMode 
              ? 'bg-gradient-to-r from-[#ff2d78] to-[#ff7700] text-white font-bold shadow-md' 
              : 'hover:text-white hover:bg-slate-800'
          }`}
        >
          <Smartphone size={14} />
          <span>قاب اندروید (Android Mobile)</span>
        </button>
        <button
          onClick={() => setIsAndroidFrameMode(false)}
          className={`flex items-center gap-1.5 px-3 py-1 rounded-full transition-all cursor-pointer ${
            !isAndroidFrameMode 
              ? 'bg-gradient-to-r from-[#00ff66] to-[#00e5ff] text-slate-950 font-bold shadow-md' 
              : 'hover:text-white hover:bg-slate-800'
          }`}
        >
          <Monitor size={14} />
          <span>پاسخگو سراسری (Full Responsive)</span>
        </button>
      </div>

      {/* Main Container: Android Device Mockup or Full Screen */}
      <div 
        className={`w-full transition-all duration-300 relative flex flex-col ${
          isAndroidFrameMode
            ? 'max-w-[430px] min-h-[880px] md:rounded-[44px] md:border-[7px] md:border-[#1a1d28] md:shadow-[0_0_60px_rgba(255,45,120,0.18)] overflow-hidden bg-[#0a0b12]'
            : 'max-w-2xl min-h-screen md:rounded-3xl md:border md:border-slate-800/80 bg-[#0a0b12]'
        }`}
      >
        {/* Android Punch-Hole Camera (Visible in phone mode) */}
        {isAndroidFrameMode && (
          <div className="hidden md:block absolute top-3 left-1/2 -translate-x-1/2 w-4 h-4 bg-[#030406] rounded-full border border-slate-800/50 z-50 pointer-events-none" />
        )}

        {/* Android Native Status Bar */}
        <div className="w-full h-8 px-5 flex items-center justify-between text-[11px] font-mono tracking-tight text-slate-300 bg-transparent z-40 select-none pt-1">
          {/* Right side in Persian RTL: Time & VPN Key */}
          <div className="flex items-center gap-2">
            <span className="font-semibold text-slate-200">10:55</span>
            {isConnected && (
              <span className="flex items-center gap-0.5 px-1.5 py-0.5 rounded bg-[#ff2d78]/20 border border-[#ff2d78]/40 text-[#ff2d78] text-[9px] font-bold animate-pulse">
                <Key size={10} />
                <span>VPN</span>
              </span>
            )}
            {isNationalActive && (
              <span className="px-1.5 py-0.5 rounded bg-[#00ff66]/20 border border-[#00ff66]/40 text-[#00ff66] text-[9px] font-bold">
                ملی
              </span>
            )}
          </div>

          {/* Left side in Persian RTL: Signal, WiFi, Battery */}
          <div className="flex items-center gap-2 text-slate-400">
            <span className="text-[10px] text-[#ffe600] font-bold">5G</span>
            <Wifi size={13} className="text-slate-300" />
            <div className="flex items-center gap-0.5">
              <span className="text-[10px] font-mono">98%</span>
              <BatteryMedium size={14} className="text-[#00ff66]" />
            </div>
          </div>
        </div>

        {/* Inner App Content */}
        <div className="flex-1 flex flex-col relative overflow-y-auto">
          {children}
        </div>

        {/* Android Gesture Pill / Nav Bar */}
        <div className="w-full h-5 flex items-center justify-center pb-2 select-none pointer-events-none">
          <div className="w-32 h-1 bg-slate-700/60 rounded-full" />
        </div>
      </div>
    </div>
  );
};
