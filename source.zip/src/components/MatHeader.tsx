import React from 'react';
import { RainbowIcon } from './RainbowIcon';
import { Sliders, Zap } from 'lucide-react';

interface MatHeaderProps {
  onOpenSettings: () => void;
  isNationalActive?: boolean;
}

export const MatHeader: React.FC<MatHeaderProps> = ({
  onOpenSettings,
  isNationalActive = false
}) => {
  return (
    <header className="w-full px-4 pt-3 pb-3 flex items-center justify-between border-b border-slate-800/60 bg-[#0a0b12]/90 backdrop-blur-md sticky top-0 z-30">
      {/* Brand & Logo */}
      <div className="flex items-center gap-3">
        <RainbowIcon size={38} animate={true} withGlow={true} />
        <div>
          <div className="flex items-center gap-2">
            <h1 className="text-xl font-black tracking-tight font-mono text-white">
              <span className="text-rainbow-7 font-black">matvpn</span>
            </h1>
            <span className="text-[9px] bg-gradient-to-r from-[#ff2d78] to-[#ff7700] text-white font-extrabold px-1.5 py-0.5 rounded-full uppercase tracking-wider">
              Ultra v3.5
            </span>
          </div>
          <span className="text-[10px] text-slate-400 block -mt-0.5 font-medium">
            دور زدن فیلترینگ شدید • سوییچ ملی
          </span>
        </div>
      </div>

      {/* Top Small & Beautiful Settings Button */}
      <div className="flex items-center gap-2">
        {isNationalActive && (
          <div 
            title="تونل اینترنت ملی فعال است"
            className="flex items-center gap-1.5 px-2 py-1 rounded-full bg-[#00ff66]/15 border border-[#00ff66]/40 text-[#00ff66] text-[10px] font-bold"
          >
            <span className="w-1.5 h-1.5 rounded-full bg-[#00ff66] animate-ping" />
            <Zap size={11} />
            <span className="hidden sm:inline">ملی فعال</span>
          </div>
        )}

        <button
          onClick={onOpenSettings}
          title="تنظیمات و جعبه‌ابزار پیشرفته"
          className="flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-gradient-to-r from-[#17192b] to-[#111320] border border-slate-700/80 hover:border-[#ff2d78] text-slate-200 hover:text-white transition-all shadow-md group active:scale-95 cursor-pointer"
        >
          <span className="text-[11px] font-bold text-slate-300 group-hover:text-white">تنظیمات</span>
          <div className="w-6 h-6 rounded-full bg-[#ff2d78]/20 border border-[#ff2d78]/40 flex items-center justify-center text-[#ff2d78] group-hover:scale-110 transition-transform">
            <Sliders size={13} />
          </div>
        </button>
      </div>
    </header>
  );
};
