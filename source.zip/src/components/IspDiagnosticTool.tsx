import React, { useState } from 'react';
import { X, ShieldAlert, Cpu, CheckCircle2, ArrowRight, Activity, Radio } from 'lucide-react';
import { diagnoseIranNetwork, IspDiagnosticResult } from '../utils/cleanIpScanner';
import { ISPType, ServerNode } from '../types/vpn';
import { SERVERS_LIST } from '../data/mockServers';

interface IspDiagnosticToolProps {
  isOpen: boolean;
  onClose: () => void;
  currentIsp: ISPType;
  onChangeIsp: (isp: ISPType) => void;
  onSelectRecommendedServer: (server: ServerNode) => void;
}

export const IspDiagnosticTool: React.FC<IspDiagnosticToolProps> = ({
  isOpen,
  onClose,
  currentIsp,
  onChangeIsp,
  onSelectRecommendedServer
}) => {
  const [testing, setTesting] = useState(false);
  const [diagnostic, setDiagnostic] = useState<IspDiagnosticResult>(diagnoseIranNetwork(currentIsp));

  if (!isOpen) return null;

  const handleTestNow = (isp: ISPType) => {
    onChangeIsp(isp);
    setTesting(true);
    setTimeout(() => {
      setDiagnostic(diagnoseIranNetwork(isp));
      setTesting(false);
    }, 800);
  };

  const handleApplyRecommended = () => {
    // Find matching server
    const recommended = SERVERS_LIST.find(s => s.recommendedIsps.includes(currentIsp)) || SERVERS_LIST[0];
    onSelectRecommendedServer(recommended);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center bg-black/85 backdrop-blur-sm p-0 sm:p-4 animate-in fade-in duration-200">
      <div className="w-full sm:max-w-md bg-[#0e101a] border border-[#00e5ff]/30 rounded-t-3xl sm:rounded-3xl max-h-[90vh] flex flex-col overflow-hidden shadow-[0_0_40px_rgba(0,229,255,0.15)]">
        {/* Header */}
        <div className="p-4 border-b border-slate-800 flex items-center justify-between bg-gradient-to-r from-[#00e5ff]/10 via-[#0e101a] to-transparent">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-xl bg-[#00e5ff]/20 border border-[#00e5ff]/40 flex items-center justify-center text-[#00e5ff]">
              <Activity size={20} />
            </div>
            <div>
              <h3 className="font-bold text-slate-100 text-sm">آنالیزور وضعیت فیلترینگ و اپراتورها</h3>
              <p className="text-[11px] text-slate-400">بررسی سطح DPI و مسدودی‌های مخابرات و دکل‌های همراه</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="w-8 h-8 rounded-full bg-slate-800/80 text-slate-400 hover:text-white flex items-center justify-center"
          >
            <X size={18} />
          </button>
        </div>

        {/* Content */}
        <div className="flex-1 overflow-y-auto p-4 space-y-4">
          {/* Operator Switcher */}
          <div>
            <span className="text-xs font-bold text-slate-300 block mb-2">انتخاب اپراتور سیم‌کارت یا اینترنت شما:</span>
            <div className="grid grid-cols-4 gap-1.5">
              {[
                { id: 'mci', label: 'همراه اول' },
                { id: 'mtn', label: 'ایرانسل' },
                { id: 'rightel', label: 'رایتل' },
                { id: 'mokhaberat', label: 'مخابرات' },
              ].map(item => (
                <button
                  key={item.id}
                  onClick={() => handleTestNow(item.id as ISPType)}
                  className={`py-2 rounded-xl text-xs font-bold transition-all cursor-pointer ${
                    currentIsp === item.id
                      ? 'bg-gradient-to-r from-[#00e5ff] to-[#00ff66] text-slate-950 font-black shadow-md'
                      : 'bg-[#121422] text-slate-400 hover:text-white border border-slate-800'
                  }`}
                >
                  {item.label}
                </button>
              ))}
            </div>
          </div>

          {/* Diagnostic Card */}
          <div className="p-4 rounded-2xl bg-[#121422] border border-slate-800/90 space-y-3">
            <div className="flex items-center justify-between border-b border-slate-800/80 pb-2">
              <span className="text-xs font-bold text-slate-100">{diagnostic.ispName}</span>
              <span className="text-[10px] px-2 py-0.5 rounded-full bg-[#ff2d78]/20 text-[#ff2d78] font-bold border border-[#ff2d78]/30">
                {diagnostic.censorLevel}
              </span>
            </div>

            <div className="grid grid-cols-2 gap-2 text-xs">
              <div className="bg-[#0a0b12] p-2.5 rounded-xl border border-slate-800">
                <span className="text-[10px] text-slate-400 block">پینگ به اینترنت ملی (داخل):</span>
                <span className="font-mono font-bold text-[#00ff66] text-sm">
                  {diagnostic.pingToNationalRelay} ms
                </span>
              </div>
              <div className="bg-[#0a0b12] p-2.5 rounded-xl border border-slate-800">
                <span className="text-[10px] text-slate-400 block">پینگ به خارج (بین‌الملل):</span>
                <span className="font-mono font-bold text-[#ffe600] text-sm">
                  {diagnostic.pingToInternational} ms
                </span>
              </div>
            </div>

            <div className="space-y-1.5 pt-1">
              <span className="text-[11px] text-slate-400 block font-medium">پروتکل تضمینی بدون قطعی:</span>
              <div className="p-2.5 rounded-xl bg-[#0a0b12] border border-slate-800 font-mono text-xs text-[#00ff66] font-bold flex items-center gap-2">
                <CheckCircle2 size={16} />
                <span>{diagnostic.recommendedProtocol}</span>
              </div>
            </div>

            <div className="space-y-1.5">
              <span className="text-[11px] text-slate-400 block font-medium">روش دور زدن فیلترینگ این اپراتور:</span>
              <div className="p-2.5 rounded-xl bg-[#0a0b12] border border-slate-800 text-xs text-slate-200">
                {diagnostic.dpiBypassMethod}
              </div>
            </div>
          </div>
        </div>

        {/* Footer Action */}
        <div className="p-3.5 bg-[#0a0b12] border-t border-slate-800/80 flex items-center justify-between">
          <button
            onClick={() => handleTestNow(currentIsp)}
            disabled={testing}
            className="text-xs text-slate-400 hover:text-white flex items-center gap-1 cursor-pointer"
          >
            <Activity size={14} className={testing ? 'animate-spin text-[#00e5ff]' : ''} />
            <span>{testing ? 'در حال تست مجدد...' : 'تست مجدد کیفیت'}</span>
          </button>
          <button
            onClick={handleApplyRecommended}
            className="px-4 py-2 rounded-xl bg-gradient-to-r from-[#00ff66] to-[#00e5ff] text-slate-950 font-bold text-xs hover:opacity-90 transition-opacity cursor-pointer shadow-md"
          >
            اعمال بهترین پروتکل
          </button>
        </div>
      </div>
    </div>
  );
};
