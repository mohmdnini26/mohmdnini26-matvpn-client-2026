import React, { useEffect, useRef, useState } from 'react';
import { ArrowDown, ArrowUp, Activity, Gauge, ShieldAlert, Waves } from 'lucide-react';
import { TrafficStats, ServerNode } from '../types/vpn';

interface SpeedGraphProps {
  stats: TrafficStats;
  isConnected: boolean;
  activeServer: ServerNode;
}

// 7 Rainbow Colors that shift every 1 second
const RAINBOW_PALETTE = [
  { dl: '#00ff66', ul: '#ff2d78', name: 'سبز فسفری و صورتی' }, // 0s
  { dl: '#00e5ff', ul: '#ff7700', name: 'فیروزه‌ای و نارنجی' }, // 1s
  { dl: '#ffe600', ul: '#a855f7', name: 'زرد الکتریک و بنفش' }, // 2s
  { dl: '#ff2d78', ul: '#00ff66', name: 'صورتی نئونی و سبز' }, // 3s
  { dl: '#3b82f6', ul: '#ffe600', name: 'آبی متالیک و زرد' }, // 4s
  { dl: '#ff7700', ul: '#00e5ff', name: 'نارنجی شعله‌ای و فیروزه‌ای' }, // 5s
  { dl: '#a855f7', ul: '#3b82f6', name: 'بنفش ارغوانی و آبی' }, // 6s
];

export const SpeedGraph: React.FC<SpeedGraphProps> = ({
  stats,
  isConnected,
  activeServer
}) => {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const [colorIndex, setColorIndex] = useState(0);

  // Cycle colors every 1 second (1000ms)
  useEffect(() => {
    if (!isConnected) {
      setColorIndex(0);
      return;
    }
    const interval = setInterval(() => {
      setColorIndex((prev) => (prev + 1) % RAINBOW_PALETTE.length);
    }, 1000);
    return () => clearInterval(interval);
  }, [isConnected]);

  const activeColors = RAINBOW_PALETTE[colorIndex];
  const activeColorsRef = useRef(activeColors);
  activeColorsRef.current = activeColors;

  const isConnectedRef = useRef(isConnected);
  isConnectedRef.current = isConnected;

  const statsRef = useRef(stats);
  statsRef.current = stats;

  // Ocean Wave Canvas Animation Loop
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    let animId: number;
    let step = 0;

    const resize = () => {
      if (!canvas) return;
      canvas.width = canvas.parentElement?.clientWidth || 320;
      canvas.height = 80;
    };

    resize();
    window.addEventListener('resize', resize);

    const render = () => {
      const width = canvas.width;
      const height = canvas.height;
      ctx.clearRect(0, 0, width, height);

      const colors = activeColorsRef.current;
      const connected = isConnectedRef.current;
      const currentStats = statsRef.current;

      step += 0.045; // Wave animation phase speed

      // Wave 1: Download Ocean Wave (Front layer)
      // Amplitude scales with download speed
      const dlSpeed = connected ? currentStats.downloadSpeed : 0.5;
      const dlAmp = connected ? Math.min(22, 6 + dlSpeed * 0.45) : 3;
      const dlFreq = 0.016;

      ctx.beginPath();
      ctx.moveTo(0, height);

      for (let x = 0; x <= width; x += 3) {
        // Multi-frequency sinusoidal equation for realistic sea waves
        const y =
          height * 0.52 +
          Math.sin(x * dlFreq + step) * dlAmp +
          Math.sin(x * 0.03 + step * 1.5) * (dlAmp * 0.35);
        ctx.lineTo(x, y);
      }

      ctx.lineTo(width, height);
      ctx.closePath();

      // Translucent ocean gradient fill
      const dlGrad = ctx.createLinearGradient(0, 0, 0, height);
      dlGrad.addColorStop(0, `${colors.dl}55`);
      dlGrad.addColorStop(0.5, `${colors.dl}25`);
      dlGrad.addColorStop(1, `${colors.dl}05`);
      ctx.fillStyle = dlGrad;
      ctx.fill();

      // Glowing ocean wave crest line
      ctx.beginPath();
      for (let x = 0; x <= width; x += 3) {
        const y =
          height * 0.52 +
          Math.sin(x * dlFreq + step) * dlAmp +
          Math.sin(x * 0.03 + step * 1.5) * (dlAmp * 0.35);
        if (x === 0) ctx.moveTo(x, y);
        else ctx.lineTo(x, y);
      }
      ctx.strokeStyle = colors.dl;
      ctx.lineWidth = connected ? 2.5 : 1.2;
      ctx.shadowBlur = connected ? 10 : 3;
      ctx.shadowColor = colors.dl;
      ctx.stroke();

      // Wave 2: Upload Ocean Wave (Back layer, offset frequency & speed)
      const ulSpeed = connected ? currentStats.uploadSpeed : 0.3;
      const ulAmp = connected ? Math.min(18, 5 + ulSpeed * 0.5) : 2.5;
      const ulFreq = 0.022;

      ctx.beginPath();
      ctx.moveTo(0, height);

      for (let x = 0; x <= width; x += 3) {
        const y =
          height * 0.62 +
          Math.sin(x * ulFreq - step * 0.9) * ulAmp +
          Math.cos(x * 0.04 - step * 1.2) * (ulAmp * 0.4);
        ctx.lineTo(x, y);
      }

      ctx.lineTo(width, height);
      ctx.closePath();

      const ulGrad = ctx.createLinearGradient(0, 0, 0, height);
      ulGrad.addColorStop(0, `${colors.ul}40`);
      ulGrad.addColorStop(0.5, `${colors.ul}18`);
      ulGrad.addColorStop(1, `${colors.ul}02`);
      ctx.fillStyle = ulGrad;
      ctx.fill();

      // Glowing wave crest for upload
      ctx.beginPath();
      for (let x = 0; x <= width; x += 3) {
        const y =
          height * 0.62 +
          Math.sin(x * ulFreq - step * 0.9) * ulAmp +
          Math.cos(x * 0.04 - step * 1.2) * (ulAmp * 0.4);
        if (x === 0) ctx.moveTo(x, y);
        else ctx.lineTo(x, y);
      }
      ctx.strokeStyle = colors.ul;
      ctx.lineWidth = connected ? 2.0 : 1.0;
      ctx.shadowBlur = connected ? 8 : 2;
      ctx.shadowColor = colors.ul;
      ctx.stroke();

      ctx.shadowBlur = 0;
      animId = requestAnimationFrame(render);
    };

    render();

    return () => {
      window.removeEventListener('resize', resize);
      cancelAnimationFrame(animId);
    };
  }, []);

  const formatBytes = (bytes: number) => {
    if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} KB`;
    if (bytes < 1024 * 1024 * 1024) return `${(bytes / (1024 * 1024)).toFixed(1)} MB`;
    return `${(bytes / (1024 * 1024 * 1024)).toFixed(2)} GB`;
  };

  return (
    <div className="w-full bg-[#0d0f18]/90 border border-slate-800/80 rounded-2xl p-3.5 backdrop-blur-md relative overflow-hidden">
      {/* Top metrics row */}
      <div className="grid grid-cols-2 gap-2 mb-2.5 relative z-10">
        {/* Download Box */}
        <div 
          className="bg-[#121422] p-2.5 rounded-xl border transition-colors duration-700 flex items-center justify-between"
          style={{ borderColor: `${activeColors.dl}40` }}
        >
          <div className="flex items-center gap-2">
            <div 
              className="w-7 h-7 rounded-lg flex items-center justify-center transition-colors duration-700"
              style={{
                backgroundColor: `${activeColors.dl}20`,
                color: activeColors.dl,
                border: `1px solid ${activeColors.dl}50`
              }}
            >
              <ArrowDown size={16} />
            </div>
            <div>
              <span className="text-[10px] text-slate-400 block font-medium">دانلود (DL)</span>
              <span 
                className="text-sm font-bold font-mono transition-colors duration-700"
                style={{ color: activeColors.dl, textShadow: `0 0 10px ${activeColors.dl}60` }}
              >
                {isConnected ? `${stats.downloadSpeed.toFixed(1)} Mb/s` : '0.0 Mb/s'}
              </span>
            </div>
          </div>
          <span className="text-[10px] font-mono text-slate-500">
            {formatBytes(stats.totalDownloadedBytes)}
          </span>
        </div>

        {/* Upload Box */}
        <div 
          className="bg-[#121422] p-2.5 rounded-xl border transition-colors duration-700 flex items-center justify-between"
          style={{ borderColor: `${activeColors.ul}40` }}
        >
          <div className="flex items-center gap-2">
            <div 
              className="w-7 h-7 rounded-lg flex items-center justify-center transition-colors duration-700"
              style={{
                backgroundColor: `${activeColors.ul}20`,
                color: activeColors.ul,
                border: `1px solid ${activeColors.ul}50`
              }}
            >
              <ArrowUp size={16} />
            </div>
            <div>
              <span className="text-[10px] text-slate-400 block font-medium">آپلود (UL)</span>
              <span 
                className="text-sm font-bold font-mono transition-colors duration-700"
                style={{ color: activeColors.ul, textShadow: `0 0 10px ${activeColors.ul}60` }}
              >
                {isConnected ? `${stats.uploadSpeed.toFixed(1)} Mb/s` : '0.0 Mb/s'}
              </span>
            </div>
          </div>
          <span className="text-[10px] font-mono text-slate-500">
            {formatBytes(stats.totalUploadedBytes)}
          </span>
        </div>
      </div>

      {/* Ocean Wave Live Canvas */}
      <div className="relative h-20 w-full bg-[#07080f] rounded-xl overflow-hidden border border-slate-900 flex items-center justify-center">
        <canvas
          ref={canvasRef}
          className="w-full h-full block"
        />

        {/* Top Wave Info Badge */}
        <div className="absolute top-1.5 left-2 right-2 flex items-center justify-between pointer-events-none select-none">
          <div className="flex items-center gap-1.5 text-[9px] font-mono backdrop-blur-md px-2 py-0.5 rounded-full bg-slate-900/70 border border-slate-800">
            <Waves size={11} className="text-[#00e5ff] animate-pulse" />
            <span className="text-slate-300">امواج ترافیک دریا:</span>
            <span className="font-bold" style={{ color: activeColors.dl }}>{activeColors.name}</span>
          </div>

          {isConnected && (
            <div className="flex items-center gap-2 text-[9px] font-mono">
              <span className="flex items-center gap-1" style={{ color: activeColors.dl }}>
                <span className="w-1.5 h-1.5 rounded-full animate-ping" style={{ backgroundColor: activeColors.dl }} /> DL
              </span>
              <span className="flex items-center gap-1" style={{ color: activeColors.ul }}>
                <span className="w-1.5 h-1.5 rounded-full" style={{ backgroundColor: activeColors.ul }} /> UL
              </span>
            </div>
          )}
        </div>
      </div>

      {/* Latency, Packet Loss & Protocol Info Footer */}
      <div className="mt-2.5 pt-2 border-t border-slate-800/60 flex items-center justify-between text-xs font-mono relative z-10">
        <div className="flex items-center gap-3">
          <span className="flex items-center gap-1 text-[#ffe600]">
            <Gauge size={13} />
            <span>پینگ: {isConnected ? stats.currentPing : '--'} ms</span>
          </span>
          <span className="flex items-center gap-1 text-slate-400">
            <ShieldAlert size={13} className={stats.packetLoss > 0 ? 'text-[#ff7700]' : 'text-slate-500'} />
            <span>اتلاف پکت: {isConnected ? `${stats.packetLoss}%` : '0%'}</span>
          </span>
        </div>
        <div className="text-[11px] text-slate-400 bg-slate-800/60 px-2 py-0.5 rounded-md font-sans border border-slate-700/50">
          {activeServer.protocol.toUpperCase()} / {activeServer.country}
        </div>
      </div>
    </div>
  );
};
