import React from 'react';
import { Zap, Split, Search, ShieldCheck, Radio, Wifi, Globe, Layers, Send, GitBranch } from 'lucide-react';
import { VPNSettings } from '../types/vpn';
import { VpnBrandLogo } from './VpnBrandLogos';

interface QuickFeaturesGridProps {
  settings: VPNSettings;
  onUpdateSettings: (newSettings: Partial<VPNSettings>) => void;
  onOpenNationalModal: () => void;
  onOpenCleanIpModal: () => void;
  onOpenSettingsModal: () => void;
  onOpenTelegramModal: () => void;
  onSelectGitHubTunnel: () => void;
  onSelectWarpInWarp: () => void;
  isNationalActive: boolean;
}

export const QuickFeaturesGrid: React.FC<QuickFeaturesGridProps> = ({
  settings,
  onUpdateSettings,
  onOpenNationalModal,
  onOpenCleanIpModal,
  onOpenSettingsModal,
  onOpenTelegramModal,
  onSelectGitHubTunnel,
  onSelectWarpInWarp,
  isNationalActive
}) => {
  return (
    <div className="w-full px-4 my-2">
      <div className="grid grid-cols-2 gap-2.5">
        {/* Card 1: National Network Switch */}
        <div 
          onClick={onOpenNationalModal}
          className={`p-3 rounded-2xl border transition-all cursor-pointer relative overflow-hidden ${
            isNationalActive || settings.nationalAutoFallback
              ? 'bg-[#00ff66]/10 border-[#00ff66]/40 shadow-[0_0_15px_rgba(0,255,102,0.15)]'
              : 'bg-[#121422] border-slate-800 hover:border-slate-700'
          }`}
        >
          <div className="flex items-center justify-between mb-1.5">
            <span className="text-[11px] font-bold text-slate-100 flex items-center gap-1.5">
              <Zap size={15} className={isNationalActive ? 'text-[#00ff66] animate-pulse' : 'text-slate-400'} />
              <span>پل اینترنت ملی</span>
            </span>
            <span className={`text-[9px] px-1.5 py-0.5 rounded font-bold ${
              isNationalActive ? 'bg-[#00ff66] text-slate-950' : 'bg-slate-800 text-slate-400'
            }`}>
              {isNationalActive ? 'متصل' : 'آماده‌باش'}
            </span>
          </div>
          <p className="text-[10px] text-slate-400 leading-tight">
            اتصال خودکار به تونل معکوس هنگام قطع اینترنت خارجی
          </p>
        </div>

        {/* Card 2: Packet Fragmentation */}
        <div 
          onClick={() => onUpdateSettings({ fragmentEnabled: !settings.fragmentEnabled })}
          className={`p-3 rounded-2xl border transition-all cursor-pointer relative overflow-hidden ${
            settings.fragmentEnabled
              ? 'bg-[#ffe600]/10 border-[#ffe600]/40 shadow-[0_0_15px_rgba(255,230,0,0.15)]'
              : 'bg-[#121422] border-slate-800 hover:border-slate-700'
          }`}
        >
          <div className="flex items-center justify-between mb-1.5">
            <span className="text-[11px] font-bold text-slate-100 flex items-center gap-1.5">
              <Split size={15} className={settings.fragmentEnabled ? 'text-[#ffe600]' : 'text-slate-400'} />
              <span>پکت فرگمنت (DPI)</span>
            </span>
            <span className={`text-[9px] px-1.5 py-0.5 rounded font-mono font-bold ${
              settings.fragmentEnabled ? 'bg-[#ffe600] text-slate-950' : 'bg-slate-800 text-slate-400'
            }`}>
              {settings.fragmentEnabled ? settings.fragmentLength : 'خاموش'}
            </span>
          </div>
          <p className="text-[10px] text-slate-400 leading-tight">
            تکه‌تکه کردن بسته‌ها برای فریب فایروال همراه اول و ایرانسل
          </p>
        </div>

        {/* Card 3: Fake SNI Spoofing */}
        <div 
          onClick={onOpenSettingsModal}
          className={`p-3 rounded-2xl border transition-all cursor-pointer ${
            settings.fakeSniEnabled
              ? 'bg-[#ff2d78]/10 border-[#ff2d78]/40 shadow-[0_0_15px_rgba(255,45,120,0.15)]'
              : 'bg-[#121422] border-slate-800 hover:border-slate-700'
          }`}
        >
          <div className="flex items-center justify-between mb-1.5">
            <span className="text-[11px] font-bold text-slate-100 flex items-center gap-1.5">
              <ShieldCheck size={15} className={settings.fakeSniEnabled ? 'text-[#ff2d78]' : 'text-slate-400'} />
              <span>جعل دامنه سفید</span>
            </span>
            <span className="text-[9px] font-mono font-bold text-[#ff2d78]">
              {settings.fakeSniEnabled ? settings.selectedFakeSni : 'غیرفعال'}
            </span>
          </div>
          <p className="text-[10px] text-slate-400 leading-tight">
            عبور داده‌ها در پوشش دامنه‌های مجاز بانکی و دولتی
          </p>
        </div>

        {/* Card 4: Clean IP Scanner */}
        <div 
          onClick={onOpenCleanIpModal}
          className="p-3 rounded-2xl bg-[#121422] border border-slate-800 hover:border-[#ff7700] transition-all cursor-pointer"
        >
          <div className="flex items-center justify-between mb-1.5">
            <span className="text-[11px] font-bold text-slate-100 flex items-center gap-1.5">
              <Search size={15} className="text-[#ff7700]" />
              <span>اسکنر آی‌پی تمیز</span>
            </span>
            <span className="text-[9px] px-1.5 py-0.5 rounded bg-[#ff7700]/20 text-[#ff7700] font-bold">
              وارپ + کلودفلر
            </span>
          </div>
          <p className="text-[10px] text-slate-400 leading-tight">
            پیدا کردن سریع آی‌پی‌های بدون قطعی و با پینگ زیر ۶۰ms
          </p>
        </div>

        {/* Card 5: Telegram MTProto Proxy Fake TLS */}
        <div 
          onClick={onOpenTelegramModal}
          className="p-3 rounded-2xl bg-[#121422] border border-slate-800 hover:border-[#00e5ff] hover:bg-[#00e5ff]/5 transition-all cursor-pointer"
        >
          <div className="flex items-center justify-between mb-1.5">
            <span className="text-[11px] font-bold text-slate-100 flex items-center gap-1.5">
              <Send size={15} className="text-[#00e5ff]" />
              <span>پروکسی تلگرام</span>
            </span>
            <span className="text-[9px] px-1.5 py-0.5 rounded bg-[#00e5ff]/20 text-[#00e5ff] font-bold">
              Fake TLS
            </span>
          </div>
          <p className="text-[10px] text-slate-400 leading-tight">
            اتصال مستقیم ۱ کلیکه تلگرام بدون قطعی و پرسرعت
          </p>
        </div>

        {/* Card 6: GitHub Cloud Tunnel Relay */}
        <div 
          onClick={onSelectGitHubTunnel}
          className="p-3 rounded-2xl bg-[#121422] border border-slate-800 hover:border-[#00ff66] hover:bg-[#00ff66]/5 transition-all cursor-pointer"
        >
          <div className="flex items-center justify-between mb-1.5">
            <span className="text-[11px] font-bold text-slate-100 flex items-center gap-1.5">
              <GitBranch size={15} className="text-[#00ff66]" />
              <span>گیت‌هاب تانل ابری</span>
            </span>
            <span className="text-[9px] px-1.5 py-0.5 rounded bg-[#00ff66]/20 text-[#00ff66] font-bold">
              دامنه سفید
            </span>
          </div>
          <p className="text-[10px] text-slate-400 leading-tight">
            سوییچ به سرور گیت‌هاب که به دلیل تحصیلی مسدود نمی‌شود
          </p>
        </div>

        {/* Card 7: WARP-in-WARP Dual Cloudflare Tunnel */}
        <div 
          onClick={onSelectWarpInWarp}
          className="col-span-2 p-3 rounded-2xl bg-gradient-to-r from-[#ffe600]/10 via-[#ff7700]/10 to-[#ff2d78]/10 border border-[#ffe600]/50 hover:border-[#ffe600] transition-all cursor-pointer flex items-center justify-between"
        >
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-xl bg-[#090a14] border border-slate-700/80 flex items-center justify-center p-1">
              <VpnBrandLogo protocol="warp_in_warp" size={24} />
            </div>
            <div>
              <div className="flex items-center gap-1.5">
                <span className="text-xs font-bold text-slate-100">وارپ در وارپ (WARP on WARP دو مرحله‌ای)</span>
                <span className="text-[9px] bg-[#ffe600] text-slate-950 font-black px-1.5 py-0.2 rounded">
                  تضمینی ضد فیلتر
                </span>
              </div>
              <p className="text-[10px] text-slate-400 mt-0.5">
                کپسوله‌سازی دو لایه کلودفلر؛ دور زدن کامل اختلال و قطعی همراه اول و ایرانسل
              </p>
            </div>
          </div>
          <span className="text-[11px] font-mono text-[#ffe600] font-bold px-2 py-1 rounded-lg bg-[#ffe600]/10 border border-[#ffe600]/30 shrink-0">
            فعال‌سازی
          </span>
        </div>
      </div>
    </div>
  );
};
