import React from 'react';
import { X, ShieldAlert, Zap, Server, CheckCircle2, AlertTriangle, ArrowRightLeft, Radio } from 'lucide-react';
import { VPNSettings } from '../types/vpn';

interface NationalNetFallbackModalProps {
  isOpen: boolean;
  onClose: () => void;
  settings: VPNSettings;
  onUpdateSettings: (newSettings: Partial<VPNSettings>) => void;
  onTriggerEmergencyNational: () => void;
  isNationalActive: boolean;
}

export const NationalNetFallbackModal: React.FC<NationalNetFallbackModalProps> = ({
  isOpen,
  onClose,
  settings,
  onUpdateSettings,
  onTriggerEmergencyNational,
  isNationalActive
}) => {
  if (!isOpen) return null;

  const SNI_PRESETS = [
    { domain: 'shaparak.ir', desc: 'شبکه پرداخت بانکی شاپرک (غیرقابل مسدودی ۱۰۰٪)' },
    { domain: 'telewebion.com', desc: 'تلوبیون صدا و سیما (ترافیک سفید ملی)' },
    { domain: 'shad.ir', desc: 'شبکه شاد آموزش و پرورش (اولویت اول پهنای باند)' },
    { domain: 'bankmellat.ir', desc: 'درگاه پرداخت بانک ملت (بدون محدودیت فایروال)' },
    { domain: 'speedtest.ir', desc: 'سرورهای تست سرعت داخلی' },
  ];

  return (
    <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center bg-black/85 backdrop-blur-sm p-0 sm:p-4 animate-in fade-in duration-200">
      <div className="w-full sm:max-w-md bg-[#0e101a] border border-[#00ff66]/30 rounded-t-3xl sm:rounded-3xl max-h-[92vh] flex flex-col overflow-hidden shadow-[0_0_40px_rgba(0,255,102,0.15)]">
        {/* Header */}
        <div className="p-4 border-b border-slate-800 flex items-center justify-between bg-gradient-to-r from-[#00ff66]/10 via-[#0e101a] to-transparent">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-xl bg-[#00ff66]/20 border border-[#00ff66]/40 flex items-center justify-center text-[#00ff66]">
              <Zap size={20} className="animate-pulse" />
            </div>
            <div>
              <h3 className="font-bold text-slate-100 text-sm flex items-center gap-1.5">
                <span>سوییچ هوشمند اینترنت ملی</span>
                <span className="text-[10px] bg-[#00ff66] text-slate-950 font-black px-1.5 py-0.5 rounded">
                  فوق پیشرفته
                </span>
              </h3>
              <p className="text-[11px] text-slate-400">انتقال خودکار هنگام ضعیف شدن یا قطعی اینترنت بین‌الملل</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="w-8 h-8 rounded-full bg-slate-800/80 text-slate-400 hover:text-white flex items-center justify-center"
          >
            <X size={18} />
          </button>
        </div>

        {/* Scrollable Content */}
        <div className="flex-1 overflow-y-auto p-4 space-y-4">
          {/* Active Status Banner */}
          <div className={`p-3.5 rounded-2xl border flex items-center justify-between ${
            isNationalActive 
              ? 'bg-[#00ff66]/15 border-[#00ff66]/60 text-[#00ff66]' 
              : 'bg-[#121422] border-slate-800 text-slate-300'
          }`}>
            <div className="flex items-center gap-3">
              <div className={`w-3 h-3 rounded-full ${isNationalActive ? 'bg-[#00ff66] animate-ping' : 'bg-slate-600'}`} />
              <div>
                <span className="text-xs font-bold block">
                  {isNationalActive ? 'حالت اینترنت ملی فعال است (تونل معکوس برپاست)' : 'حالت اینترنت بین‌الملل فعال است'}
                </span>
                <span className="text-[10px] text-slate-400">
                  {isNationalActive ? 'ترافیک از طریق سرورهای داخلی و SNI سفید عبور داده می‌شود.' : 'پایشگر در حال رصد کیفیت شبکه است.'}
                </span>
              </div>
            </div>
            <button
              onClick={onTriggerEmergencyNational}
              className="text-[10px] px-2.5 py-1.5 rounded-xl bg-gradient-to-r from-[#00ff66] to-[#00e5ff] text-slate-950 font-bold hover:opacity-90 transition-opacity cursor-pointer whitespace-nowrap"
            >
              {isNationalActive ? 'بازگشت به بین‌الملل' : 'تست سوییچ اضطراری'}
            </button>
          </div>

          {/* Toggle 1: Auto Fallback when Internet is Weak */}
          <div className="p-3.5 rounded-2xl bg-[#121422] border border-slate-800/90 flex items-center justify-between">
            <div className="pr-1">
              <span className="text-xs font-bold text-slate-100 block">اتصال خودکار هنگام ضعیف شدن اینترنت</span>
              <span className="text-[11px] text-slate-400 block mt-0.5 leading-relaxed">
                در صورت افزایش پینگ یا قطع شدن اینترنت خارجی، بدون معطلی به پل معکوس ملی متصل شود تا هیچ قطعی رخ ندهد.
              </span>
            </div>
            <label className="relative inline-flex items-center cursor-pointer">
              <input
                type="checkbox"
                checked={settings.nationalAutoFallback}
                onChange={(e) => onUpdateSettings({ nationalAutoFallback: e.target.checked })}
                className="sr-only peer"
              />
              <div className="w-11 h-6 bg-slate-700 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-[#00ff66]"></div>
            </label>
          </div>

          {/* Fallback Latency Threshold */}
          <div className="p-3.5 rounded-2xl bg-[#121422] border border-slate-800/90 space-y-2">
            <div className="flex items-center justify-between text-xs">
              <span className="font-bold text-slate-200">آستانه تاخیر سوییچ اضطراری:</span>
              <span className="text-[#ffe600] font-mono font-bold">{settings.failoverLatencyThreshold} میلی‌ثانیه</span>
            </div>
            <input
              type="range"
              min="200"
              max="800"
              step="50"
              value={settings.failoverLatencyThreshold}
              onChange={(e) => onUpdateSettings({ failoverLatencyThreshold: Number(e.target.value) })}
              className="w-full accent-[#ffe600] bg-slate-800 rounded-lg h-1.5 cursor-pointer"
            />
            <div className="flex justify-between text-[10px] text-slate-500 font-mono">
              <span>۲۰۰ms (سریع‌تر)</span>
              <span>۵۰۰ms (پیش‌فرض)</span>
              <span>۸۰۰ms (آرام‌تر)</span>
            </div>
          </div>

          {/* Fake SNI Spoofing Section */}
          <div className="p-3.5 rounded-2xl bg-[#121422] border border-slate-800/90 space-y-3">
            <div className="flex items-center justify-between">
              <div>
                <span className="text-xs font-bold text-slate-100 block">جعل دامنه‌های سفید داخلی (Fake SNI)</span>
                <span className="text-[10px] text-slate-400">ترافیک وی‌پی‌ان را مانند سایت‌های مجاز ایرانی نمایش می‌دهد</span>
              </div>
              <label className="relative inline-flex items-center cursor-pointer">
                <input
                  type="checkbox"
                  checked={settings.fakeSniEnabled}
                  onChange={(e) => onUpdateSettings({ fakeSniEnabled: e.target.checked })}
                  className="sr-only peer"
                />
                <div className="w-11 h-6 bg-slate-700 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-[#ff2d78]"></div>
              </label>
            </div>

            {settings.fakeSniEnabled && (
              <div className="space-y-2 pt-1 border-t border-slate-800/80">
                <span className="text-[11px] text-slate-300 font-medium block">انتخاب دامنه جعلی (سفید):</span>
                {SNI_PRESETS.map((item) => (
                  <div
                    key={item.domain}
                    onClick={() => onUpdateSettings({ selectedFakeSni: item.domain })}
                    className={`p-2.5 rounded-xl border text-xs cursor-pointer flex items-center justify-between transition-colors ${
                      settings.selectedFakeSni === item.domain
                        ? 'bg-[#ff2d78]/15 border-[#ff2d78]/50 text-white'
                        : 'bg-[#181a2b] border-slate-800 text-slate-400 hover:text-slate-200'
                    }`}
                  >
                    <div>
                      <span className="font-mono font-bold text-slate-100">{item.domain}</span>
                      <span className="block text-[10px] text-slate-400 mt-0.5">{item.desc}</span>
                    </div>
                    {settings.selectedFakeSni === item.domain && (
                      <CheckCircle2 size={16} className="text-[#ff2d78]" />
                    )}
                  </div>
                ))}
              </div>
            )}
          </div>

          {/* Reverse Tunneling Tech Specs */}
          <div className="p-3.5 rounded-2xl bg-[#090a12] border border-slate-800/80 text-[11px] text-slate-400 space-y-1.5 leading-relaxed">
            <span className="text-slate-200 font-bold block flex items-center gap-1.5 text-[#00ff66]">
              <CheckCircle2 size={14} /> مکانیزم ضد قطع اینترنت ملی در MatVPN:
            </span>
            <p>
              هنگامی که اینترنت کشور به اصطلاح «ملی» یا دچار اختلال لایه ۷ می‌شود، کلیه پورت‌های UDP و IPهای خارجی مسدود می‌گردند. مات وی‌پی‌ان بلافاصله ترافیک را از طریق پروتکل ترکیبی VLESS Reality + TLS Fragment بر روی پورت‌های مجاز دیتاسنترهای داخلی نظیر آسیاتک و افرانت رله نموده و با جعل SNIهای شاپرک و تلوبیون، تحریم‌ها و فیلترینگ را به طور کامل دور می‌زند.
            </p>
          </div>
        </div>

        {/* Footer */}
        <div className="p-3.5 bg-[#0a0b12] border-t border-slate-800/80 flex items-center justify-end">
          <button
            onClick={onClose}
            className="px-5 py-2 rounded-xl bg-gradient-to-r from-[#00ff66] to-[#00e5ff] text-slate-950 font-bold text-xs hover:opacity-90 transition-opacity cursor-pointer"
          >
            ذخیره و اعمال تنظیمات
          </button>
        </div>
      </div>
    </div>
  );
};
