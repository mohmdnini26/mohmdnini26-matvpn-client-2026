import React, { useState } from 'react';
import { X, Search, Radio, Check, Zap, Globe, RefreshCw, ShieldAlert } from 'lucide-react';
import { ServerNode, VPNProtocol, ISPType, VPNCategory } from '../types/vpn';
import { SERVERS_LIST } from '../data/mockServers';
import { VpnBrandLogo } from './VpnBrandLogos';

interface ServerListModalProps {
  isOpen: boolean;
  onClose: () => void;
  activeServer: ServerNode;
  onSelectServer: (server: ServerNode) => void;
}

export const ServerListModal: React.FC<ServerListModalProps> = ({
  isOpen,
  onClose,
  activeServer,
  onSelectServer
}) => {
  const [selectedCategory, setSelectedCategory] = useState<'all' | VPNCategory>('all');
  const [selectedProtocol, setSelectedProtocol] = useState<VPNProtocol | 'all'>('all');
  const [selectedIsp, setSelectedIsp] = useState<ISPType>('all');
  const [searchQuery, setSearchQuery] = useState('');
  const [servers, setServers] = useState<ServerNode[]>(SERVERS_LIST);
  const [isPingingAll, setIsPingingAll] = useState(false);

  if (!isOpen) return null;

  const handlePingAll = () => {
    setIsPingingAll(true);
    setTimeout(() => {
      setServers(prev => 
        prev.map(s => ({
          ...s,
          ping: Math.max(25, s.ping + Math.floor((Math.random() - 0.5) * 16))
        }))
      );
      setIsPingingAll(false);
    }, 1000);
  };

  const filteredServers = servers.filter(s => {
    const isNat = s.category === 'national_emergency' || s.isNationalRelay;
    const matchesCategory = 
      selectedCategory === 'all' ||
      (selectedCategory === 'national_emergency' ? isNat : !isNat);
    const matchesProtocol = selectedProtocol === 'all' || s.protocol === selectedProtocol;
    const matchesIsp = selectedIsp === 'all' || s.recommendedIsps.includes(selectedIsp);
    const matchesQuery = 
      s.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      s.nameFa.includes(searchQuery) ||
      s.country.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesProtocol && matchesIsp && matchesQuery;
  });

  const getLatencyBadgeColor = (ping: number) => {
    if (ping < 60) return 'text-[#00ff66] bg-[#00ff66]/10 border-[#00ff66]/30';
    if (ping < 90) return 'text-[#ffe600] bg-[#ffe600]/10 border-[#ffe600]/30';
    return 'text-[#ff7700] bg-[#ff7700]/10 border-[#ff7700]/30';
  };

  return (
    <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center bg-black/80 backdrop-blur-sm p-0 sm:p-4 animate-in fade-in duration-200">
      <div className="w-full sm:max-w-md bg-[#0e101a] border border-slate-800 rounded-t-3xl sm:rounded-3xl max-h-[90vh] flex flex-col overflow-hidden shadow-2xl">
        {/* Header */}
        <div className="p-4 border-b border-slate-800/80 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-xl bg-gradient-to-tr from-[#ff2d78] to-[#ff7700] flex items-center justify-center text-white">
              <Globe size={18} />
            </div>
            <div>
              <h3 className="font-bold text-slate-100 text-sm">انتخاب لوکیشن و پروتکل</h3>
              <p className="text-[11px] text-slate-400">تمام پروتکل‌ها و تونل‌های اینترنت ملی</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="w-8 h-8 rounded-full bg-slate-800/80 text-slate-400 hover:text-white flex items-center justify-center"
          >
            <X size={18} />
          </button>
        </div>

        {/* Search & Ping Button */}
        <div className="p-3 bg-[#0a0b12] border-b border-slate-800/50 flex items-center gap-2">
          <div className="flex-1 relative">
            <Search size={15} className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-500" />
            <input
              type="text"
              placeholder="جستجوی کشور، پروتکل، آی‌پی..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full bg-[#121422] border border-slate-800 rounded-xl pr-9 pl-3 py-1.5 text-xs text-slate-200 focus:outline-none focus:border-[#ff2d78]"
            />
          </div>
          <button
            onClick={handlePingAll}
            disabled={isPingingAll}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-[#1a1d2e] border border-slate-700/80 text-[11px] text-slate-300 hover:text-white hover:border-[#00ff66] transition-colors cursor-pointer"
          >
            <RefreshCw size={12} className={isPingingAll ? 'animate-spin text-[#00ff66]' : ''} />
            <span>تست پینگ</span>
          </button>
        </div>

        {/* 2 Main Category Filter Tabs */}
        <div className="px-3 pt-2 pb-1.5 flex items-center gap-1.5 bg-[#0a0b12] border-b border-slate-800/80">
          <button
            onClick={() => setSelectedCategory('all')}
            className={`py-1 px-2 rounded-xl text-[10px] font-bold transition-all cursor-pointer ${
              selectedCategory === 'all'
                ? 'bg-[#1f2336] text-white border border-slate-700'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            همه
          </button>
          <button
            onClick={() => setSelectedCategory('international')}
            className={`flex-1 py-1 px-2 rounded-xl text-[10px] font-bold transition-all cursor-pointer flex items-center justify-center gap-1 ${
              selectedCategory === 'international'
                ? 'bg-gradient-to-r from-[#ff2d78] to-[#ff7700] text-white shadow-sm'
                : 'text-slate-400 hover:text-white bg-[#121422]'
            }`}
          >
            <Globe size={11} />
            <span>۱. بین‌المللی و ضد DPI</span>
          </button>
          <button
            onClick={() => setSelectedCategory('national_emergency')}
            className={`flex-1 py-1 px-2 rounded-xl text-[10px] font-bold transition-all cursor-pointer flex items-center justify-center gap-1 ${
              selectedCategory === 'national_emergency'
                ? 'bg-gradient-to-r from-[#00ff66] to-[#00e5ff] text-slate-950 font-black shadow-sm'
                : 'text-slate-400 hover:text-white bg-[#121422]'
            }`}
          >
            <ShieldAlert size={11} />
            <span>۲. ضد قطعی ملی و اضطراری</span>
          </button>
        </div>

        {/* Protocol Filter Tabs with Brand Logos */}
        <div className="px-3 py-2 flex items-center gap-1.5 overflow-x-auto no-scrollbar border-b border-slate-800/50 bg-[#0c0d16]">
          {[
            { id: 'all', label: 'همه پروتکل‌ها' },
            { id: 'warp_in_warp', label: 'وارپ در وارپ' },
            { id: 'v2ray', label: 'وی‌تو‌ری' },
            { id: 'singbox', label: 'Sing-Box' },
            { id: 'warp', label: 'WARP+' },
            { id: 'amnezia', label: 'AmneziaWG' },
            { id: 'github_tunnel', label: 'گیت‌هاب تانل' },
            { id: 'telegram_proxy', label: 'پروکسی تلگرام' },
            { id: 'windscribe', label: 'وینداسکرایب' },
            { id: 'openvpn', label: 'OpenVPN' },
            { id: 'tor', label: 'Tor' },
            { id: 'psiphon', label: 'Psiphon' },
            { id: 'wireguard', label: 'WireGuard' },
            { id: 'proton', label: 'Proton' },
            { id: 'lantern', label: 'Lantern' },
            { id: 'iran_relay', label: 'پل اینترنت ملی' },
          ].map(tab => (
            <button
              key={tab.id}
              onClick={() => setSelectedProtocol(tab.id as VPNProtocol | 'all')}
              className={`flex items-center gap-1.5 px-2.5 py-1 rounded-lg text-[11px] font-medium whitespace-nowrap transition-all cursor-pointer ${
                selectedProtocol === tab.id
                  ? 'bg-gradient-to-r from-[#ff2d78] to-[#ff7700] text-white shadow-sm font-bold'
                  : 'bg-[#151724] text-slate-400 hover:text-slate-200'
              }`}
            >
              {tab.id !== 'all' && (
                <div className="w-4 h-4 flex items-center justify-center shrink-0">
                  <VpnBrandLogo protocol={tab.id} size={15} />
                </div>
              )}
              <span>{tab.label}</span>
            </button>
          ))}
        </div>

        {/* ISP Filter Pills */}
        <div className="px-3 py-2 flex items-center gap-1.5 text-[10px] bg-[#090a10] border-b border-slate-800/40">
          <span className="text-slate-500 font-medium">اپراتور شما:</span>
          {[
            { id: 'all', label: 'همه' },
            { id: 'mci', label: 'همراه اول' },
            { id: 'mtn', label: 'ایرانسل' },
            { id: 'rightel', label: 'رایتل' },
            { id: 'mokhaberat', label: 'مخابرات' },
          ].map(isp => (
            <button
              key={isp.id}
              onClick={() => setSelectedIsp(isp.id as ISPType)}
              className={`px-2 py-0.5 rounded-md transition-colors cursor-pointer ${
                selectedIsp === isp.id
                  ? 'bg-[#00ff66]/20 border border-[#00ff66]/40 text-[#00ff66] font-bold'
                  : 'bg-slate-800/60 text-slate-400 hover:text-slate-200'
              }`}
            >
              {isp.label}
            </button>
          ))}
        </div>

        {/* Server List Items */}
        <div className="flex-1 overflow-y-auto p-3 space-y-2">
          {filteredServers.length === 0 ? (
            <div className="py-12 text-center text-slate-500 text-xs">
              هیچ سروری با فیلترهای انتخابی یافت نشد.
            </div>
          ) : (
            filteredServers.map((server) => {
              const isSelected = activeServer.id === server.id;
              return (
                <div
                  key={server.id}
                  onClick={() => {
                    onSelectServer(server);
                    onClose();
                  }}
                  className={`p-3 rounded-2xl border transition-all cursor-pointer flex items-center justify-between ${
                    isSelected
                      ? 'bg-gradient-to-r from-[#ff2d78]/15 via-[#ffe600]/10 to-[#00ff66]/15 border-[#00ff66]/60 shadow-[0_0_15px_rgba(0,255,102,0.2)]'
                      : 'bg-[#121422] border-slate-800/70 hover:border-slate-700 hover:bg-[#16192a]'
                  }`}
                >
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 rounded-xl bg-[#090a14] border border-slate-700/80 flex items-center justify-center relative p-1 shrink-0 select-none">
                      <VpnBrandLogo protocol={server.protocol} size={24} />
                      <span className="absolute -bottom-1 -right-1 text-[11px] drop-shadow">{server.flag}</span>
                    </div>
                    <div>
                      <div className="flex items-center gap-1.5 flex-wrap">
                        <span className="font-bold text-slate-100 text-xs">{server.nameFa}</span>
                        {server.protocol === 'warp_in_warp' && (
                          <span className="text-[9px] bg-[#ffe600] text-slate-950 px-1.5 py-0.5 rounded font-black">
                            دوبل وارپ
                          </span>
                        )}
                        {server.isNationalRelay && (
                          <span className="text-[9px] bg-[#00ff66]/20 text-[#00ff66] px-1.5 py-0.5 rounded font-bold border border-[#00ff66]/40">
                            ضد ملی
                          </span>
                        )}
                        {server.isCleanIp && (
                          <span className="text-[9px] bg-[#ffe600]/20 text-[#ffe600] px-1.5 py-0.5 rounded font-bold border border-[#ffe600]/40">
                            کلین آی‌پی
                          </span>
                        )}
                      </div>
                      <div className="flex items-center gap-2 mt-1 text-[10px] text-slate-400 font-mono">
                        <span className="uppercase text-[#ff2d78] font-bold">{server.protocol.replace('_', ' ')}</span>
                        <span>•</span>
                        <span>{server.serverIp}</span>
                        <span>•</span>
                        <span>بار: {server.loadPercentage}%</span>
                      </div>
                    </div>
                  </div>

                  <div className="flex items-center gap-2">
                    <span className={`px-2 py-0.5 rounded-full border text-[11px] font-mono font-bold ${getLatencyBadgeColor(server.ping)}`}>
                      {server.ping} ms
                    </span>
                    {isSelected && (
                      <div className="w-5 h-5 rounded-full bg-[#00ff66] text-slate-950 flex items-center justify-center">
                        <Check size={12} strokeWidth={3} />
                      </div>
                    )}
                  </div>
                </div>
              );
            })
          )}
        </div>

        {/* Footer info */}
        <div className="p-3 bg-[#0a0b12] border-t border-slate-800/80 text-center text-[11px] text-slate-400">
          <span>سیستم هوشمند MatVPN سرورها را با کمترین تأخیر و بالاترین مقاومت در برابر فیلترینگ اولویت‌بندی می‌کند.</span>
        </div>
      </div>
    </div>
  );
};
