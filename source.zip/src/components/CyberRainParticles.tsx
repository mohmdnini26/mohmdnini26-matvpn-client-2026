import React, { useEffect, useRef, useState } from 'react';

interface CyberRainParticlesProps {
  isConnected: boolean;
}

interface Drop {
  x: number;
  y: number;
  length: number;
  speed: number;
  opacity: number;
  thickness: number;
}

interface SplashRipple {
  x: number;
  y: number;
  radiusX: number;
  radiusY: number;
  maxRadius: number;
  opacity: number;
  growthRate: number;
}

interface SplashDroplet {
  x: number;
  y: number;
  vx: number;
  vy: number;
  gravity: number;
  radius: number;
  opacity: number;
  life: number;
}

// 7 Neon Rainbow Colors that shift every 1 second (1000ms)
const RAINBOW_PALETTE = [
  '#ff2d78', // 0s: Hot Neon Pink (صورتی نئونی)
  '#ff7700', // 1s: Blazing Orange (نارنجی شعله‌ای)
  '#ffe600', // 2s: Electric Yellow (زرد فسفری/الکتریک)
  '#00ff66', // 3s: Phosphor Green (سبز فسفری)
  '#00e5ff', // 4s: Cyan Electric Aqua (فیروزه‌ای نئونی)
  '#3b82f6', // 5s: Electric Blue (آبی متالیک)
  '#a855f7', // 6s: Neon Purple / Violet (بنفش نئونی)
];

const COLOR_NAMES_FA = [
  'صورتی نئونی',
  'نارنجی شعله‌ای',
  'زرد فسفری',
  'سبز فسفری',
  'فیروزه‌ای نئونی',
  'آبی متالیک',
  'بنفش نئونی',
];

export const CyberRainParticles: React.FC<CyberRainParticlesProps> = ({ isConnected }) => {
  const containerRef = useRef<HTMLDivElement | null>(null);
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  
  // Color index for 1-second interval switching (shifts every 1000ms)
  const [colorIndex, setColorIndex] = useState(0);

  // Switch color exactly every 1 second (1000ms) continuously
  useEffect(() => {
    const interval = setInterval(() => {
      setColorIndex((prev) => (prev + 1) % RAINBOW_PALETTE.length);
    }, 1000);

    return () => clearInterval(interval);
  }, []);

  const currentColor = RAINBOW_PALETTE[colorIndex];
  const currentColorRef = useRef(currentColor);
  currentColorRef.current = currentColor;

  const isConnectedRef = useRef(isConnected);
  isConnectedRef.current = isConnected;

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    let animationFrameId: number;
    let time = 0;

    const updateDimensions = () => {
      if (!canvas) return;
      const rect = canvas.getBoundingClientRect();
      const parent = canvas.parentElement;
      const w = Math.max(rect.width, parent?.clientWidth || 0, 320);
      const h = Math.max(rect.height, parent?.clientHeight || 0, 500);
      canvas.width = w;
      canvas.height = h;
      return { w, h };
    };

    let { w: width, h: height } = updateDimensions() || { w: 380, h: 700 };

    // Noticeably thicker, lush cyber raindrops
    const dropCount = Math.min(55, Math.max(30, Math.floor(width / 8.5)));
    const drops: Drop[] = [];
    const ripples: SplashRipple[] = [];
    const splashDroplets: SplashDroplet[] = [];

    for (let i = 0; i < dropCount; i++) {
      drops.push({
        x: Math.random() * (width + 60),
        y: Math.random() * height,
        length: 26 + Math.random() * 30, // 26px - 56px length
        speed: 4.5 + Math.random() * 5.0,
        opacity: 0.5 + Math.random() * 0.45,
        thickness: 2.0 + Math.random() * 1.5, // 2.0px - 3.5px thickness
      });
    }

    const handleResize = () => {
      const dims = updateDimensions();
      if (dims) {
        width = dims.w;
        height = dims.h;
      }
    };

    window.addEventListener('resize', handleResize);

    // Calculate dynamic moving surface Y coordinate of the accumulated rainwater pool
    const getWaterSurfaceY = (x: number, t: number, layer: number = 0) => {
      // Puddle base height at screen bottom: ~52px to 68px
      const puddleBaseHeight = Math.min(68, Math.max(50, height * 0.082));
      const baseY = height - puddleBaseHeight;

      if (layer === 0) {
        // Main front wave: active flowing liquid
        const w1 = Math.sin(x * 0.016 + t * 2.8) * 5.2;
        const w2 = Math.cos(x * 0.032 - t * 1.9) * 3.4;
        const w3 = Math.sin(x * 0.065 + t * 4.1) * 1.6;
        return baseY + w1 + w2 + w3;
      } else {
        // Secondary back wave: deeper, out-of-phase flow
        const w1 = Math.sin(x * 0.013 + t * 1.7 + 1.8) * 4.4;
        const w2 = Math.cos(x * 0.026 - t * 1.3 + 0.9) * 2.8;
        return baseY + 5 + w1 + w2;
      }
    };

    const render = () => {
      ctx.clearRect(0, 0, width, height);

      time += 0.028;
      const activeColor = currentColorRef.current;
      const connected = isConnectedRef.current;

      // ==========================================
      // 1. DRAW ACCUMULATED RAINWATER POOL (BOTTOM)
      // ==========================================

      // --- Layer A: Secondary Deep Water Wave (Back) ---
      ctx.beginPath();
      ctx.moveTo(0, height);
      for (let x = 0; x <= width; x += 6) {
        const y = getWaterSurfaceY(x, time, 1);
        ctx.lineTo(x, y);
      }
      ctx.lineTo(width, height);
      ctx.closePath();

      const backWaterGradient = ctx.createLinearGradient(0, height - 70, 0, height);
      backWaterGradient.addColorStop(0, `${activeColor}20`);
      backWaterGradient.addColorStop(0.5, `${activeColor}12`);
      backWaterGradient.addColorStop(1, '#050711cc');
      ctx.fillStyle = backWaterGradient;
      ctx.fill();

      // --- Layer B: Main Accumulated Moving Water Pool (Front) ---
      ctx.beginPath();
      ctx.moveTo(0, height);
      const surfacePoints: { x: number; y: number }[] = [];
      for (let x = 0; x <= width; x += 5) {
        const y = getWaterSurfaceY(x, time, 0);
        surfacePoints.push({ x, y });
        ctx.lineTo(x, y);
      }
      ctx.lineTo(width, height);
      ctx.closePath();

      const puddleGradient = ctx.createLinearGradient(0, height - 60, 0, height);
      puddleGradient.addColorStop(0, `${activeColor}45`); // Luminous water surface
      puddleGradient.addColorStop(0.25, `${activeColor}30`);
      puddleGradient.addColorStop(0.7, `${activeColor}1a`);
      puddleGradient.addColorStop(1, `${activeColor}0a`);
      ctx.fillStyle = puddleGradient;
      ctx.fill();

      // --- Layer C: Glowing Moving Water Surface Crest (Meniscus line) ---
      ctx.beginPath();
      if (surfacePoints.length > 0) {
        ctx.moveTo(surfacePoints[0].x, surfacePoints[0].y);
        for (let i = 1; i < surfacePoints.length; i++) {
          ctx.lineTo(surfacePoints[i].x, surfacePoints[i].y);
        }
      }
      ctx.strokeStyle = activeColor;
      ctx.lineWidth = connected ? 2.6 : 2.0;
      ctx.shadowColor = activeColor;
      ctx.shadowBlur = connected ? 16 : 10;
      ctx.globalAlpha = 0.95;
      ctx.stroke();
      ctx.shadowBlur = 0; // reset

      // --- Layer D: Moving Underwater Caustics & Liquid Highlights ---
      const causticCount = 4;
      ctx.lineWidth = 1.4;
      for (let c = 0; c < causticCount; c++) {
        const cOffset = c * 10;
        const cPhase = c * 1.4;
        ctx.beginPath();
        const startX = ((time * 30 + c * 80) % (width + 100)) - 50;
        const strandLength = 70 + (c % 3) * 30;
        const endX = Math.min(width, startX + strandLength);

        if (startX < width && endX > 0) {
          for (let cx = Math.max(0, startX); cx <= endX; cx += 8) {
            const cy = getWaterSurfaceY(cx, time, 0) + 12 + cOffset + Math.sin(cx * 0.05 + time * 3 + cPhase) * 2;
            if (cx === Math.max(0, startX)) {
              ctx.moveTo(cx, cy);
            } else {
              ctx.lineTo(cx, cy);
            }
          }
          ctx.strokeStyle = `${activeColor}35`;
          ctx.globalAlpha = 0.55;
          ctx.stroke();
        }
      }

      // ==========================================
      // 2. FALLING RAINDROPS & WATER POOL COLLISION
      // ==========================================
      for (let i = 0; i < drops.length; i++) {
        const drop = drops[i];

        // Slanted angle for delicate cyber-rain
        const startX = drop.x;
        const startY = drop.y;
        const endX = drop.x - drop.length * 0.22;
        const endY = drop.y + drop.length;

        // Gradient streak for soft drop head & trailing tail
        const gradient = ctx.createLinearGradient(startX, startY, endX, endY);
        gradient.addColorStop(0, 'transparent');
        gradient.addColorStop(0.3, `${activeColor}40`);
        gradient.addColorStop(0.7, `${activeColor}aa`);
        gradient.addColorStop(1, activeColor);

        ctx.beginPath();
        ctx.moveTo(startX, startY);
        ctx.lineTo(endX, endY);
        ctx.strokeStyle = gradient;
        ctx.lineWidth = drop.thickness;
        ctx.globalAlpha = drop.opacity * (connected ? 0.98 : 0.85);
        ctx.lineCap = 'round';

        ctx.shadowBlur = connected ? 14 : 7;
        ctx.shadowColor = activeColor;
        ctx.stroke();

        // Droplet head at tip
        ctx.beginPath();
        ctx.arc(endX, endY, drop.thickness * 1.1, 0, Math.PI * 2);
        ctx.fillStyle = activeColor;
        ctx.fill();

        // Move drop downwards
        drop.y += drop.speed * (connected ? 1.3 : 1.05);
        drop.x -= drop.speed * 0.22;

        // Check collision with the moving surface of the accumulated rainwater pool!
        const waterSurfaceAtDrop = getWaterSurfaceY(endX, time, 0);

        if (endY >= waterSurfaceAtDrop) {
          // Trigger water puddle ripples (elliptical surface ring)
          ripples.push({
            x: endX,
            y: waterSurfaceAtDrop,
            radiusX: 2,
            radiusY: 0.9,
            maxRadius: 8 + Math.random() * 12,
            opacity: 0.9,
            growthRate: 0.5 + Math.random() * 0.4,
          });

          // Trigger 2 tiny splash micro-droplets bouncing out of the water pool
          for (let d = 0; d < 2; d++) {
            splashDroplets.push({
              x: endX,
              y: waterSurfaceAtDrop - 1,
              vx: (Math.random() - 0.5) * 2.8,
              vy: -(1.8 + Math.random() * 2.4),
              gravity: 0.16,
              radius: 1.0 + Math.random() * 0.8,
              opacity: 0.9,
              life: 1.0,
            });
          }

          // Respawn drop at top
          drop.y = -drop.length - Math.random() * 40;
          drop.x = Math.random() * (width + 80);
          drop.speed = 4.5 + Math.random() * 5.0;
        }

        if (drop.x < -20) {
          drop.x = width + 20;
        }
      }

      // ==========================================
      // 3. DRAW & ANIMATE WATER SURFACE RIPPLES
      // ==========================================
      for (let i = ripples.length - 1; i >= 0; i--) {
        const rip = ripples[i];
        ctx.beginPath();
        ctx.ellipse(rip.x, rip.y, rip.radiusX, rip.radiusY, 0, 0, Math.PI * 2);
        ctx.strokeStyle = activeColor;
        ctx.lineWidth = 1.3;
        ctx.globalAlpha = rip.opacity;
        ctx.shadowBlur = 8;
        ctx.shadowColor = activeColor;
        ctx.stroke();

        rip.radiusX += rip.growthRate * 1.5;
        rip.radiusY += rip.growthRate * 0.55;
        rip.opacity -= 0.04;

        if (rip.opacity <= 0 || rip.radiusX >= rip.maxRadius * 2) {
          ripples.splice(i, 1);
        }
      }

      // ==========================================
      // 4. DRAW & ANIMATE SPLASH MICRO-DROPLETS
      // ==========================================
      for (let i = splashDroplets.length - 1; i >= 0; i--) {
        const sd = splashDroplets[i];
        ctx.beginPath();
        ctx.arc(sd.x, sd.y, sd.radius, 0, Math.PI * 2);
        ctx.fillStyle = activeColor;
        ctx.globalAlpha = sd.opacity;
        ctx.shadowBlur = 6;
        ctx.shadowColor = activeColor;
        ctx.fill();

        sd.x += sd.vx;
        sd.y += sd.vy;
        sd.vy += sd.gravity;
        sd.opacity -= 0.04;

        if (sd.opacity <= 0 || sd.y > height) {
          splashDroplets.splice(i, 1);
        }
      }

      ctx.shadowBlur = 0;
      ctx.globalAlpha = 1.0;
      animationFrameId = requestAnimationFrame(render);
    };

    render();

    return () => {
      window.removeEventListener('resize', handleResize);
      cancelAnimationFrame(animationFrameId);
    };
  }, []);

  return (
    <div 
      ref={containerRef}
      className="absolute inset-0 pointer-events-none overflow-hidden z-20 select-none"
    >
      <canvas
        ref={canvasRef}
        className="w-full h-full block pointer-events-none"
      />

      {/* Top Floating Cyber Rain & Water Color Indicator (Changes every 1 second) */}
      <div className="absolute top-9 left-1/2 -translate-x-1/2 pointer-events-none transition-all duration-500 opacity-90 z-30">
        <div 
          className="flex items-center gap-1.5 px-3 py-0.5 rounded-full text-[10px] font-mono font-bold backdrop-blur-md border shadow-md transition-all duration-700"
          style={{
            color: currentColor,
            borderColor: `${currentColor}60`,
            backgroundColor: `${currentColor}18`,
            boxShadow: `0 0 14px ${currentColor}50`
          }}
        >
          <span className="w-2.5 h-2.5 rounded-full animate-ping" style={{ backgroundColor: currentColor }} />
          <span>🌧️ باران و آب متحرک: {COLOR_NAMES_FA[colorIndex]} (۱ ثانیه‌ای)</span>
        </div>
      </div>

      {/* Subtle Bottom Rainwater Pool Indicator Tag */}
      <div 
        className="absolute bottom-2 left-1/2 -translate-x-1/2 pointer-events-none transition-all duration-700 opacity-80 z-30"
      >
        <div 
          className="flex items-center gap-1.5 px-2.5 py-0.5 rounded-full text-[9px] font-mono font-medium backdrop-blur-sm border transition-all duration-500"
          style={{
            color: currentColor,
            borderColor: `${currentColor}40`,
            backgroundColor: `${currentColor}12`,
            boxShadow: `0 0 10px ${currentColor}30`
          }}
        >
          <span className="w-1.5 h-1.5 rounded-full animate-pulse" style={{ backgroundColor: currentColor }} />
          <span>🌊 حوضچه آب باران مواج در حال حرکت</span>
        </div>
      </div>
    </div>
  );
};
