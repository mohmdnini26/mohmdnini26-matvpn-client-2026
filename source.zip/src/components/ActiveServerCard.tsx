import React from 'react';
import { ChevronLeft, ShieldCheck, Zap, Globe, Sparkles } from 'lucide-react';
import { ServerNode } from '../types/vpn';
import { VpnBrandLogo } from './VpnBrandLogos';

interface ActiveServerCardProps {
  server: ServerNode;
  onOpenServerModal: () => void;
  isNationalActive: boolean;
}

export const ActiveServerCard: React.FC<ActiveServerCardProps> = ({
  server,
  onOpenServerModal,
  isNationalActive
}) => {
  return (
    <div className="w-full px-4 my-2">
      <div 
        onClick={onOpenServerModal}
        className="w-full p-3.5 rounded-2xl bg-gradient-to-r from-[#121422] to-[#181b2d] border border-slate-800 hover:border-slate-700 transition-all cursor-pointer shadow-lg hover:shadow-[0_0_20px_rgba(255,45,120,0.15)] flex items-center justify-between group"
      >
        <div className="flex items-center gap-3">
          <div className="w-12 h-12 rounded-2xl bg-[#090a12] border border-slate-700/80 flex items-center justify-center relative shadow-inner select-none p-1.5">
            <VpnBrandLogo protocol={server.protocol} size={28} />
            <span className="absolute -bottom-1 -right-1 text-xs drop-shadow">{server.flag}</span>
          </div>
          <div>
            <div className="flex items-center gap-1.5">
              <span className="font-bold text-slate-100 text-xs sm:text-sm">{server.nameFa}</span>
              {isNationalActive ? (
                <span className="text-[9px] bg-[#00ff66]/20 text-[#00ff66] px-1.5 py-0.5 rounded font-black border border-[#00ff66]/40 animate-pulse">
                  پل ملی فعال
                </span>
              ) : (
                <span className="text-[9px] bg-[#ff2d78]/20 text-[#ff2d78] px-1.5 py-0.5 rounded font-bold border border-[#ff2d78]/30">
                  {server.protocol.toUpperCase()}
                </span>
              )}
            </div>
            <div className="flex items-center gap-2 mt-1 text-[11px] text-slate-400">
              <span className="font-mono text-slate-300">{server.country}</span>
              <span>•</span>
              <span className="font-mono text-[#00ff66] font-bold">{server.ping} ms</span>
              <span>•</span>
              <span className="text-slate-500">بار سرور: {server.loadPercentage}%</span>
            </div>
          </div>
        </div>

        <div className="flex items-center gap-2 text-slate-400 group-hover:text-white transition-colors">
          <span className="text-xs hidden sm:inline">تغییر</span>
          <div className="w-7 h-7 rounded-full bg-slate-800/80 flex items-center justify-center">
            <ChevronLeft size={16} />
          </div>
        </div>
      </div>
    </div>
  );
};
