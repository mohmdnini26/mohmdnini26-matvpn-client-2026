import React, { useEffect, useState } from 'react';
import { Power, RefreshCw, Sparkles, Heart, Shield, Zap } from 'lucide-react';
import { ConnectionStatus } from '../types/vpn';

interface ConnectButtonProps {
  status: ConnectionStatus;
  onToggle: () => void;
  connectingStepText?: string;
  ping: number;
}

// 7 Neon Rainbow Colors for 1-second interval shifting when connected
const RAINBOW_PALETTE = [
  { hex: '#ff2d78', name: 'صورتی نئونی', shadow: 'rgba(255, 45, 120, 0.6)' },
  { hex: '#ff7700', name: 'نارنجی شعله‌ای', shadow: 'rgba(255, 119, 0, 0.6)' },
  { hex: '#ffe600', name: 'زرد فسفری', shadow: 'rgba(255, 230, 0, 0.6)' },
  { hex: '#00ff66', name: 'سبز فسفری', shadow: 'rgba(0, 255, 102, 0.6)' },
  { hex: '#00e5ff', name: 'فیروزه‌ای نئونی', shadow: 'rgba(0, 229, 255, 0.6)' },
  { hex: '#3b82f6', name: 'آبی متالیک', shadow: 'rgba(59, 130, 246, 0.6)' },
  { hex: '#a855f7', name: 'بنفش نئونی', shadow: 'rgba(168, 85, 247, 0.6)' },
];

export const ConnectButton: React.FC<ConnectButtonProps> = ({
  status,
  onToggle,
  connectingStepText,
  ping
}) => {
  const isConnected = status === 'connected';
  const isConnecting = status === 'connecting';
  const isSwitching = status === 'switching_to_national';

  // 1-second color cycling timer when connected
  const [colorIndex, setColorIndex] = useState(0);

  useEffect(() => {
    if (!isConnected) {
      setColorIndex(3); // Default green when not cycling
      return;
    }

    const interval = setInterval(() => {
      setColorIndex((prev) => (prev + 1) % RAINBOW_PALETTE.length);
    }, 1000);

    return () => clearInterval(interval);
  }, [isConnected]);

  const currentColor = isConnected ? RAINBOW_PALETTE[colorIndex] : RAINBOW_PALETTE[0];

  return (
    <div className="relative flex flex-col items-center justify-center my-6">
      {/* Outer Glow Pulse Rings */}
      {isConnected && (
        <>
          <div 
            className="absolute w-60 h-60 rounded-full blur-3xl animate-pulse pointer-events-none transition-colors duration-700 opacity-60"
            style={{
              background: `radial-gradient(circle, ${currentColor.hex}77 0%, ${currentColor.hex}22 55%, transparent 75%)`
            }}
          />
          <div 
            className="absolute w-48 h-48 rounded-full border-2 animate-ping opacity-35 pointer-events-none transition-colors duration-700"
            style={{ borderColor: currentColor.hex }}
          />
        </>
      )}

      {isConnecting && (
        <div className="absolute w-52 h-52 rounded-full border border-dashed border-[#ff7700]/60 animate-spin-slow pointer-events-none" />
      )}

      {/* Button Wrapper with 7-Color Rainbow Gradient Border */}
      <div className="relative group p-1.5 rounded-full">
        {/* Animated Rainbow Border Layer */}
        <div 
          className="absolute inset-0 rounded-full transition-all duration-700"
          style={
            isConnected
              ? {
                  background: `linear-gradient(135deg, ${currentColor.hex}, #ffffff, ${currentColor.hex})`,
                  boxShadow: `0 0 40px ${currentColor.shadow}`,
                }
              : isConnecting || isSwitching
              ? {
                  background: 'linear-gradient(135deg, #ff2d78, #ff7700, #ffe600)',
                  boxShadow: '0 0 30px rgba(255,119,0,0.5)',
                }
              : {
                  background: 'linear-gradient(135deg, #ff2d78, #ff7700, #ffe600, #00ff66)',
                  boxShadow: '0 0 22px rgba(255,45,120,0.4)',
                }
          }
        />

        {/* Inner Button Body */}
        <button
          onClick={onToggle}
          className={`relative w-36 h-36 rounded-full flex flex-col items-center justify-center transition-all duration-500 cursor-pointer active:scale-95 ${
            isConnected
              ? 'bg-[#06080d]'
              : isConnecting
              ? 'bg-[#150f0c] text-[#ff7700]'
              : 'bg-[#0c0d16] text-slate-100 hover:bg-[#121422]'
          }`}
          style={
            isConnected
              ? {
                  border: `2px solid ${currentColor.hex}60`,
                  boxShadow: `inset 0 0 25px ${currentColor.hex}30`
                }
              : {}
          }
        >
          {/* Inner Accent Ring */}
          <div 
            className="absolute inset-2 rounded-full border transition-colors duration-700 pointer-events-none"
            style={{
              borderColor: isConnected
                ? `${currentColor.hex}50`
                : isConnecting
                ? '#ff770050'
                : '#334155'
            }}
          />

          {/* Central Heartwarming & Delightful Icon */}
          <div className="relative z-10 transition-transform duration-300">
            {isConnecting || isSwitching ? (
              <RefreshCw size={44} className="animate-spin text-[#ff7700]" />
            ) : isConnected ? (
              <div className="flex flex-col items-center select-none">
                {/* Heartwarming Iridescent Freedom SVG Emblem */}
                <div className="relative flex items-center justify-center">
                  <svg
                    width="54"
                    height="54"
                    viewBox="0 0 100 100"
                    fill="none"
                    xmlns="http://www.w3.org/2000/svg"
                    className="drop-shadow-lg transition-all duration-700"
                  >
                    <defs>
                      <linearGradient id="shieldGrad" x1="0%" y1="0%" x2="100%" y2="100%">
                        <stop offset="0%" stopColor={currentColor.hex} />
                        <stop offset="50%" stopColor="#ffffff" />
                        <stop offset="100%" stopColor={currentColor.hex} />
                      </linearGradient>
                      <radialGradient id="glowGlow" cx="50%" cy="50%" r="50%">
                        <stop offset="0%" stopColor={currentColor.hex} stopOpacity="0.8" />
                        <stop offset="100%" stopColor={currentColor.hex} stopOpacity="0" />
                      </radialGradient>
                    </defs>

                    {/* Outer Rotating Delightful Sparkle Ring */}
                    <circle
                      cx="50"
                      cy="50"
                      r="44"
                      stroke={currentColor.hex}
                      strokeWidth="2"
                      strokeDasharray="4 6"
                      className="animate-spin-slow origin-center"
                      opacity="0.7"
                    />

                    {/* Heartwarming Security Shield with Heart Silhouette */}
                    <path
                      d="M50 14L74 24V48C74 65 62 79 50 85C38 79 26 65 26 48V24L50 14Z"
                      fill={`${currentColor.hex}25`}
                      stroke="url(#shieldGrad)"
                      strokeWidth="3.2"
                      strokeLinejoin="round"
                    />

                    {/* Cute Heart-of-Freedom Center Core */}
                    <path
                      d="M50 63L45.5 59C34 49 29 43 29 36C29 30 33 26 39 26C43 26 47 28 50 32C53 28 57 26 61 26C67 26 71 30 71 36C71 43 66 49 54.5 59L50 63Z"
                      fill={currentColor.hex}
                      opacity="0.95"
                    />

                    {/* Central Golden Lightning / Key in Heart */}
                    <path
                      d="M52 30L44 44H51L48 56L58 42H51L52 30Z"
                      fill="#ffffff"
                    />

                    {/* Cute Delightful Little Sparkle Stars */}
                    <circle cx="24" cy="24" r="3" fill={currentColor.hex} className="animate-ping" />
                    <circle cx="76" cy="76" r="3" fill="#ffe600" />
                    <circle cx="76" cy="24" r="2.5" fill="#ffffff" />
                  </svg>
                </div>

                {/* Ping latency badge that also changes color */}
                <span 
                  className="text-[10px] font-mono font-bold mt-1 px-2.5 py-0.5 rounded-full border transition-all duration-700 shadow-sm"
                  style={{
                    color: currentColor.hex,
                    backgroundColor: `${currentColor.hex}18`,
                    borderColor: `${currentColor.hex}50`,
                  }}
                >
                  {ping} ms • متصل
                </span>
              </div>
            ) : (
              <div className="flex flex-col items-center">
                <Power size={44} className="text-white drop-shadow-[0_0_12px_rgba(255,45,120,0.8)] group-hover:scale-110 transition-transform" />
              </div>
            )}
          </div>
        </button>
      </div>

      {/* Status Label underneath Button */}
      <div className="mt-4 flex flex-col items-center text-center">
        {isConnected ? (
          <div className="flex flex-col items-center gap-1">
            <div className="flex items-center gap-2">
              <span 
                className="w-2.5 h-2.5 rounded-full animate-ping transition-colors duration-700"
                style={{ backgroundColor: currentColor.hex }}
              />
              <span 
                className="text-sm font-bold transition-colors duration-700"
                style={{
                  color: currentColor.hex,
                  textShadow: `0 0 12px ${currentColor.shadow}`
                }}
              >
                متصل به اینترنت آزاد و پرسرعت
              </span>
            </div>
            <span 
              className="text-[10px] font-mono font-medium transition-colors duration-700"
              style={{ color: `${currentColor.hex}dd` }}
            >
              چرخش نوری دکمه هر ثانیه: {currentColor.name}
            </span>
          </div>
        ) : isConnecting ? (
          <div className="flex flex-col items-center gap-1">
            <span className="text-sm font-bold text-[#ffe600] text-glow-yellow animate-pulse">
              در حال اتصال امن...
            </span>
            <span className="text-xs text-slate-400 font-mono">
              {connectingStepText || 'تنظیم هدرهای DPI و فرگمنت...'}
            </span>
          </div>
        ) : isSwitching ? (
          <div className="flex flex-col items-center gap-1">
            <span className="text-sm font-bold text-[#ff7700] animate-bounce">
              افت سرعت! اتصال به تونل اضطراری ملی...
            </span>
          </div>
        ) : (
          <div className="flex flex-col items-center">
            <span className="text-sm font-bold text-slate-200">
              برای اتصال لمس کنید
            </span>
            <span className="text-xs text-slate-500 mt-0.5">
              مسیریابی هوشمند و بدون قطعی
            </span>
          </div>
        )}
      </div>
    </div>
  );
};
