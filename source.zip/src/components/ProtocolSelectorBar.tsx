import React, { useState } from 'react';
import { ALL_SUPPORTED_ENGINES, VPN_CATEGORIES } from '../data/mockServers';
import { VPNProtocol, VPNCategory } from '../types/vpn';
import { VpnBrandLogo } from './VpnBrandLogos';
import { Globe, ShieldAlert, Sparkles } from 'lucide-react';

interface ProtocolSelectorBarProps {
  currentProtocol: VPNProtocol;
  onSelectProtocol: (proto: VPNProtocol) => void;
}

export const ProtocolSelectorBar: React.FC<ProtocolSelectorBarProps> = ({
  currentProtocol,
  onSelectProtocol
}) => {
  const [selectedCategory, setSelectedCategory] = useState<'all' | VPNCategory>('all');

  const filteredEngines = selectedCategory === 'all'
    ? ALL_SUPPORTED_ENGINES
    : ALL_SUPPORTED_ENGINES.filter(e => e.category === selectedCategory);

  return (
    <div className="w-full px-4 pt-1.5 pb-2 space-y-2">
      {/* 2 Main Categories Switcher Tabs */}
      <div className="flex items-center gap-1.5 p-1 rounded-2xl bg-[#0c0d16] border border-slate-800/80">
        <button
          onClick={() => setSelectedCategory('all')}
          className={`flex-1 py-1.5 px-2 rounded-xl text-[10px] font-bold transition-all cursor-pointer text-center ${
            selectedCategory === 'all'
              ? 'bg-[#1e2235] text-white shadow-sm border border-slate-700'
              : 'text-slate-400 hover:text-white'
          }`}
        >
          همه (۱۵)
        </button>

        <button
          onClick={() => setSelectedCategory('international')}
          className={`flex-2 py-1.5 px-2 rounded-xl text-[10px] font-bold transition-all cursor-pointer flex items-center justify-center gap-1.5 ${
            selectedCategory === 'international'
              ? 'bg-gradient-to-r from-[#ff2d78] to-[#ff7700] text-white shadow-md'
              : 'text-slate-400 hover:text-white'
          }`}
        >
          <Globe size={12} />
          <span>۱. بین‌المللی و ضد DPI</span>
        </button>

        <button
          onClick={() => setSelectedCategory('national_emergency')}
          className={`flex-2 py-1.5 px-2 rounded-xl text-[10px] font-bold transition-all cursor-pointer flex items-center justify-center gap-1.5 ${
            selectedCategory === 'national_emergency'
              ? 'bg-gradient-to-r from-[#00ff66] to-[#00e5ff] text-slate-950 font-black shadow-md'
              : 'text-slate-400 hover:text-white'
          }`}
        >
          <ShieldAlert size={12} />
          <span>۲. ضد قطعی ملی و اضطراری</span>
        </button>
      </div>

      {/* Protocols Horizontal Scroll with Authentic Logos */}
      <div className="flex items-center gap-2 overflow-x-auto no-scrollbar py-1">
        {filteredEngines.map((engine) => {
          const isActive = currentProtocol === engine.id;
          return (
            <button
              key={engine.id}
              onClick={() => onSelectProtocol(engine.id as VPNProtocol)}
              className={`flex items-center gap-2 px-3 py-1.5 rounded-xl border text-xs whitespace-nowrap transition-all cursor-pointer select-none active:scale-95 ${
                isActive
                  ? 'bg-gradient-to-r from-[#ff2d78]/25 via-[#ffe600]/15 to-[#00ff66]/20 border-[#00ff66] text-white font-bold shadow-[0_0_14px_rgba(0,255,102,0.35)]'
                  : 'bg-[#10121d] border-slate-800 text-slate-300 hover:text-white hover:border-slate-700'
              }`}
            >
              {/* Authentic Brand Logo */}
              <div className="w-5 h-5 flex items-center justify-center shrink-0">
                <VpnBrandLogo protocol={engine.id} size={20} />
              </div>
              <span className="font-medium">{engine.nameFa}</span>
              {engine.id === 'warp_in_warp' && (
                <span className="text-[8px] bg-[#ffe600] text-slate-950 font-black px-1 rounded">
                  جدید
                </span>
              )}
            </button>
          );
        })}
      </div>
    </div>
  );
};
