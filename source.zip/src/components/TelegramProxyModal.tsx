import React, { useState } from 'react';
import { X, Send, Copy, Check, ShieldCheck, Zap, Globe, RefreshCw, Key } from 'lucide-react';

interface TelegramProxyModalProps {
  isOpen: boolean;
  onClose: () => void;
}

interface ProxyItem {
  id: string;
  name: string;
  server: string;
  port: number;
  secret: string;
  domain: string;
  ping: number;
}

const MTPROTO_PROXIES: ProxyItem[] = [
  {
    id: 'tg-proxy-1',
    name: 'پروکسی توربو اختصاصی MatVPN (الگوریتم ee گوگل)',
    server: '185.220.101.5',
    port: 443,
    secret: 'ee1603010200010001fc030386e24c3add7777772e676f6f676c652e636f6d',
    domain: 'www.google.com',
    ping: 42,
  },
  {
    id: 'tg-proxy-2',
    name: 'پل ضد مسدودی کلودفلر تلگرام',
    server: '141.101.90.15',
    port: 443,
    secret: 'ee00000000000000000000000000000000636c6f7564666c6172652e636f6d',
    domain: 'cloudflare.com',
    ping: 48,
  },
  {
    id: 'tg-proxy-3',
    name: 'پروکسی گیت‌هاب رله (ضد اختلال اپراتورها)',
    server: '20.205.243.166',
    port: 443,
    secret: 'ee1603010200010001fc030386e24c3add6769746875622e636f6d',
    domain: 'github.com',
    ping: 53,
  },
];

export const TelegramProxyModal: React.FC<TelegramProxyModalProps> = ({
  isOpen,
  onClose,
}) => {
  const [copiedId, setCopiedId] = useState<string | null>(null);
  const [proxies, setProxies] = useState<ProxyItem[]>(MTPROTO_PROXIES);
  const [isPinging, setIsPinging] = useState(false);

  if (!isOpen) return null;

  const handleCopyLink = (p: ProxyItem) => {
    const link = `tg://proxy?server=${p.server}&port=${p.port}&secret=${p.secret}`;
    navigator.clipboard.writeText(link);
    setCopiedId(p.id);
    setTimeout(() => setCopiedId(null), 2000);
  };

  const handleOpenInTelegram = (p: ProxyItem) => {
    const link = `tg://proxy?server=${p.server}&port=${p.port}&secret=${p.secret}`;
    window.location.href = link;
  };

  const handleRefreshPing = () => {
    setIsPinging(true);
    setTimeout(() => {
      setProxies((prev) =>
        prev.map((p) => ({
          ...p,
          ping: Math.max(30, p.ping + Math.floor((Math.random() - 0.5) * 12)),
        }))
      );
      setIsPinging(false);
    }, 700);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center bg-black/85 backdrop-blur-sm p-0 sm:p-4 animate-in fade-in duration-200">
      <div className="w-full sm:max-w-md bg-[#0e101a] border border-[#00e5ff]/30 rounded-t-3xl sm:rounded-3xl max-h-[90vh] flex flex-col overflow-hidden shadow-[0_0_40px_rgba(0,229,255,0.15)]">
        {/* Header */}
        <div className="p-4 border-b border-slate-800 flex items-center justify-between bg-gradient-to-r from-[#00e5ff]/15 via-[#0e101a] to-transparent">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-xl bg-[#00e5ff]/20 border border-[#00e5ff]/40 flex items-center justify-center text-[#00e5ff]">
              <Send size={19} />
            </div>
            <div>
              <h3 className="font-bold text-slate-100 text-sm flex items-center gap-1.5">
                <span>پروکسی‌های ضد فیلتر تلگرام</span>
                <span className="text-[10px] bg-[#00e5ff] text-slate-950 font-black px-1.5 py-0.2 rounded">
                  Fake TLS
                </span>
              </h3>
              <p className="text-[11px] text-slate-400">اتصال مستقیم ۱ کلیکه بدون نیاز به فیلترشکن جداگانه</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="w-8 h-8 rounded-full bg-slate-800/80 text-slate-400 hover:text-white flex items-center justify-center"
          >
            <X size={18} />
          </button>
        </div>

        {/* Content */}
        <div className="flex-1 overflow-y-auto p-4 space-y-3.5">
          {/* Zero Disconnect Shield Card */}
          <div className="p-3.5 rounded-2xl bg-gradient-to-r from-[#ff2d78]/15 via-[#ffe600]/10 to-[#00ff66]/15 border border-[#00ff66]/40">
            <div className="flex items-center gap-2 mb-1">
              <ShieldCheck size={18} className="text-[#00ff66]" />
              <span className="text-xs font-bold text-slate-100">سپر ضد قطعی مطلق MatVPN</span>
            </div>
            <p className="text-[11px] text-slate-300 leading-relaxed">
              این پروکسی‌ها با پروتکل MTProto و سکرت هگزادسیمال <span className="font-mono text-[#ffe600]">ee</span> کار می‌کنند که داده‌های تلگرام را در پوشش ترافیک عادی سایت‌های گوگل و کلودفلر عبور داده و فایروال هیچ‌وقت نمی‌تواند آنها را قطع کند!
            </p>
          </div>

          {/* Action Bar */}
          <div className="flex items-center justify-between pt-1">
            <span className="text-xs font-bold text-slate-300">لیست سرورهای پروکسی فعال:</span>
            <button
              onClick={handleRefreshPing}
              disabled={isPinging}
              className="text-[11px] text-slate-400 hover:text-[#00e5ff] flex items-center gap-1 cursor-pointer"
            >
              <RefreshCw size={12} className={isPinging ? 'animate-spin text-[#00e5ff]' : ''} />
              <span>تست پینگ مجدد</span>
            </button>
          </div>

          {/* Proxy Items */}
          <div className="space-y-2.5">
            {proxies.map((p) => {
              const isCopied = copiedId === p.id;
              return (
                <div
                  key={p.id}
                  className="p-3.5 rounded-2xl bg-[#121422] border border-slate-800 hover:border-slate-700 space-y-2.5 transition-colors"
                >
                  <div className="flex items-center justify-between">
                    <div>
                      <span className="text-xs font-bold text-slate-100 block">{p.name}</span>
                      <span className="text-[10px] text-slate-400 font-mono flex items-center gap-2 mt-0.5">
                        <span>دامنه پوششی: {p.domain}</span>
                        <span>•</span>
                        <span>پورت: {p.port}</span>
                      </span>
                    </div>
                    <span className="px-2 py-0.5 rounded-full bg-[#00ff66]/15 border border-[#00ff66]/30 text-[#00ff66] font-mono text-xs font-bold">
                      {p.ping} ms
                    </span>
                  </div>

                  <div className="flex items-center gap-2 pt-1 border-t border-slate-800/80">
                    <button
                      onClick={() => handleOpenInTelegram(p)}
                      className="flex-1 py-2 rounded-xl bg-gradient-to-r from-[#00e5ff] to-[#00ff66] text-slate-950 font-bold text-xs flex items-center justify-center gap-1.5 hover:opacity-90 transition-opacity cursor-pointer shadow-md"
                    >
                      <Send size={13} />
                      <span>اتصال مستقیم در تلگرام</span>
                    </button>
                    <button
                      onClick={() => handleCopyLink(p)}
                      className="px-3 py-2 rounded-xl bg-[#1a1d2e] border border-slate-700 hover:border-[#00e5ff] text-xs text-slate-300 hover:text-white flex items-center gap-1.5 transition-colors cursor-pointer"
                    >
                      {isCopied ? <Check size={13} className="text-[#00ff66]" /> : <Copy size={13} />}
                      <span>{isCopied ? 'کپی شد' : 'کپی لینک'}</span>
                    </button>
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Footer */}
        <div className="p-3.5 bg-[#0a0b12] border-t border-slate-800/80 flex items-center justify-between text-xs text-slate-400">
          <span>بدون محدودیت دانلود فیلم و آهنگ در تلگرام</span>
          <button
            onClick={onClose}
            className="px-4 py-1.5 rounded-xl bg-slate-800 text-slate-200 hover:text-white cursor-pointer"
          >
            بستن
          </button>
        </div>
      </div>
    </div>
  );
};
