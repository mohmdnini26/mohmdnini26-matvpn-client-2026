import React, { useState, useEffect, useRef } from 'react';
import confetti from 'canvas-confetti';
import { AndroidFrame } from './components/AndroidFrame';
import { MatHeader } from './components/MatHeader';
import { ProtocolSelectorBar } from './components/ProtocolSelectorBar';
import { ActiveServerCard } from './components/ActiveServerCard';
import { ConnectButton } from './components/ConnectButton';
import { SpeedGraph } from './components/SpeedGraph';
import { ServerListModal } from './components/ServerListModal';
import { NationalNetFallbackModal } from './components/NationalNetFallbackModal';
import { AdvancedSettingsModal } from './components/AdvancedSettingsModal';
import { CleanIpScannerModal } from './components/CleanIpScannerModal';
import { SplitTunnelingModal } from './components/SplitTunnelingModal';
import { ConfigManagerModal } from './components/ConfigManagerModal';
import { IspDiagnosticTool } from './components/IspDiagnosticTool';
import { TelegramProxyModal } from './components/TelegramProxyModal';
import { SERVERS_LIST } from './data/mockServers';
import { soundEngine } from './utils/audio';
import { CyberRainParticles } from './components/CyberRainParticles';
import { 
  ServerNode, 
  VPNProtocol, 
  ConnectionStatus, 
  VPNSettings, 
  TrafficStats, 
  ISPType 
} from './types/vpn';

export default function App() {
  // Connection & Server State
  const [connectionStatus, setConnectionStatus] = useState<ConnectionStatus>('disconnected');
  const [activeServer, setActiveServer] = useState<ServerNode>(SERVERS_LIST[4]); // Defaults to VLESS Reality FRA
  const [currentProtocol, setCurrentProtocol] = useState<VPNProtocol>('v2ray');
  const [isNationalActive, setIsNationalActive] = useState(false);
  const [connectingStep, setConnectingStep] = useState('');
  const [isAndroidFrameMode, setIsAndroidFrameMode] = useState(true);

  // Active modal
  const [activeModal, setActiveModal] = useState<
    null | 'servers' | 'national' | 'settings' | 'cleanIp' | 'splitTunnel' | 'config' | 'diagnostics' | 'telegram'
  >(null);

  // Settings State
  const [settings, setSettings] = useState<VPNSettings>({
    nationalAutoFallback: true,
    autoFailoverProtocols: true,
    failoverLatencyThreshold: 450,
    fragmentEnabled: true,
    fragmentLength: '1-3',
    fragmentInterval: '15-25',
    fakeSniEnabled: true,
    selectedFakeSni: 'shaparak.ir',
    customFakeSni: '',
    amneziaJunkPackets: true,
    amneziaJunkMin: 50,
    amneziaJunkMax: 1000,
    mtu: 1280,
    killSwitch: false,
    splitTunnelingMode: 'bypass_iran',
    whitelistedIranianApps: ['ir.bankmellat', 'ir.melli.baam', 'cab.snapp.passenger', 'com.digikala'],
    dnsType: 'cloudflare_doh',
    customDns: '',
    soundEffects: true,
    hapticFeedback: true,
    rainParticlesEnabled: true,
    currentISP: 'mci'
  });

  // Traffic Stats
  const [trafficStats, setTrafficStats] = useState<TrafficStats>({
    downloadSpeed: 0,
    uploadSpeed: 0,
    totalDownloadedBytes: 1024 * 1024 * 42,
    totalUploadedBytes: 1024 * 1024 * 12,
    currentPing: 58,
    packetLoss: 0,
    durationSeconds: 0
  });

  const timerRef = useRef<NodeJS.Timeout | null>(null);

  // Live Traffic Simulation when connected
  useEffect(() => {
    if (connectionStatus === 'connected') {
      const interval = setInterval(() => {
        setTrafficStats(prev => {
          const dlDelta = (Math.random() * 22 + 8);
          const ulDelta = (Math.random() * 8 + 2);
          const jitter = Math.floor((Math.random() - 0.5) * 8);
          const currentPing = Math.max(28, (isNationalActive ? 32 : activeServer.ping) + jitter);

          return {
            ...prev,
            downloadSpeed: dlDelta,
            uploadSpeed: ulDelta,
            totalDownloadedBytes: prev.totalDownloadedBytes + dlDelta * 1024 * 128,
            totalUploadedBytes: prev.totalUploadedBytes + ulDelta * 1024 * 64,
            currentPing,
            packetLoss: Math.random() < 0.08 ? 1 : 0,
            durationSeconds: prev.durationSeconds + 1
          };
        });
      }, 1000);
      return () => clearInterval(interval);
    } else {
      setTrafficStats(prev => ({
        ...prev,
        downloadSpeed: 0,
        uploadSpeed: 0,
        currentPing: activeServer.ping,
        packetLoss: 0
      }));
    }
  }, [connectionStatus, activeServer.ping, isNationalActive]);

  // Connect / Disconnect Handler
  const handleToggleConnect = () => {
    if (settings.soundEffects) soundEngine.playTick();

    if (connectionStatus === 'connected') {
      // Disconnecting
      if (settings.soundEffects) soundEngine.playDisconnect();
      setConnectionStatus('disconnected');
      setIsNationalActive(false);
      return;
    }

    // Connecting steps
    setConnectionStatus('connecting');
    if (settings.soundEffects) soundEngine.playConnectStart();

    const steps = [
      'تست اختلال شبکه و DPI اپراتور...',
      settings.fragmentEnabled ? 'تکه‌تکه سازی پکت‌های TLS (Fragment 1-3)...' : 'تنظیم مسیر امن...',
      settings.fakeSniEnabled ? `جعل هدر و SNI به سمت ${settings.selectedFakeSni}...` : 'مذاکره امن...',
      `برقراری پروتکل ${activeServer.protocol.toUpperCase()}...`,
      'تایید پینگ و تونل بدون قطعی...'
    ];

    let stepIdx = 0;
    setConnectingStep(steps[0]);

    const stepInterval = setInterval(() => {
      stepIdx++;
      if (stepIdx < steps.length) {
        setConnectingStep(steps[stepIdx]);
      } else {
        clearInterval(stepInterval);
        setConnectionStatus('connected');
        if (settings.soundEffects) soundEngine.playConnectedSuccess();

        // Celebratory rainbow confetti
        confetti({
          particleCount: 40,
          spread: 60,
          origin: { y: 0.6 },
          colors: ['#ff2d78', '#ff7700', '#ffe600', '#00ff66', '#00e5ff', '#a855f7']
        });
      }
    }, 450);
  };

  // Switch to National Relay (Emergency simulation or auto fallback)
  const handleTriggerEmergencyNational = () => {
    if (settings.soundEffects) soundEngine.playNationalSwitch();
    
    if (isNationalActive) {
      // Revert to international
      setIsNationalActive(false);
      const intlServer = SERVERS_LIST.find(s => !s.isNationalRelay) || SERVERS_LIST[4];
      setActiveServer(intlServer);
      setCurrentProtocol(intlServer.protocol);
      return;
    }

    setConnectionStatus('switching_to_national');
    setTimeout(() => {
      setIsNationalActive(true);
      const iranServer = SERVERS_LIST.find(s => s.isNationalRelay) || SERVERS_LIST[0];
      setActiveServer(iranServer);
      setCurrentProtocol('iran_relay');
      setConnectionStatus('connected');
      if (settings.soundEffects) soundEngine.playConnectedSuccess();
    }, 1100);
  };

  // Protocol Selection from toolbar
  const handleSelectProtocol = (proto: VPNProtocol) => {
    if (settings.soundEffects) soundEngine.playTick();
    setCurrentProtocol(proto);
    const matchingServer = SERVERS_LIST.find(s => s.protocol === proto) || SERVERS_LIST[0];
    setActiveServer(matchingServer);
    if (proto === 'iran_relay') {
      setIsNationalActive(true);
    } else {
      setIsNationalActive(false);
    }
  };

  const handleUpdateSettings = (newSettings: Partial<VPNSettings>) => {
    setSettings(prev => ({ ...prev, ...newSettings }));
  };

  const handleApplyCleanIp = (ip: string) => {
    const warpServer = SERVERS_LIST.find(s => s.protocol === 'warp') || SERVERS_LIST[2];
    setActiveServer({
      ...warpServer,
      serverIp: ip,
      nameFa: `وارپ با آی‌پی تمیز (${ip})`,
      ping: 48,
      isCleanIp: true
    });
    setCurrentProtocol('warp');
  };

  const handleImportCustomConfig = (configStr: string) => {
    const customNode: ServerNode = {
      id: `custom-${Date.now()}`,
      name: 'Custom User Config',
      nameFa: 'کانفیگ شخصی وارد شده',
      country: 'Custom Route',
      countryCode: 'custom',
      flag: '⚡',
      protocol: 'v2ray',
      subProtocol: 'vless_reality',
      ping: 42,
      serverIp: '1.1.1.1',
      port: 443,
      recommendedIsps: ['mci', 'mtn', 'rightel', 'mokhaberat', 'zitel'],
      loadPercentage: 20,
      configUrl: configStr,
      features: ['پیکربندی اختصاصی کاربر', 'پشتیبانی از فرگمنت', 'ضد DPI']
    };
    setActiveServer(customNode);
    setCurrentProtocol('v2ray');
  };

  return (
    <AndroidFrame
      connectionStatus={connectionStatus}
      isNationalActive={isNationalActive}
      isAndroidFrameMode={isAndroidFrameMode}
      setIsAndroidFrameMode={setIsAndroidFrameMode}
    >
      {/* Cyberpunk Rain Particle Effect (Pink by default, 1-sec color shifting on connect) */}
      {settings.rainParticlesEnabled && (
        <CyberRainParticles isConnected={connectionStatus === 'connected'} />
      )}

      {/* Top Bar with Logo and Small Beautiful Settings Button */}
      <MatHeader
        onOpenSettings={() => setActiveModal('settings')}
        isNationalActive={isNationalActive}
      />

      {/* Protocol Quick-Switcher Bar */}
      <ProtocolSelectorBar
        currentProtocol={currentProtocol}
        onSelectProtocol={handleSelectProtocol}
      />

      {/* Active Server Node Card */}
      <ActiveServerCard
        server={activeServer}
        onOpenServerModal={() => setActiveModal('servers')}
        isNationalActive={isNationalActive}
      />

      {/* Central Connect Button with 7-Color Rainbow Aura */}
      <ConnectButton
        status={connectionStatus}
        onToggle={handleToggleConnect}
        connectingStepText={connectingStep}
        ping={trafficStats.currentPing}
      />

      {/* Real-time Traffic Graph & Latency Speedometer (Ocean Waves with 1s color shift) */}
      <div className="w-full px-4 my-1">
        <SpeedGraph
          stats={trafficStats}
          isConnected={connectionStatus === 'connected'}
          activeServer={activeServer}
        />
      </div>

      {/* National Relay Notification Alert Banner when auto-fallback is triggered */}
      {isNationalActive && (
        <div className="mx-4 my-2 p-3 rounded-2xl bg-gradient-to-r from-[#00ff66]/15 via-[#ffe600]/10 to-[#ff7700]/15 border border-[#00ff66]/50 flex items-center justify-between animate-in fade-in">
          <div className="flex items-center gap-2.5">
            <span className="w-2.5 h-2.5 rounded-full bg-[#00ff66] animate-ping" />
            <div>
              <span className="text-xs font-bold text-[#00ff66] block">
                تونل اضطراری اینترنت ملی فعال است
              </span>
              <span className="text-[10px] text-slate-300">
                در شرایط اختلال، ترافیک بدون قطعی از پل داخلی به خارج رله می‌شود.
              </span>
            </div>
          </div>
          <button
            onClick={handleTriggerEmergencyNational}
            className="text-[10px] font-bold px-2 py-1 rounded-lg bg-slate-800 text-slate-300 hover:text-white cursor-pointer"
          >
            عادی‌سازی
          </button>
        </div>
      )}

      {/* All Sub-modals */}
      <ServerListModal
        isOpen={activeModal === 'servers'}
        onClose={() => setActiveModal(null)}
        activeServer={activeServer}
        onSelectServer={(server) => {
          setActiveServer(server);
          setCurrentProtocol(server.protocol);
          setIsNationalActive(!!server.isNationalRelay);
        }}
      />

      <NationalNetFallbackModal
        isOpen={activeModal === 'national'}
        onClose={() => setActiveModal(null)}
        settings={settings}
        onUpdateSettings={handleUpdateSettings}
        onTriggerEmergencyNational={handleTriggerEmergencyNational}
        isNationalActive={isNationalActive}
      />

      <AdvancedSettingsModal
        isOpen={activeModal === 'settings'}
        onClose={() => setActiveModal(null)}
        settings={settings}
        onUpdateSettings={handleUpdateSettings}
        onOpenTelegramModal={() => setActiveModal('telegram')}
        onOpenCleanIpModal={() => setActiveModal('cleanIp')}
        onOpenNationalModal={() => setActiveModal('national')}
        onOpenSplitTunnelModal={() => setActiveModal('splitTunnel')}
        onOpenConfigManager={() => setActiveModal('config')}
        onOpenDiagnostics={() => setActiveModal('diagnostics')}
        onSelectGitHubTunnel={() => {
          const ghServer = SERVERS_LIST.find(s => s.protocol === 'github_tunnel') || SERVERS_LIST[0];
          setActiveServer(ghServer);
          setCurrentProtocol('github_tunnel');
          setIsNationalActive(false);
          if (settings.soundEffects) soundEngine.playConnectedSuccess();
        }}
        onSelectWarpInWarp={() => {
          const wiwServer = SERVERS_LIST.find(s => s.protocol === 'warp_in_warp') || SERVERS_LIST[0];
          setActiveServer(wiwServer);
          setCurrentProtocol('warp_in_warp');
          setIsNationalActive(false);
          if (settings.soundEffects) soundEngine.playConnectedSuccess();
        }}
      />

      <CleanIpScannerModal
        isOpen={activeModal === 'cleanIp'}
        onClose={() => setActiveModal(null)}
        onApplyCleanIp={handleApplyCleanIp}
      />

      <SplitTunnelingModal
        isOpen={activeModal === 'splitTunnel'}
        onClose={() => setActiveModal(null)}
        settings={settings}
        onUpdateSettings={handleUpdateSettings}
      />

      <ConfigManagerModal
        isOpen={activeModal === 'config'}
        onClose={() => setActiveModal(null)}
        activeServer={activeServer}
        onImportCustomConfig={handleImportCustomConfig}
      />

      <IspDiagnosticTool
        isOpen={activeModal === 'diagnostics'}
        onClose={() => setActiveModal(null)}
        currentIsp={settings.currentISP}
        onChangeIsp={(isp) => handleUpdateSettings({ currentISP: isp })}
        onSelectRecommendedServer={(server) => {
          setActiveServer(server);
          setCurrentProtocol(server.protocol);
          setIsNationalActive(!!server.isNationalRelay);
        }}
      />

      <TelegramProxyModal
        isOpen={activeModal === 'telegram'}
        onClose={() => setActiveModal(null)}
      />
    </AndroidFrame>
  );
}
